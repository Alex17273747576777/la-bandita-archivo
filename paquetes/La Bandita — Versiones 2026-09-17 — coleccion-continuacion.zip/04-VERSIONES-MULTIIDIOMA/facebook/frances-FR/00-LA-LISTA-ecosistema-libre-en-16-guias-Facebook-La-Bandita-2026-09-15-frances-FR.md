# LA LISTE — L'écosystème libre en 18 guides (fondée le 14 · coupe du 15 septembre 2026)

**La Bandita · 15 de septiembre de 2026 · édition française (adaptée de l'original espagnol, pièce 00)**

Dix-sept guides, un seul jour de vérification. Chaque projet de cette liste a ouvert son dépôt, sa page de releases et son README AUJOURD'HUI. La règle de la carte est une : si c'est noté, c'est vivant — et si c'est vivant, ça a une date.

## 🗺️ La carte de la liste

```
BOUTIQUES ET MÉTIER
├── 01  Boutiques d'APK légales — les fiches, l'horloge de 2027
├── 03  Vérification des Développeurs — 15 jours jusqu'au jalon
├── 09  Outils FOSS — la boîte du métier, pièce par pièce
├── 10  GLTools ne se prescrit pas — le panneau de 2020 et le nombre sans source
└── 12  FMHY — le wiki de pistes, pas un catalogue

LECTEURS : MANGAS, ROMANS ET ANIME
├── 02  Kototoro v2.1.3 — mangas, romans et vidéo dans une bibliothèque
├── 04  Extensions : les trois arbres et leurs hubs vivants
├── 06  Forks de lecteurs — les secondes générations
├── 07  Usagi est vivante — la chaîne Kotatsu → Yukimi → Usagi
├── 11  AniZen v0.5.211 — le miroir n'est pas le dépôt
├── 13  Branche Aniyomi — mangas et anime en une seule main
├── 17  Couche d'immersion — Chimahon, Hoshi, Yomikai, Yomi, Koharia
├── 14  Branche anime pur — Animiru et Anikku
├── 15  Branche J2K — le grand-père est revenu, le fantôme a une maison
└── 16  Branche SY/Komikku — le classique et le second fils avec organisation

MUSIQUE ET NOUVELLE DU JOUR
├── 08  Musique FOSS — clients avec dépôt et date de pouls
└── 05  TMO est tombé — les clones ne sont pas TMO

LIVRES
└── 18  Livres libres — OpenlibExtended : la bibliothèque dans la poche
```

## 🗂️ Les catalogues (la carte des cartes)

Les répertoires que la Bandita a consultés pour construire et nourrir cette liste — on les utilise comme point de départ, jamais comme vérification :

- **Miyomi** (miyomi.app) — le répertoire de l'écosystème Tachiyomi/Mihon : apps, entrepôts et guides. Son catalogue vit dans la session du navigateur (pas de JSON public) : on le lit dans le navigateur, avec calme.
- **The Index** (theindex.moe) — collections curées à la main par son équipe éditoriale : des VPN sans-logs (distinction court-proven incluse) aux apps de mangas et d'anime pour Android. Les sections 18+ se nomment sans index.
- **EverythingMoe** (everythingmoe.com) — toplist curée de la culture otaku (anime, mangas, manhwa, apps, musique), actualisée chaque heure, avec son propre cimetière et détecteur de chutes.
- **Wotaku** (wotaku.wiki) — wiki par sections : webs, logiciels par système, extensions, guides et glossaire.
- **FMHY** (fmhy.net) — le wiki de pistes du logiciel libre (pièce 12 de cette collection) : découverte oui, vérification non.

La règle avec tous : le catalogue ouvre la porte ; la maison du projet ferme le dossier. Les catalogues qui indexent des sites de streaming et des agrégateurs se lisent comme carte du terrain — ici on ne les copie ni ne les prescrit.

## 🧭 Comment on lit

- **Coupe du jour.** Tout ce qui est noté a été vérifié le 14 septembre et re-vérifié tout au long du 15 : Kototoro (v2.1.3), Yomikai (1.9.84) et Chimahon (v2.4.2) se sont levés avec release neuve ; Anikku a inauguré r8932 ; N-Zik a lâché sa première dev v8.0.0. À la clôture : recensement vivant des 560 maisons citées dans le corpus, Riffle et Debrify sont entrés par lien du propriétaire (pièces 36 et 23), Tadami restée rectifiée vivante avec organisation propre neuve, et Nuvio s'est levé suspendu de Google Play — PV levé. Le reste de la carte, pareil. Chaque lien se rouvre le jour où on l'utilise.
- **Seul le vivant.** La carte ne nomme ni archivés ni miroirs : elle note des projets actifs avec apport propre.
- **Rien d'index d'installation ici.** On nomme les maisons ; la recette se lit dans chaque maison, le jour où on en a besoin.

**Le mème de la coupe :**

> — Et lequel est le meilleur lecteur ?
> — Celui qui s'est levé avec une release neuve. Aujourd'hui, six se sont levés.

> La Bandita rapporte à partir de sources datées. La liste n'est pas éternelle : elle est d'aujourd'hui — et ça la rend honnête.

> **Note datée (15-sep) :** le titre conserve « 16 guides » comme à la fondation. Recompte vérifié AUJOURD'HUI dans l'archive : **46 guides Facebook + 46 jumelles WhatsApp** (00–19 du 14-sep ; 20–45 du 15-sep). Le mot final sur le titre appartient au propriétaire.

> **Note datée (15-sep, déménagement) :** par mandat du propriétaire, la série 00–19 a été actualisée, re-vérifiée contre les maisons et déménagée de la fournée du 14 vers le dossier du 15 : la série complète 00–79 vit sous une même coupe. PV : Registre #71.

> **Note datée (15-sep, tour du petit matin XXXV — au plafond) :** recompte re-vérifié dans l'archive : **80 guides Facebook + 80 jumelles WhatsApp (00–79)** — la quinzaine a touché son plafond. La liste du plafond, en une page : pièce 78 du 15-sep. Le mot final sur le titre appartient au propriétaire.

> **Note datée (15-sep, soir — la carte au jour) :** le jour a fermé son compte. Les 560 maisons citées dans le corpus ont été vérifiées en direct et en parallèle, avec soustraction au détail (Registre #73). Les trois supposés tombés se sont révélés fausses alertes : deux étaient des placeholders de la pièce 75 et un, un pointeur tronqué de la citation de TWRP — **aucune maison n'est morte** ; la maison de Tadami vit (★260) et a inauguré organisation propre (tadamiorg). La nouvelle globale : Nuvio suspendu de Google Play par une plainte DMCA de la MPA, ses maisons GitHub vivantes et des apps fausses rôdant dans la boutique (Registre #74). Fiches neuves par lien du propriétaire : **Riffle** (pièce 36, les livres) et **Debrify** (pièce 23, le salon du mur). Clôture du jour et livraison finale : Registre #75, ZIP 96ᵉ/97ᵉ. Le mot final appartient au propriétaire.

---

**Note de déménagement (15-sep) :** guide passé de la fournée du 14 à celle-ci, avec re-vérification contre les maisons : recompte et déménagement. Ce qui n'est pas mentionné reste constaté à son jour (14-sep). PV complet : Registre #71.
