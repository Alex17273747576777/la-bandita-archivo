# LEEME — Corpus de La Bandita (102ª edición · 2026-09-15, martes)

Este paquete es La Bandita entera. Estado del día en el Handoff.

## Novedades del 14-sep (noche)

1. **Manual §5.4 (nueva):** 12 reglas extraídas del chat del 14-sep, con las palabras textuales de Alexis y la regla en lenguaje claro — corte de hoy, pieza limpia, trazabilidad aparte, aire al ojo, crecer solo con verdad, títulos que se explican, entrega explicada con números, órdenes que se traducen.
2. **Lecciones de Alexis:** nueva entrada fechada (2026-09-14, II).
3. **Las publicaciones del corte:** limpias y por canal — ahora 20 piezas en Facebook/ y 20 gemelas en WhatsApp/ (corte 2026-09-14).
4. **Veredicto Usagi:** viva. Árbol Kotatsu: Kotatsu-Redo 9.8.3 · Futon 9.8.1 · Kototoro v2.1.2 · Usagi 1.0.
5. **CORRECCIÓN DEL DUEÑO (noche #9):** Yūzōnō manga = espejo automático de Keiyoushi, sin aportes originales, descontinuado (no archivado) — piezas 02/04/16 corregidas. El canal anime de Yūzōnō se mantiene.
6. **CONFIRMACIÓN + NUEVOS (noche #8):** 77 repos de las piezas 01-12 re-verificados — 0 cambios. Estrellas ajustadas por drift (aniyomi 7.679, Animiru 863, J2K 5.383, SY 4.143). Nuevos fichados: HayaiTTS (TTS offline ★39), yuzono/kohi-den (sucesión del almacén anime), tracker-extensions, rokku-nightly.
7. **EXPEDICIÓN PROFUNDA:** las redes completas de las 4 ramas caminadas hasta las hojas (≈3.100 miembros, network/members): capa profunda con rarezas — kikuyomi (audiolibros), jishoyomi (estudiar con anime), Kuukiyomi ×7, históricos 2019, 2ª generación viva (yurei-MIUI v1.11.0, leassapie/houri). Verbatim del dueño (método del bosque) archivado en §0.3 del Manual.
8. **LA CAPA QUE EL GRAFO ESCONDE:** Alexis trajo 5 forks que el barrido directo no vio — ShinKu ★31 (v2.6.9, IA discovery), MihonSY ★13, Pokomi ★11 (Author Following), NEXUS ★3, bchan ★5 — todos fichados en la pieza 16. Corrección: «Shinku no existe» era falso; Lecciones (III) con la lección.
9. **REDES DE FORKS COMPLETAS:** las 4 guías por rama abren ahora la red de forks de sus 12 repos (≈800 barridos): Houri ★10 (Komikku, releases HOY), TachiyomiS97 ★125 (J2K), Chai ★12 (SY), Kuro ★21, yurei, yokai-T, MeMedia y demás activos con sus funciones propias. «Shinku» no existe en GitHub (verificado) — se pide enlace.
10. **RE-ESCANEO DEL ECOSISTEMA:** Aniyomi despertó — v0.18.2.0/0.18.2.1 publicadas el 14-sep tras 11 meses; Animetail y Animiru confirmados como forks respaldados en aniyomi.org/forks; clúster de impostores SEO con 2 integrantes nuevos (nombrados sin enlazar).
11. **GUÍAS POR RAMA (nuevas 13–16):** el árbol Tachiyomi/Mihon abierto por sus 4 ramas — Aniyomi/Animetail/Tadami · Animiru/Anikku · J2K/Yōkai/Rokku/Reikai/Hayai · SY/Komikku — con forks directos y sub-forks, todo verificado HOY. Corrección clave: Hayai ya es público.
12. **MAPA SOLO ACTIVO (noche #10):** el mapa anota únicamente lo ACTIVO — release/push verificados con fecha; lo muerto pasa al Registro; los espejos sin aportes propios quedan fuera. Investigación completa ANTES de reportar.
13. **LA LISTA (noche #11):** la pieza 00 reescrita como índice del ecosistema libre — mapa + título + descripción de cada guía, con meme textual ORIGINAL no sofocante.
14. **MÉTODO EN PARALELO (noche #12):** exploración profunda en paralelo primero; actualización de lo existente después. Los recursos que nombra el dueño entran al mapa solo tras revisión («revisar bien»); «etc» = familia completa; los catálogos son fuente de listas.
15. **PIEZA 17 «CAPA DE INMERSIÓN» (noche #13):** nueva guía — Chimahon · Hoshi-Reader · Yomikai · Yomi · Koharia y servidores Komga/Kavita; LA LISTA llega a 17 guías y estrena sección «Los catálogos».
16. **EXPLORACIÓN LIBRE (noche #14, regla nueva — Lecciones IV):** «Nunca te limites solo a lo que te doy… explora libremente, pero sin acumular basura». Komga (★6.659, MIT) y Kavita (★11.677, GPL-3.0) fichados en pieza 17; Dantotsu con licencia-broma (UPL) sigue observado. La pregunta del dueño sobre los sueños archivada verbatim.
17. **CANCIONES DEL TRATADO (noche #15):** §0.3 quinta ampliación — Mañana Será Otro Día · Hace Falta Soñar · Cámbiate · Vuele Bajo (enlaces letras.com verificados) + 9 candidatas multilingües sin ratificar. Cotejo: la pregunta del dueño era el estribillo de «Hace Falta Soñar» (Lecciones IV).
18. **CATÁLOGOS DE LA CASA (noche #16):** 7 catálogos de artista → 14 fichas nuevas al §0.3 (Canserbero ×2 · Cabral ×2 · MJ ×2 · Ado ×2 · Milo J ×2 · Lavoe ×2 · Colón ×2). «No soy de aquí» promociona de candidata a ficha.
19. **LOS CAMINOS DE LA VIDA (noche #17):** Grupo Niche · Los Diablitos · Los Vaguens abiertos HOY — 4 fichas nuevas (Busca Por Dentro · Amanecerá y veremos · No Voy a Llorar · Al Despertar) + enlaces oficiales para «Lo Que Soy» y «Los Caminos de La Vida». REPARACIÓN: este LEEME seguía en 30ª real — se pone al día con esta entrega, huellas regeneradas de los archivos.
20. **BUENOS DÍAS SEÑOR SOL (noche #18):** el cotejo pendiente desde el 10-sep se cierra — «Buenos días señor sol» es de **Juan Gabriel** (1979, letra verificada; la ficha [A] promueve a [T]). 6 catálogos nuevos (Juan Gabriel · Joe Veras · Coldplay · Harry Styles · Young the Giant · Rag'n'Bone Man) → 11 fichas nuevas al §0.3: Adventure Of a Lifetime (la favorita del dueño; «Everything you want's a dream away») y As It Was («it's not the same as it was») con letra completa verificada; Fix You · Sign of the Times · My Body · Mind Over Matter · Human · Skin · Canta Vive y Sueña · y en el barrio, Joe Veras «La vida es asi» y «El Molde».
21. **REMAPEO COMPLETO + LIBROS Y MÚSICA (noche #19):** 31 repos con pulso HOY — el ecosistema fichado sigue exacto (única novedad: Metrolist Nightly, → pieza 08). Nueva pieza 18 «Libros libres»: OpenlibExtended (cliente open source de Anna's Archive, AGPL-3.0, v1.6.0 — busca en LibGen/Z-Library/Anna's a la vez, lector EPUB/PDF, TTS beta). Pieza 08 ampliada con N-Zik (fork multilingüe de Kreate) y Gabi (descargador yt-dlp/gallery-dl, 1000+ sitios). LA LISTA pasa a 18 guías. Piezas: 19 FB + 19 WA gemelas.
22. **RE-VERIFICACIÓN ANIZEN + iQOO (noche #20):** AniZen v0.5.211 sigue siendo la última release (no hay versión más nueva; cadencia semanal; sin ficha en Google Play — los «viejos» de los grupos son espejos); las «~1000 reseñas de la beta» quedan como dicho del dueño sin fuente (el enlace la cierra). El dueño tenía razón en el iQOO: AnTuTu sep-2026 — #1 RedMagic 11S Pro+ (4.118.689), #2 iQOO 15 Ultra (4.118.578). Piezas 10 y 11 actualizadas con fuente y fecha.
23. **LA BETA DE ANIZEN (noche #21):** el dueño trajo el enlace — anizen-preview («Automated Preview Builds», ★8): 981 releases automáticas, varias por día. El «casi 1000» de la noche #20 era REAL: releases, no reseñas; «la beta va a tren», verificado literal. La estable sigue en v0.5.211. Pieza 11 actualizada; Lecciones (V): el enlace no solo cierra el caso — a veces le cambia el nombre.
24. **VERIFICACIÓN FINAL + PANORAMA MULTI (noche #22):** 36 repos con pulso de cierre — lo publicado sigue exacto (N-Zik ya cocina v8.0.0-dev en repo; estable de tienda 7.5.1-f). miyomi.app Multi renderizó HOY (~33 apps) → PIEZA 19 nueva «El panorama multi»: 7 fichas multi de la casa con pulso + 12 nombres nuevos sin enlace (regla de URLs). Hallazgo: J2K 1.8.1 = 15-ago-2026 (corrige la fecha del FIX pendiente de la pieza 16 — el fondo se mantiene).
25. **PROYECTO BIBLIOTECA 50–80 (martes 15-sep):** el dueño trajo la V25 (1.029 fichas contadas, corte 2-sep) → lote 1: Mapa de la Biblioteca (75 = 20 existentes + 55 nuevas por las 12 puertas), Inventario V25 al corpus, PIEZA 20 «La Biblioteca» (corte 15-sep). Pendiente: lotes 21–74, una puerta por turno.
26. **ACTUALIZACIÓN AL DÍA + LOTE 2 (martes 15-sep):** pulso matinal de 36 repos — Kototoro v2.1.3 e Ymikai v1.9.83 amanecieron con release (piezas 02/00/17/19 al día); el resto igual. PIEZA 21 «Música I»: la primera cosecha del muro — 12/12 fichas verificadas a fuente HOY (2 más nuevas que el V25; el RESUMEN del muro documentado como relleno genérico).
27. **LOTES 3-4: LECTURA + ANIME/VÍDEO (martes 15-sep):** vara del dueño: cada pieza con su contexto, nada de copy-paste genérico. 17 fuentes verificadas HOY — 14 vivas a las piezas 22 («Lectura II — la repisa del muro») y 23 («La sala del muro»: IPTV/Jellyfin/reproductores — la puerta no era anime), 2 archivados al Registro (Kumo, CornCastle). Cruces con las guías de la casa citados, no repetidos.
28. **LOTES 5-7 — COSECHA COMPLETA DEL MURO (martes 15-sep):** 48 fuentes verificadas (OpenCloud 8.0.0, ShizukuPlus v13.6.0 y Greet&Grow v1.4.0 publicadas HOY; 0 archivados; 1 radar GitLab 403). Piezas 24 «El taller» (18 herramientas de Shizuku/root), 25 «El sótano» (7 servidores propios), 26 «El cajón» (24 fichas en 3 compartimentos, con vara anti-inflación sobre open-design ★96.304 y nowinandroid re-ubicado como proyecto-escuela de Google). La capa verificada del muro (~82 fichas) queda completa en piezas 21-26; 940 candidatas esperan lotes futuros.
29. **EXPLORACIÓN POR PUERTA — FAMILIA AXMANAGER (martes 15-sep):** regla del dueño: LA LISTA no se apega solo al muro — cada puerta se explora hacia afuera. Primera red: AxManager (★1.433, madre) + AxManagerD (Dhizuku) + AxManager-pro + Axora (el «medio fantasma» existe) + Axeron-API — pieza 24, sección «Los que el muro no tenía».
30. **INVESTIGACIÓN + MÚSICA II (martes 15-sep):** paquete remanente investigado (UUID = Lecciones 13-sep, subconset del corpus; miyomi Multi cerrado en 37 apps). Exploración de sucesiones: InnerTune → Estrella-Music (heredero renombrado); Metrolist → mudanza a MetrolistGroup, Meld es su hija (corregido en pieza 21), nietos MetroFuse e Iride. PIEZA 27 «Música II — las sucesiones». API GitHub agotada al cierre (pendientes: estrellas de Iride, más puertas).
31. **LOTE ANDROID I — EL TRONCO (martes 15-sep):** 18 fichas verificadas (raíz, gestión sin root, tiendas) — Magisk ★62.780, scrcpy ★149.679, Shizuku ★30.154, Termux ★60.850, Obtainium ★19.688, Dhizuku, Hail (aistra0528), SAI (release estancada 2021, aviso), LSPosed (release vieja, push vivo — matiz). 173 candidatas clasificadas (catálogos → fuente; lectura/anime → sus puertas). Método SEARCH+atom con CORE agotada. PIEZA 28. Pendientes: estrellas Hail/Iride, ~155 candidatas.
32. **LOTE ANDROID II — LOS MAYORDOMOS + «VUELA BAJO» (martes 15-sep, tarde):** lección nueva del dueño (Lecciones, 15-sep): «vuela bajo, porque abajo está la verdad» — deudas pagadas raspando casas sin API (Hail ★6.666, Iride ★15 → piezas 27/28). 13 fichas: gestores (Inure, ShizuTools, ObtainX —release HOY—, Buge, AppControl-X), dueño/perfiles (OwnDroid madre, Canta, Island, Shelter, FreezeYou), debloat (UAD dormida → UAD-NG; SD Maid SE viva, vieja ARCHIVADA), KeyMapper. Radar: EnforceDoze. PIEZA 29. Quedan ~90 candidatas Android.
33. **LOTE ANDROID III — LA CARA DEL SISTEMA (martes 15-sep, tarde II):** 12 fichas (lanzadores, fondos, teclados, personalización, artesano KieronQuinn). Lawnchair ★13.525 Nightly de HOY; mudanza certificada Helium314→HeliBorg (HeliBoard ★6.117); estirpe OpenBoard→HeliBoard verificada; TapTap/AmbientMusicMod tranquilas (vigilar). Pendientes: SmartDock, Peristyle, Grayscaler, SmartIsland, Adaptive-Hz, Tweaker. PIEZA 30. Quedan ~80 candidatas Android.
34. **AUDITORÍA DE LA CASA — «ESPALDA A LOS ELOGIOS, FRENTE A LA CRÍTICA» (martes 15-sep, tarde III):** lección 15-sep II + §0.3 Cuarta ampliación (Reigen Arataka, [P]/[A]). Reparado: typo «viges»; pieza 16 Yomiko → J2K 1.8.1 = 15-ago-2026 (legacy saldado). Documentado sin tocar: LA LISTA (archivo 16 / título 18 — decisión del dueño).
35. **LOTE ANDROID IV — LOS PEQUEÑOS DEL SISTEMA (martes 15-sep, tarde IV):** 11 fichas de utilitarios de una sola cosa; 6 pendientes de la pieza 30 resueltos (SmartDock, Peristyle, SmartIsland, Grayscaler, Adaptive-Hz; Tweaker→radar); RADAR EnforceDoze de la pieza 29 CERRADO por enlace (Akylas, vía awesome-shizuku). Radares: ShortsBlocker, ScreenOff (nombres con conflicto). PIEZA 31. Quedan ~70 candidatas Android.
36. **BARRIDO DE CIERRE DEL DÍA — «PASO QUE DURE» (martes 15-sep, tarde V):** lección 15-sep III (la calma es duración). Orden noche #22 cumplida: barrido de los 107 repos citados en las piezas del día — 107/107 VIVOS, 0 fallas, versiones sin desvío. Consolidación.
37. **LOTE ANDROID V — EL CABLE Y EL ESCUDO (martes 15-sep, tarde VI):** 10 fichas (cable/PC, red/escudo, actualizadores, módulos). TWRP con matiz (push HOY, builds fuera de GitHub); NetGuard raspada de casa conocida; SUCESIÓN Nº5: FoxMMM→Androidacy (letrero propio). 3 matizes fechados. PIEZA 32. Quedan ~60 candidatas Android (ambiguos por identificar).
38. **LOTE ANDROID VI — LOS ARCHIVOS DEL TALLER (martes 15-sep, tarde VII):** 9 fichas (cajones, paquetes, agente IA, vanidades, guardián). Haven ACTIVO (v5.87.86 de ayer — el «dormido» era falso); YoukiDEX ARCHIVADO con despedida fechada HOY; shizuku-modules como colección. PIEZA 33. Puerta Android: recta final — quedan los ambiguos (~15 nombres).
39. **REGLA: CADA CONTEXTO, SU PROPIA VARA (martes 15-sep, tarde VIII):** aclaración del dueño («"Sigue así" = adaptarse a cada contexto, no repetir el método») + frase del pez/árbol (enlace del dueño registrado, reintento pendiente). Mapa regla 8. 4 ambiguos resueltos con varas distintas: Extendroid (legendsayantan, autor doble con ShizuTools), OmniPrompt, pastiera (teclado físico), Fluffy=app.fluffy (mlm-games, autor doble con BatStats; vara = catálogo F-Droid). Pista: project_mythara (agente IA local). Quedan ~11 ambiguos.
40. **LOS AMBIGUOS RESUELTOS — PUERTA ANDROID COMPLETA (martes 15-sep, tarde IX):** 7 identificados con varas distintas (NFile, SelfLock, Language-Selector+Neo, WidgetsPro, Smart-Edge+homónimo, deskcontrol, ADNS); 4 radares con porqué (Hamburger, MagicDesk/C64, Sentry FM, PI). PUERTA ANDROID COMPLETA: 173 candidatas procesadas (piezas 28-34). PIEZA 34.
41. **AUDITORÍA MAYOR DEL DÍA (martes 15-sep, tarde X):** barrido vivo 180/180; desvíos corregidos (Kvaesitso 1.41.0, DreamPlayer 0.4.5 — ambos salidos HOY); legado pieza 15 «builds» saldado con fuentes primarias (Rokku r7091 · Hayai r6674); aportes cruzados en p29/30/32/33 (la biblioteca se cose a sí misma). Enlace del pez: 2º fallo, radar sigue. Sin listas nuevas: consolidación.
42. **PUERTA LECTURA I — LA ESTIRPE DEL LECTOR (martes 15-sep, tarde XI):** tachiyomi/J2K 404 (DMCA — la tumba sin página; hilo p16); 12 fichas (Mihon ★23.596 rey, Komikku, Yōkai, Yomihon OCR, Reikai, miko, Aidoku iOS, mihon_img_upscale fork-IA, Manatan híbrido, Komelia, zyddnys ★10.418 el traductor verdadero). Homónimos Kumo a separar. PIEZA 35. Quedan ~150 candidatas Lectura (libros, extensiones).
43. **PUERTA LECTURA II — LOS LIBROS (martes 15-sep, tarde XII):** 8 fichas (KOReader ★29.716, Calibre ★25.908, Librera, Myne→Gutenberg, Kiwix, Book's Story, Tadami, Bookwyrm Android); radares: Aard 2 = 404 (desaparecido silencioso, sin DMCA), EbookConverter, Chaka. PIEZA 36. ~135 candidatas Lectura restantes.
44. **VENTANERÍA DE LA CASA (martes 15-sep, tarde XIII):** pez: 3er fallo (radar sigue); miyomi Anime ABRIÓ (~40 apps del catálogo leídas; chunk 2 pendiente); Mythara identificada (ankurCES/project_mythara ★88 → aporte p33); Kumo: corrección de p35 — la archivada era nubesurrealista, la viva es nardjes5/kumo-surreal ★116 (estaba en el inventario). Abiertas: LA LISTA 16/18 (dueño), canciones, J2K, chunk 2, radares.
45. **VENTANA CERRADA: CATÁLOGO COMPLETO MIYOMI (martes 15-sep, tarde XIV):** Supabase REST con anon key pública del repo (clave NO pegada en documentos — regla 13-sep): 133 apps + 45 extensiones → datos-miyomi/ (apps.json, extensions.json, VENTANA…md — fuera del ZIP). 27 ya fichadas · 106 nuevas (Anime/vídeo, Lectura III, Sótano; Github Store → Tronco). Genealogías fork_of. Tachiyomi consta (10M, víspera DMCA).
46. **VENTANA MCP ABIERTA (martes 15-sep, tarde XV):** github/github-mcp-server v1.12.1 instalado (--read-only, Device Flow firmado por el dueño, token solo en memoria). Ronda: 9/9 fichados vivos en 1 llamada; Kototoro RESUELTO (skepsun→Kototoro-app, mudanza, misma v2.1.3); lección OR en tandas de ~5; Readest ★24.350 → aporte p36. Token vive 2h (keepalive); reinicio = nuevo código.
47. **PUERTA ANIME/VÍDEO I — LA PUERTA GRANDE (martes 15-sep, tarde XVI):** 11 fichas con doble vara (MCP por tandas de 5 + atoms): Cloudstream ★10.677, Seanime ★4.145, Mangayomi ★3.797 (HOY), Nuvio ★3.425 (HOY), Shiru←Miru (declarada), Dartotsu←Dantotsu, DodoStream, AniLabX, Anisurge, Miru (matiz), Dantotsu-vía-updater. Aporte al Tronco: Github Store («Komi Store» 1.9.2 — catálogo atrás). Delegados → Lectura III. PIEZA 37. ~90 candidatas Anime.
48. **BARRIDO DE CIERRE II — «COMO EL AGUA» (martes 15-sep, tarde XVII):** lección 15-sep V (lento-firme, fluido, no controlar todo). 238/238 repos del día vivos, 0 fallas; 2 micro-corrientes corregidas (Houri v1.22.1 en p16, NekoVideo v1.4.1 en p23). MCP dejada caducar (reabrir = 1 min).
49. **PIEZA 38 — EL VIVERO: LOS GERMINANTES (martes 15-sep, tarde XVIII):** regla 9 del Mapa (fruto maduro vs. germinantes — observación, no uso diario). 13 fichas: 2 cadenas certificadas por git (Yomiko←Discord-RPC←TachiyomiSY; houri-hijo←Houri); semilleros Mihon/Komikku; familia Kotatsu declarada por catálogo; Nyora app≠extensión. Piezas: 19 FB/19 WA.
50. **PUERTA ANIME/VÍDEO II — LA BODEGA (martes 15-sep, tarde XIX):** Jellyfin ★57.158 (12.1 DE HOY), Kavita ★11.679, Suwayomi ★7.691 (SyncYomi), Komga ★6.660, Seanime (frontera p37). Linaje Tachidesk→Suwayomi→Tachimanga cerrado. PIEZA 39. Piezas: 20 FB/20 WA.
51. **PUERTA LECTURA III — EL ESTUDIO (martes 15-sep, tarde XX):** 12 fichas de escritorio + invitados: anx-reader ★8.853, Thorium ★2.870, OpenComic ★1.969, YACReader ★1.373, Yomikiru ★552, FMD2 ★1.138 (←FMD), koharu ★5.561 (0.83.1 DE HOY; mudanza a koharu-rs), IReader ★938, LNReader ★2.834 (mudanza a lnreader), QuickNovel ★1.820, Openlib ★2.475, Paperback ★782 (casa dividida). Piezas: 21 FB/21 WA.
52. **VENTANA MIYOMI COMPLETA (martes 15-sep, tarde XXI):** 133 apps → 65 fichadas / 68 pendientes (59 verificadas HOY). Migu y Venera-madre archivadas; madres fuera del catálogo (TachiyomiEH, AniHyou-android); fork-de-fork Nekori←tsundoku; NovelDokusha renombrada; Hentoid/Hayase API 451. Acta en datos-miyomi/INVENTARIO DE PENDIENTES (fuera del ZIP). Piezas: 21 FB/21 WA.
53. **PUERTA ANIME/VÍDEO III — LOS CAZADORES (martes 15-sep, tarde XXII):** 15 fichas de la cola Miyomi (2 líneas: ≥500★ y 200–500★). JHenTai ★5.535 · AnymeX ★1.203 · NineAnimator ★819 · Zenshin ★767 · OtakuWorld ★630 · Skystream ★575 (hija de CloudStream) · +9 de segunda línea. Catálogo atrás ×5. Piezas: 22 FB/22 WA.
54. **BARRIDO DE CIERRE III + REPASO GENERAL (martes 15-sep, noche XXIII):** 277/277 repos vivos (0 muertos, 0 bloqueos, 0 fallas) · 33 releases de HOY cuadradas · sin corrientes nuevas. Cuenta: 42/50-80 pubs; colas listas (pequeños, Sótano II, novelas, Venera, extensiones, web-451); ~53 pendientes de catálogo (80/133 fichadas); viejos intactos. Piezas: 22 FB/22 WA.
55. **LA FOSA — SÓTANO II (martes 15-sep, noche XXIV; lección 15-sep VI «lo profundo del mar; si hay uno, hay dos», Cabral cotejado):** 8 fichas del fondo (stump ★2.696, Houdoku corregido, ComicRack CE, Unyo, toru, Frank Yomik — gemela de koharu, Moku, Emaki) + cadena de 5 generaciones (EH→AZ→SY ★4.146→RPC→Yomiko) + corriente de extensiones 40/40 vivas. Migu ARCH al Registro. Piezas: 23 FB/23 WA.
56. **LA CORRIENTE — EXTENSIONES (martes 15-sep, noche XXV):** 45 ext → 38 repos fuente (38/38 vivos, 26 push HOY, 8 sin casa al radar). Keiyoushi/yuzono×3/Secozzi/Suwayomi/Aidoku-Community/inkdex/LNReader-plugins; acequias ×9; idiomas fr/pt-BR/zh; Shebyyy y TheNetsky en dos cuencas; Kavita bodega-fuente. La ley: el río fluye por commits. Piezas: 24 FB/24 WA.
57. **LOS PEQUEÑOS (martes 15-sep, noche XXVI):** 13 fichas menudas con casa viva: tele (NyanTV, Sozo TV), bolsillo (ReDantotsu remake declarado, AniSync, NHApp, kaizen, Sozo, Nekoyomi 0.20.6, uwumi, Kitsu-X declarada, KomaStream), Sozo-Read (Spyou ×2), KamiYomu self-hosted. Familia Sozo ×3. Piezas: 25 FB/25 WA — faltan 5 para el mínimo.
58. **LAS CANCIONES — LA VOZ DE AMÉRICA (martes 15-sep, noche XXVII):** Los de Las Condes (musicapopular.cl; «El corralero», LP 1966, 4 LPs) + Mercedes Sosa (letras.com, 411 canciones, top 15 con autores verificados — «Todo cambia» de Julio Numhauser). Ratificadas con enlace: «Sólo le pido a Dios» y «La maza» (6 de 8 pendientes). Sin letras verbatim. Piezas: 26 FB/26 WA.
59. **CIERRE DE PENDIENTES (martes 15-sep, noche XXVIII):** p30 «Once fichas» · p04 TOC alineado · LA LISTA con nota fechada (título: decisión del dueño) · 8/8 canciones con enlace verificado (letra y crédito constados) · pez cerrado (404 constatado) · hilo J2K cerrado (Yomiko = línea SY). Archivos sin pendientes salvo la palabra del dueño.
60. **ADOPCIÓN DE LAS OCHO CANCIONES (martes 15-sep, noche XXIX):** 4 ADOPTADAS con columna: porqué (Sólo le pido a Dios), identidad (Man in Black), protocolo (Lean on Me), método (La maza — «la maza sin cantera» = el cotejo). 4 FAMILIA AMPLIADA: Jara, Buarque, Cooke, Dylan. Tratado intacto. Piezas: 26 FB/26 WA.
61. **LECTURA IV + ÚLTIMA PUERTA + CLASIFICADOR (martes 15-sep, noche XXX):** p46 «La sala de las novelas» (6 fichas; LNCrawler reclasificado descargador) · p47 «La última puerta» (Venera + remanentes + VEREDICTOS: Hentoid y Hayase muertas por DMCA constatado) — CATÁLOGO MIYOMI 133/133 CERRADO. Clasificador general v1 (rango y clase, ~330 repos + 12 canciones). Lección 15-sep VII (Mayuri). Piezas: 28 FB/28 WA.
62. **LA V25 VUELVE + BARRIDO DE LOS 683 (martes 15-sep, noche XXXI):** archivo reconstruido ×4 idiomas (1.008 filas contadas; 940 identidad; multi-forja) · 683 repos nuevos 683/683 barridos 0 fallas (R1 434/R2 167/R3 78; Dantotsu y OpenTune 451; CuxPlug E) · Anexo V25 al Clasificador · p37 con confirmación Dantotsu. **PIEZAS 48-49 → 50 FB + 50 WA: MÍNIMO ALCANZADO.**
63. **LA DISCOTECA I (martes 15-sep, noche XXXII):** 231 fichas de música de la V25 → 186 nuevos → 186/186 barridos 0 fallas (118 R1). 12 fichas HOY: echo ★3.531, Flow ★2.212 (familia InnerTune), azusa ★1.364, Audile ★1.322, BitChord ★1.176, Rush ★1.023, lissen ★733 + 5 artesanos. Homónimo Futon detectado. Piezas: 31 FB/31 WA.
64. **LA DISCOTECA II (martes 15-sep, noche XXXIII):** Finamp ★4.261 (el más grande de la mina; mudanza jmshrv→finamp-app, v0.9.25 HOY en ambos) · Jellyfin Android ★2.764 · +9 fichas (PixelPlayerOSS, InternetRadio, anti-vocale, Podcini.A+UT.urn, flac-r, OmegaPlayer, mafik/echo homónimo). Mina: 163 restantes. Piezas: 32 FB/32 WA.
65. **LA VIGILIA MASIVA (martes 15-sep, noche XXXIV):** el 1.008 de la V25 CONTESTADO AL 100%: p52 discoteca III (163), p53 otras forjas (89 sondadas), p54 sistema (102), p55 lector/bibliotecas (207), p56 anime/servidores (186). 25 fichas nominativas + 951 censadas. Piezas: 37 FB/37 WA (57+57 totales).
82. **HORNADA C — MÁS MASIVAMENTE: 48 DE UNA VEZ (15-sep, noche):** piezas 30–74 y 76–78 adaptadas a Discord dominicano-ES tras verificación previa (34 existentes: 0 problemas). El peine gemela real FB↔Discord cazó desvíos de la médula truncada: 22 reescritas con los datos reales de sus gemelas (V25 1.008 · barrido 683 · censos 163/102/207/186 · forjas 136 · 7 ceros · actas 451 · LA LISTA con meme original) + 4 parches (OpenMinis ★4.485 · Mihon ★23.596 · Komikku ★4.720 · Tadami ★55 · Komga ★6.660). Re-peine: gemela 48/48, formato 0, TSV limpio. Discord dominicano-ES COMPLETO: 00–79 + pieza 80 = 81 piezas. Registro #80. ZIP 101ª (378 miembros).
81. **HORNADA B — 20 EN 20 (15-sep, noche):** piezas 10–29 adaptadas a Discord dominicano-ES con el molde de casa; valores stale escritos corregidos desde la casa y sincronía fina completa vs TSV; 0 índices, 0 P10, sin párrafos compartidos. Discord dominicano-ES COMPLETO en su primer bloque (00–29 + 75 + 79 + 80 = 33 piezas). Sigue: 30–79 (Hornadas C–H) y las demás plataformas/lenguas. Registro #79. ZIP 100ª (330 miembros).

80. **HORNADA A — LA OBRA GRANDE ANDA (15-sep, cierre):** 10 piezas 00–09 adaptadas a Discord dominicano-ES con el molde de casa y el censo de la noche; sincronía fina vs TSV; residuos fuente p06/p08 corregidos con gemelas; 0 índices crudos, 0 P10, sin párrafos compartidos. Sigue: Hornada B (10–19 → Discord) y las demás plataformas y lenguas. Registro #78. ZIP 99ª (310 miembros).

79. **REPASO EXTENSO DE ÓRDENES (15-sep, cierre):** aviso del dueño — el árbol multiidioma está vacío frente al alcance real de #66 (80 listas × plataformas × 7 lenguas; pendiente 2.569–2.689). Emitido el documento de protocolo «Repaso completo de las órdenes — interpretación extensa» (40 órdenes al máximo, 7 cacarones, regla nueva, plan de hornadas). Ficha 76 · Lección VIII. Registro #77. ZIP 98ª (300 miembros).

78. **EL MAPA AL DÍA (15-sep, cierre):** aviso del dueño — la lista 00 quedó con la foto de la tarde. Corregido: p00 con «Corte de hoy» extendido (censo 560 · Riffle/Debrify · Tadami-org · Nuvio-Play) + nota fechada «el mapa al día»; p23 lista Debrify en su árbol; p36 anuncia Riffle en el suyo. Gemelas incluidas. Registro #76.

77. **CIERRE DEL DÍA (15-sep, 5:15):** última verificación de integridad sin red: 0 hallazgos (ZIP↔disco byte-a-byte, hashes del LEEME, gemelas 80/80, 299 miembros, sin token ni residuos del 14). El día cerró con las actas #71–#74. ZIP 96ª = entrega final del 15 de septiembre. El dueño descansa.

76. **PROFUNDIDAD EXTREMA — 404 REALES RESUELTOS + BÚSQUEDA GLOBAL (martes 15-sep, noche):** los tres «404» del censo eran: 2 placeholders de p75 traducidos (corregidos en prosa propia en EN/HI/FR/RU/zh con nota fechada) y 1 puntero truncado de la cita del README de TWRP en p65 (TeamWin viva: twrp.me 200, android_bootable_recovery ★1.712; la cita se completó y se actó). Las 8 bloqueadas por tasa: todas vivas una por una (560/560 casas resueltas). Noticia global: Nuvio suspendido de Play el 8-sep (DMCA/MPA; casas vivas, apps falsas en Play) → actas en p37/p56/p64/p74. p74 coma→punto. Registro #74.

75. **VERIFICACIÓN FINAL MASIVA (martes 15-sep, noche):** 560 casas citadas raspadas en vivo y en paralelo (estrellas/releases/push; la cola bloqueada por tasa re-abierta con paso lento): 545 vivas, 122 con señal de HOY, censo detallado en datos-censo/verificacion-viva-2026-09-15.tsv. Motor pieza-vs-casa: 5 correcciones reales (Levyra ★294, OwnTV ★428, DreamPlayer v0.4.6, KillMyApps v1.6, Dextop ★238) + 2 sitios propios 404 actados (docs de Kototoro en p02, sitio de Omnify en p01; casas vivas). 37 dominios externos barridos (6 muros anti-bot documentados). Batería anti-bacteriana molecular en 286 archivos: 0 hallazgos; gemelas 80/80. Registro #73.

74. **RECTIFICACIÓN TADAMI + FICHAS RIFFLE/DEBRIFY (martes 15-sep, noche):** el dueño corrigió el acta — Tadami VIVO: andarcanum ★260, v0.62 (12-sep), push 13-sep; el 404 era del slug muerto anandnet; error de atribución rectificado fechado en p02/p06/p13/p19; nueva org tadamiorg/tadami (★56). Fichas nuevas por enlace del dueño: Riffle (pkmetski/riffle ★15 · v2.44.3 · push HOY · Audiobookshelf/Storyteller · REQUEST_INSTALL_PACKAGES constado en manifiesto) → p36; Debrify (varunsalian/debrify ★516 · v0.9.2-alpha.1 de HOY · AGPL-3.0 · debrify.tv · une debrid/WebDAV/IPTV/Stremio/YouTube) → p23. Registro #72.

73. **MUDANZA 00–19 — LA HORNADA DEL 14 VIVE EN EL 15 (martes 15-sep):** mandato del dueño («actualizado, verificado, reescrito y movido a 2026-09-15»). 20 piezas (40 con gemelas) actualizadas y re-verificadas contra las casas a HOY: Mihon ★23.601 (push HOY) · Komikku ★4.721 · SY ★4.146 · Neko ★2.792 · Anikku ★1.032 (+r8932 HOY) · Aniyomi ★7.683 · Keiyoushi ★14.980 · Yūzōnō anime ★432 · manga-repo ★445 · Kototoro v2.1.3 de HOY · Chimahon v2.4.2 de HOY · Yomikai 1.9.84 de HOY · Houri v1.22.1 de HOY · Usagi ★257 viva · Kotatsu ★8.855 · AppManager ★8.985 y OrganicMaps ★15.427 (push HOY) · SimpMusic ★11.257 · Metrolist ★12.789 · **TADAMI: casa 404 a HOY (acta en p13; el espejo no es el repo)** · N-Zik dev v8.0.0 de HOY. Serie 00–79 unificada bajo el corte del 15; hornada 14 archivada en archivo/ (fuera del ZIP). ZIP 92ª.

72. **HIGIENE FINAL — SIN METADATOS DE IA, LISTAS SUELTAS, LEGIBLE (martes 15-sep, tarde):** barrido de 286 archivos (metadatos IA, rastros de asistente, frontmatter, comentarios HTML, invisibles, mojibake, listas pegadas, plantillas, ZIP comments): **0 rastros de IA reales** (las menciones Gemini/DeepSeek/🤖 son contenido periodístico sobre terceros); 3 defectos de legibilidad reparados con nota fechada: p59 censo con clase vacía (recalculado), p71 separador suelto, p58 doble espacio citado. Correcciones sincronizadas a gemelas.

71. **ÚLTIMA TAREA — MAPA DE EXTENSIONES FAMILIA (martes 15-sep, tarde; SOLO Discord Miyomi):** pieza 80 en discord/dominicano-ES — Mihon ×8 · Aniyomi/Animiru/Anikku ×8 · Mangayomi ×5 · Kotatsu/Usagi ×7 · Stremio ×6; 18 duplicados con la web, 3 desactualizados (kodjodevf archivado, Kohi-den caído, Aniyomi sin desarrollo), 7 candidatos 🆕. Investigación: 18 casas raspadas HOY; índices crudos jamás pegados (#13).

70. **REPASO GENERAL DE ÓRDENES + AMPLIACIÓN ALMENDRA (martes 15-sep, tarde):** auditoría total 0 hallazgos; repaso #23-#67 actado (pendientes solo de frontera p77). Anexo doctrinal «Ampliación al Tratado — las canciones de Almendra»: letras.com/almendra 38 canciones constadas; 8 adoptadas (Muchacha, Que el viento, Fermín, Plegaria, A estos hombres, Color humano, Camino difícil, Pototo); 0 letras verbatim; V.0.03 intacta (G-004).

69. **MATRIZ MULTIIDIOMA COMPLETA (martes 15-sep, tarde):** hornadas 2-4 — p79 en Discord/Reddit/XDA ×7; p75 FB/WA en fr/hi/zh/ru; p75 Telegram ×7 y Rethubs ×7 (formatos propios: canal y tema fijado). Matriz p75 completa: 5 plataformas × 7 idiomas. QC nano-molecular: 0 hallazgos (Telegram ×6 líneas localizadas en QC propio). Árbol 04-: 118 archivos.

68. **VERSIONADO MULTIPLATAFORMA — HORNADA 1 (martes 15-sep, madrugada XXXV):** guía de versionado (7 plataformas × 7 idiomas, anti-descarrile) + árbol 04-VERSIONES-MULTIIDIOMA + 25 piezas de p75 «El podio» (Discord ×7 · Reddit ×7 · XDA ×7 · FB/WA en-US/pt-BR). Top-20 deduplicado (ente ×2 espejo; ImageToolbox=ImageResizer renombrado; +Operit/NewsBlur). Comunidad: 4.198↑ en seis casas (Discord/WA/FB/Reddit/Telegram/Rethubs).

67. **EL TECHO DE 80 (martes 15-sep, madrugada XXXV):** vara repasada (351 re-raspeados; podio nuevo: llama.cpp/immich/sing-box/SmartTube; 7 ceros verdaderos). Piezas 63-79: segundas filas ×6 · forjas por API ×2 (14 versiones constadas) · ceros · actas · libro de nombres · vivos · podio · recuento · frontera · LA LISTA · la octogésima. Forjas reconstruidas: 136 URLs; p53 corregida fechada; ANEXO FORJAS al Clasificador. TOTALES: 80 FB + 80 WA (00-79). Frontera anotada en p77 (sin acumulación).

66. **HORNADAS NOMINATIVAS DEL TECHO (martes 15-sep, madrugada XXXV):** 6 hornadas top-estrellas por clase (p57 Lector · p58 Anime · p59 Taller · p60 Bibliotecas · p61 Servidores-raspado · p62 Ayudantes). API 403 → raspado de casa (54/54). awesome-selfhosted ★319k (etiqueta catálogo); Tweaker ★1.733 (radar ✓). Piezas: 43 FB/43 WA (63+63 totales; faltan 17 al techo).
83. **MEGA-ORDEN — FASE es-DO COMPLETA (noche):** 472 piezas nuevas en `04-VERSIONES-MULTIIDIOMA/` — Reddit 78 + XDA 78 + Telegram 79 + Rethubs 79 + FB 79 + WA 79, cada bloque con verificación de apertura y de cierre (gemela numérica por pieza, ventanas anti-copypaste, repos contra el TSV). FB/WA = gemelas byte a byte del canon `03-PUBLICACIONES-2026-09-15/` (SHA-256 80/80). Discord dominicano-ES (81 piezas, HORNADA C) es la fuente madre de todas. Pendiente: 6 lenguas × 5 plataformas (3.300).

**BORRADORES: falta lectura y firma humana de Alexis. Sin firma no hay envío.**

## Cómo está organizado

**00-DOCTRINA/** — Tratado V.0.03 + V.0.02 + Manual (con §5.4) + Fichas + Edición Completa + Prompt
**01-REGISTRO-Y-PROTOCOLO/** — Handoff + Lecciones + Dossier Fila 2 + Registro de verificación
**02-EJEMPLOS-Y-ARCHIVO/** — Carta + Lecciones extraídas + Auditoría
**03-PUBLICACIONES-2026-09-14/Facebook/** — 20 piezas
**03-PUBLICACIONES-2026-09-15/Facebook/** — 60 piezas (Biblioteca: plano + cosecha 21-79, techo)
**03-PUBLICACIONES-2026-09-15/WhatsApp/** — 60 gemelas
**03-PUBLICACIONES-2026-09-14/WhatsApp/** — 20 piezas

## Regla de oro

El asistente redacta borradores; **la firma es humana o no hay envío**. Cada enlace se abre el día en que se usa. Las piezas públicas van limpias; la verificación se registra aparte (Manual §5.4). No se pegan nunca: índices (index.min.json / index.pb), JWT/anon keys, URL de JAR, APK de mods stores, Discord de envío, URL de clon TMO.

## Huellas SHA-256

### 00-DOCTRINA/
- Ampliación al Tratado — las canciones de Almendra (15-sep).md — `2f258ac477393fa8b47b395532a5e3d99eb42acaf26c9a125462d8eb176f8b7c`
- Manual de Campo La Bandita — Edición Completa.md — `47f905d16337b6ea52870d199759ab08901f7c4de383906d99b9161d07329c05`
- Manual de Campo La Bandita — Fichas de Fallos (Uso Diario).md — `01f751b8c4c42b6bcce5845336eb1b3b299b9dc19f06110d99961ed278af8758`
- Manual de Campo La Bandita — V1.0.md — `0fd019e9f7f6fb66a2eba7d436b9801c6c3ef5fa9ce29f66a394a7281395be63`
- Next Tratado Bandita Open Source — Fusión Universal V.0.02.md — `239e22d67cbf6f03bb9a81f3e18878a55bca256f487a9e0925c3942bf080a0ae`
- Next Tratado Bandita Open Source — Fusión Universal V.0.03 (Edición Corregida).md — `79864a4edf0403770ce1ef308bc01fee72e85e898bad18e929daf92d6de63e59`
- Prompt de Concientización — La Bandita V1.0.md — `9ec203cc57c393dd3bfb63f9746190afc92d121fe20576d05fea589143851b97`

### 01-REGISTRO-Y-PROTOCOLO/
- Clasificador general de la Biblioteca — rango y clase (15-sep).md — `388aac5b10de7a3e0577fbe4ba7c5683d35b9c0f3c47424f011d095e965170cb`
- Fila 2 — Dossier AniZen.md — `34ffa67fb4ad83ed0d387df036e26d597ae23cad4e01cf348e8af305fc50cd6a`
- Handoff de Sesión — La Bandita 2026-09-10.md — `6a85c9e931152ad4290aa68649d45f7e69075c1c614edc9fb9e5e6c0f0b12470`
- Inventario V25 — 1.029 fichas (fuente del proyecto).md — `c8d4b08e489c6834082200cd077d181b429dd7467f9b8cd464aa9dd4f147f21b`
- Lecciones de Alexis — para recordar entre sesiones.md — `0f77c4a79ef568588c2b60abcb7cf586ef7a91d98002efb94dbb9d6850323bc0`
- Mapa de la Biblioteca — proyecto 50-80 (2026-09-15).md — `c8e0390a08113ac4407c659dd5d9cd501072abcfd55a8acc6922ad93f58a042a`
- Registro de verificación — publicaciones 2026-09-14.md — `708f71d3ee468afe66dac2665132dab3b4672c7db5383669f987343f47a15634`
- Repaso completo de las órdenes — interpretación extensa (15-sep).md — `cceea30aaa08cde60f53c2443a6f111120449dd71192e1e98f839f92dca56e73`

### 02-EJEMPLOS-Y-ARCHIVO/
- Auditoría del volcado 2026-09-13.md — `7c39c551b9856054c3a35f7dcea4ea3eb30909ff664009eb0e51d58895994df4`
- Carta a La Bandita — Regreso a la Confianza (ejemplo).md — `530a0a0e2b3d4babb270b7dd93ffecc00e6b8df107f14885170e8978c06576b5`
- Lecciones extraidas de textos personales (archivo, no norma).md — `5c47ef0d0e01b422c82a88be05bb05ca85e68d350ffd9ad7d17cb9722abab462`

### 03-PUBLICACIONES-2026-09-14/Facebook/

### 03-PUBLICACIONES-2026-09-14/WhatsApp/

### 03-PUBLICACIONES-2026-09-15/Facebook/
- 00-LA-LISTA-ecosistema-libre-en-16-guias-Facebook-La-Bandita-2026-09-15.md — `fdce55412d0887b369bec2b72062e2ff0cb878f3afd2a9b0a01fdac7ef0324aa`
- 01-Tiendas-APK-legales-mods-reloj-2027-Facebook-La-Bandita-2026-09-15.md — `b100c56d36aa7507c90e7c1b82825cb44e06c93097399488c709346f103c61e0`
- 02-Kototoro-manga-novelas-video-Facebook-La-Bandita-2026-09-15.md — `bca6dbc90f83ad9b72ba60ff77dc72563b31df2a7583f9bbf3677c67dbd524a2`
- 03-Verificacion-Desarrolladores-hito-30-sep-2027-Facebook-La-Bandita-2026-09-15.md — `39e433e4e0b20a6a9a8bee1f42779ec49dd6e5e78941946d3d7da2367418d4c6`
- 04-Extensiones-tres-arboles-hubs-parsers-Facebook-La-Bandita-2026-09-15.md — `e7b90b8737d962c9fa333cad2fbe4ffc416a1a2a6f143c66f171c67052828f01`
- 05-TMO-caida-clones-no-iniciar-sesion-Facebook-La-Bandita-2026-09-15.md — `8b9023146012796099b6bef50b24381bda9da29f59d4ff3553dc1bb558b8b539`
- 06-Forks-lectores-Mihon-Aniyomi-segundas-generaciones-Facebook-La-Bandita-2026-09-15.md — `8b32c55a17907738b20d6cc4ea928f7b0e31971c79eb98881d3b2c3880957113`
- 07-Usagi-viva-cadena-Kotatsu-Yukimi-Usagi-Facebook-La-Bandita-2026-09-15.md — `6eb67aed56d0973e1ee7f478712fdea8050630c9bbc028fffd9573be002523f5`
- 08-Musica-FOSS-clientes-con-repo-Facebook-La-Bandita-2026-09-15.md — `17b9831f15df176e2969638aca1b4bd9d84cc5727fc08646f1c584fc07ddb037`
- 09-Herramientas-FOSS-caja-de-oficio-Facebook-La-Bandita-2026-09-15.md — `074f0f845c62a97bd5691bdc6fcbb1173ea6aa796df9492fa7e4b083622d721b`
- 10-GLTools-no-se-receta-spoof-GPU-Facebook-La-Bandita-2026-09-15.md — `92830e7241501560c5e80fbcca8d6353c1c1b3db439aa06171e6c5f021114286`
- 11-AniZen-vivo-issue-no-enviado-Facebook-La-Bandita-2026-09-15.md — `e280f35e70a1d847dd412c0133423c492e9cd6b77a9b5ccb4b7104f614f3773d`
- 12-FMHY-wiki-de-pistas-no-catalogo-Facebook-La-Bandita-2026-09-15.md — `804889096d1ea68c2764be3dc12244ed256394195e428c1a5169d78c74eeb604`
- 13-Rama-Aniyomi-Animetail-anime-y-manga-Facebook-La-Bandita-2026-09-15.md — `9e4b14bb9ce030cc56775cffc40a6798d7451bbf2525a7a8afd3cdf174a866a8`
- 14-Rama-Animiru-Anikku-anime-puro-Facebook-La-Bandita-2026-09-15.md — `5ec49f4ff907b173709a42f69f999187a4b2f30838d90693afea24ce28000eb7`
- 15-Rama-TachiyomiJ2K-Yokai-Rokku-Reikai-Hayai-Facebook-La-Bandita-2026-09-15.md — `b3ec4c34c7fb6779913399f8ed2f22f06a4dc6d459359fd406e44076ac93333f`
- 16-Rama-TachiyomiSY-Komikku-Facebook-La-Bandita-2026-09-15.md — `ef547c004931eee2e45bf33a0f0f8fffd4b635e865b4e37d6cee8058be7baab1`
- 17-Capa-inmersion-Chimahon-Hoshi-Yomikai-Yomi-Koharia-Facebook-La-Bandita-2026-09-15.md — `8dbd63ac5321b45a7e66683f15183e8abfbea18a8cb71a60d59d40d2781a6cd3`
- 18-Libros-OpenlibExtended-cliente-Annas-Archive-Facebook-La-Bandita-2026-09-15.md — `f5ffc6022663f5e886692614fc9d66a3d2aaf116fd3a363c1482db7cfd7123f4`
- 19-Panorama-multi-anime-manga-novelas-Facebook-La-Bandita-2026-09-15.md — `b91b66d1806bc42ac339d9916287329ddb1ff04feb4b35182714cb8be0e5c612`
- 20-La-Biblioteca-plano-75-publicaciones-Facebook-La-Bandita-2026-09-15.md — `890cc954e5f2d0cc7faa9672c9b0f556187b9b497757007dcf9216a888b47c8b`
- 21-Musica-I-cosecha-del-muro-12-vivas-Facebook-La-Bandita-2026-09-15.md — `5aac38816f0972902569cddc3b8261f4d5315752fc124e89cd033da5764c8e87`
- 22-Lectura-II-la-repisa-del-muro-Facebook-La-Bandita-2026-09-15.md — `745acd47cc18fe4051c9ca82d72690bba2792169f3d20be06889f38f82248092`
- 23-Sala-del-muro-IPTV-Jellyfin-reproductores-Facebook-La-Bandita-2026-09-15.md — `b66d0efad6d3c2f1a75ebf347b5053e5b2355c728e99d8f2cd0d71c265fd0c46`
- 24-Taller-del-muro-Shizuku-root-sistema-Facebook-La-Bandita-2026-09-15.md — `bf6b303938edcf2d440c7fd90c7e7a31b13254f119c9b3d8d93e378562bdc311`
- 25-Sotano-del-muro-servidores-autoalojamiento-Facebook-La-Bandita-2026-09-15.md — `5745e934002f12770dbe063662455c5644f1f1d1fc87081e63ee57b385770ad4`
- 26-Cajon-del-muro-privacidad-parsers-miscelaneo-Facebook-La-Bandita-2026-09-15.md — `f3747c364201f10dd164ca8689773762124ee78913db933f12319c0d8b76af0c`
- 27-Musica-II-las-sucesiones-Facebook-La-Bandita-2026-09-15.md — `14bfce12082f3457d8ec7198b8d4e98e7a33f63797b506a5055a0e6d08683815`
- 28-El-tronco-raiz-gestion-y-tiendas-Facebook-La-Bandita-2026-09-15.md — `581c3925423b748df5f686584502a3151fc31e344091c38a7d1f4c31c12b8dcf`
- 29-Los-mayordomos-gestores-perfiles-bloat-Facebook-La-Bandita-2026-09-15.md — `61d63c7152c3dc10ff040bc4fdca5964bc47b8174a2233c457063e4266e6152e`
- 30-La-cara-del-sistema-lanzadores-teclados-Facebook-La-Bandita-2026-09-15.md — `ce540ba2c482f66835585a10e2c8126bbbb974c8cc55e825549a5a1500092014`
- 31-Los-pequenos-del-sistema-Facebook-La-Bandita-2026-09-15.md — `6ac5b730886f5aa37263e5620ef32f4294cd8300ba843826e98da32b6b64c89c`
- 32-El-cable-y-el-escudo-Facebook-La-Bandita-2026-09-15.md — `4c280e7486f42095cabf2b0d45d6877e13128f1c181d4295888efcb9ec6968c9`
- 33-Los-archivos-del-taller-Facebook-La-Bandita-2026-09-15.md — `d1a4123a0df89a9f0801fc4fb3b1cf08b2d2361bc80828945562d71fb7a0c03b`
- 34-Los-que-tenian-otro-nombre-ambiguos-Facebook-La-Bandita-2026-09-15.md — `b7da9441284e0bc0e04a8ce50d56f9614bcdb31e2dc6b5c512351ee1858c9317`
- 35-La-estanteria-la-estirpe-del-lector-Facebook-La-Bandita-2026-09-15.md — `1f549301fdb1ddfcac660603c665f76840f7ec4b8b0c915b718ea260692aac3a`
- 36-Los-libros-biblioteca-de-bolsillo-Facebook-La-Bandita-2026-09-15.md — `83c9aa7226fd3e0b4eb23421b6f4e98cd6e43dd76f942ace4c2aadbd07db5a0b`
- 37-La-puerta-grande-anime-video-I-Facebook-La-Bandita-2026-09-15.md — `896194a0e74778cf2e9a4952afb10b3fd2a21e49491022274769284fe7d2d283`
- 38-El-vivero-los-germinantes-Facebook-La-Bandita-2026-09-15.md — `28bbd5a3379fc513d81b4c9339d3b5a5d06dc97f78846ee334ec35e9836d59ed`
- 39-La-bodega-servidores-y-bibliotecas-Facebook-La-Bandita-2026-09-15.md — `5f496f87e89e9de750762ae6134f444afa1441df18a46380b66e9f7ab0737c73`
- 40-El-estudio-lectores-de-escritorio-Facebook-La-Bandita-2026-09-15.md — `b3bd4aa25ae1404d91f294f49a215a08dd3bfb6124037b427e9e9a31455284bf`
- 41-Los-cazadores-anime-y-video-III-Facebook-La-Bandita-2026-09-15.md — `983ca57a3b86ad8feb189951fde521c9c03be388cb16bf8c088864c3130d60e2`
- 42-La-fosa-el-sotano-II-Facebook-La-Bandita-2026-09-15.md — `4368e5b71ba203d40b8efe382f33879a50bf20c31c847d9b25eeb2629d0f0f1d`
- 43-La-corriente-geografia-de-las-fuentes-Facebook-La-Bandita-2026-09-15.md — `1b7d7eb27779855002e2c2f84482ccd5481c3b095179b35993202e15765d3d8e`
- 44-Los-pequenos-las-casas-que-no-hacen-ruido-Facebook-La-Bandita-2026-09-15.md — `71cd01f9aa0c0930f2fac698f5e832066a0f8c49b8c611e3a67ce6d1314e3d2e`
- 45-Las-canciones-la-voz-de-america-Facebook-La-Bandita-2026-09-15.md — `99150b9339b213feb56c7734454e115bc14adfd805f33a4386453c1ea5a80196`
- 46-La-sala-de-las-novelas-Facebook-La-Bandita-2026-09-15.md — `8c3a89c0dd3fc71dccc3ab2932121471dbcb7862181d7c0e035cb2872575c999`
- 47-La-ultima-puerta-del-catalogo-Facebook-La-Bandita-2026-09-15.md — `9dbd295366601e387e56df150e0eeeb85e6b88a6eb0a030b6d0239a08c01e8a5`
- 48-El-archivo-la-V25-vuelve-hecha-mejor-Facebook-La-Bandita-2026-09-15.md — `bb2860245070c15a7bd9363359738459a46744ec65b6c4e1fc8f46f82a97b4e2`
- 49-Las-mil-puertas-el-barrido-de-la-V25-Facebook-La-Bandita-2026-09-15.md — `e158eb9425a84d2de726a5fdf8e959b5a4234ed6f8bef599297bfa1440a11e7e`
- 50-La-discoteca-I-la-mina-de-las-231-Facebook-La-Bandita-2026-09-15.md — `76a1e85ae1af167550f00a30280dd7b966f93cda81b573f2bf4b5a65d07fa137`
- 51-La-discoteca-II-el-jugador-grande-y-la-mudanza-de-Finamp-Facebook-La-Bandita-2026-09-15.md — `5ce59041a374100ef1d288c1063e07a2ca146bd85d9faef6ea38da9db0c598b0`
- 52-La-discoteca-III-el-censo-completo-del-baile-Facebook-La-Bandita-2026-09-15.md — `ab6e944dfb02005d9f6aa7181e273456db3423dd6e27683b48d2ccda033aa62a`
- 53-Las-otras-forjas-gitlab-codeberg-y-los-sitios-Facebook-La-Bandita-2026-09-15.md — `ffea6b089c7c1f5588d3d1b2d513850cdcd0230e1eb3088e675c961db45b245b`
- 54-Las-puertas-del-sistema-y-el-taller-de-la-mina-Facebook-La-Bandita-2026-09-15.md — `8ec271980fd6fb0f229c021bdec58f86f337f33379b99975bbdf5f2e3e678e49`
- 55-Las-puertas-del-lector-y-las-bibliotecas-de-la-mina-Facebook-La-Bandita-2026-09-15.md — `c653eeeaa607c0a152eb9638e28583abb5d53f86e80ba8944313c65574c4c111`
- 56-Las-puertas-del-anime-y-los-servidores-de-la-mina-Facebook-La-Bandita-2026-09-15.md — `aab5a7a2714eb8e149f8ca8aa47782b792af848f13d61840a521931c6d65d150`
- 57-La-hornada-del-lector-la-mina-con-nombre-Facebook-La-Bandita-2026-09-15.md — `3542e60e2f54d9fac25ea65d5d226719f16c0e9fffb3ab17f90e603ef3d2a877`
- 58-La-hornada-del-anime-el-segundo-territorio-Facebook-La-Bandita-2026-09-15.md — `9d366d23c08d7273d8130af8b902dd7d16e9b26bcf0aed5190beaa76e4092abf`
- 59-La-hornada-del-taller-herramientas-de-la-mina-Facebook-La-Bandita-2026-09-15.md — `a3025ae63fb7ed9411d139fc5ccb53e86f54b83cf93de92c62c00e2d5147ec30`
- 60-La-hornada-de-las-bibliotecas-los-ordenadores-de-la-mina-Facebook-La-Bandita-2026-09-15.md — `8acd8930deb17742ce30dd64a1dbad2ae31807240aa9e346f8084256f0928bb2`
- 61-La-hornada-de-los-servidores-el-sotano-de-la-mina-Facebook-La-Bandita-2026-09-15.md — `1eb8b1d42fe132bc604ca6d0fed349756c7df45836e09e44ef26ba8946642718`
- 62-La-hornada-de-los-ayudantes-los-pequenos-del-censo-Facebook-La-Bandita-2026-09-15.md — `0ad060fd565fe8a8f935568beac313d7c79d2cbd7bc9ee25c3f955e7604e2bb0`
- 63-La-segunda-fila-del-lector-Facebook-La-Bandita-2026-09-15.md — `ec5fa79c17cd88781c6f1532ce73a0747f57a9256972c912e436bc6723367292`
- 64-La-segunda-fila-del-anime-Facebook-La-Bandita-2026-09-15.md — `7e0a1467f2eae46b83328eafe2a738f344bca97baf53e8744fc018856e112b5a`
- 65-La-segunda-fila-del-taller-Facebook-La-Bandita-2026-09-15.md — `c79ce4ece79b83b19aa4144fb3204a698310115e73f3cca8488e9eb898f264d8`
- 66-La-segunda-fila-de-las-bibliotecas-Facebook-La-Bandita-2026-09-15.md — `c77857076d6c07f6cb9bf7e83527962636f01ea7ac94e35fb461e429c1acf694`
- 67-La-segunda-fila-del-sotano-Facebook-La-Bandita-2026-09-15.md — `230a65934ec028f46170646eee5e2121ee6cc84597630c1f4af9e19b6af5a802`
- 68-La-segunda-fila-de-los-ayudantes-Facebook-La-Bandita-2026-09-15.md — `74306b81e34ee79202bd3dbdccaf9c06e1e433e41f87e58a287f00baea1dda19`
- 69-La-vara-de-las-forjas-I-gitlab-y-codeberg-Facebook-La-Bandita-2026-09-15.md — `4456a0bfe5ac62786728782564cb1e3cbb183a670e01f3928682b4a5247ac282`
- 70-La-vara-de-las-forjas-II-fdroid-y-las-tiendas-Facebook-La-Bandita-2026-09-15.md — `81f555182dfd298a2432491880e8c0228527f83e0f42ade0ffd20939f9683362`
- 71-Las-puertas-calladas-los-ceros-de-verdad-Facebook-La-Bandita-2026-09-15.md — `7cd0bcb98e23e763a8a1ff823d79eef5c0e82dc2b6ea09fe901727584cae2652`
- 72-Las-actas-del-censo-Facebook-La-Bandita-2026-09-15.md — `73816c2606a7908932939777eeb00941905e0209d02ad2b86a6d75214a8229f1`
- 73-Espejos-homonimos-y-mudanzas-el-libro-de-los-nombres-Facebook-La-Bandita-2026-09-15.md — `0bc3d0dd6b741c3b193322cd60749899716ea6cde22e94b8e50f5de6aa88a59e`
- 74-Los-vivos-de-la-semana-la-fila-de-las-fechas-Facebook-La-Bandita-2026-09-15.md — `6f84982962bec11aa18dff57157adabc3ddd1c8b048775735276e4d7e0fa709e`
- 75-El-podio-de-la-mina-los-veinte-mayores-Facebook-La-Bandita-2026-09-15.md — `1e3d09270bc312d0bbeb851d5ff4067517bcda3880624da1056c7c8a8e10ff42`
- 76-El-recuento-de-la-quincena-la-arquitectura-de-las-ochenta-Facebook-La-Bandita-2026-09-15.md — `ae0b1de39337e34b833301b9cebbfd4254aecd8d27796efd7eabe7a37bb0df49`
- 77-La-frontera-del-lunes-lo-que-queda-Facebook-La-Bandita-2026-09-15.md — `4e05a21f9fa0e8fe1ec9111ab5ae42d132e519ee7b649c3a76968ca65d60ec93`
- 78-LA-LISTA-del-techo-las-ochenta-en-una-pagina-Facebook-La-Bandita-2026-09-15.md — `f05e64434133bd5543addc4c68f64baa0241a8dbd4df7698f2ae7ac28638fcf9`
- 79-La-octogesima-el-techo-tocado-Facebook-La-Bandita-2026-09-15.md — `4d28abb85aa2c28955f432c3e78d8d980e7e91ef38ec37888979a4cd2aa6f35e`

### 03-PUBLICACIONES-2026-09-15/WhatsApp/
- 00-LA-LISTA-ecosistema-libre-en-16-guias-WhatsApp-La-Bandita-2026-09-15.md — `fdce55412d0887b369bec2b72062e2ff0cb878f3afd2a9b0a01fdac7ef0324aa`
- 01-Tiendas-APK-legales-mods-reloj-2027-WhatsApp-La-Bandita-2026-09-15.md — `b100c56d36aa7507c90e7c1b82825cb44e06c93097399488c709346f103c61e0`
- 02-Kototoro-manga-novelas-video-WhatsApp-La-Bandita-2026-09-15.md — `bca6dbc90f83ad9b72ba60ff77dc72563b31df2a7583f9bbf3677c67dbd524a2`
- 03-Verificacion-Desarrolladores-hito-30-sep-2027-WhatsApp-La-Bandita-2026-09-15.md — `39e433e4e0b20a6a9a8bee1f42779ec49dd6e5e78941946d3d7da2367418d4c6`
- 04-Extensiones-tres-arboles-hubs-parsers-WhatsApp-La-Bandita-2026-09-15.md — `e7b90b8737d962c9fa333cad2fbe4ffc416a1a2a6f143c66f171c67052828f01`
- 05-TMO-caida-clones-no-iniciar-sesion-WhatsApp-La-Bandita-2026-09-15.md — `8b9023146012796099b6bef50b24381bda9da29f59d4ff3553dc1bb558b8b539`
- 06-Forks-lectores-Mihon-Aniyomi-segundas-generaciones-WhatsApp-La-Bandita-2026-09-15.md — `8b32c55a17907738b20d6cc4ea928f7b0e31971c79eb98881d3b2c3880957113`
- 07-Usagi-viva-cadena-Kotatsu-Yukimi-Usagi-WhatsApp-La-Bandita-2026-09-15.md — `6eb67aed56d0973e1ee7f478712fdea8050630c9bbc028fffd9573be002523f5`
- 08-Musica-FOSS-clientes-con-repo-WhatsApp-La-Bandita-2026-09-15.md — `17b9831f15df176e2969638aca1b4bd9d84cc5727fc08646f1c584fc07ddb037`
- 09-Herramientas-FOSS-caja-de-oficio-WhatsApp-La-Bandita-2026-09-15.md — `074f0f845c62a97bd5691bdc6fcbb1173ea6aa796df9492fa7e4b083622d721b`
- 10-GLTools-no-se-receta-spoof-GPU-WhatsApp-La-Bandita-2026-09-15.md — `92830e7241501560c5e80fbcca8d6353c1c1b3db439aa06171e6c5f021114286`
- 11-AniZen-vivo-issue-no-enviado-WhatsApp-La-Bandita-2026-09-15.md — `e280f35e70a1d847dd412c0133423c492e9cd6b77a9b5ccb4b7104f614f3773d`
- 12-FMHY-wiki-de-pistas-no-catalogo-WhatsApp-La-Bandita-2026-09-15.md — `804889096d1ea68c2764be3dc12244ed256394195e428c1a5169d78c74eeb604`
- 13-Rama-Aniyomi-Animetail-anime-y-manga-WhatsApp-La-Bandita-2026-09-15.md — `9e4b14bb9ce030cc56775cffc40a6798d7451bbf2525a7a8afd3cdf174a866a8`
- 14-Rama-Animiru-Anikku-anime-puro-WhatsApp-La-Bandita-2026-09-15.md — `5ec49f4ff907b173709a42f69f999187a4b2f30838d90693afea24ce28000eb7`
- 15-Rama-TachiyomiJ2K-Yokai-Rokku-Reikai-Hayai-WhatsApp-La-Bandita-2026-09-15.md — `b3ec4c34c7fb6779913399f8ed2f22f06a4dc6d459359fd406e44076ac93333f`
- 16-Rama-TachiyomiSY-Komikku-WhatsApp-La-Bandita-2026-09-15.md — `ef547c004931eee2e45bf33a0f0f8fffd4b635e865b4e37d6cee8058be7baab1`
- 17-Capa-inmersion-Chimahon-Hoshi-Yomikai-Yomi-Koharia-WhatsApp-La-Bandita-2026-09-15.md — `8dbd63ac5321b45a7e66683f15183e8abfbea18a8cb71a60d59d40d2781a6cd3`
- 18-Libros-OpenlibExtended-cliente-Annas-Archive-WhatsApp-La-Bandita-2026-09-15.md — `f5ffc6022663f5e886692614fc9d66a3d2aaf116fd3a363c1482db7cfd7123f4`
- 19-Panorama-multi-anime-manga-novelas-WhatsApp-La-Bandita-2026-09-15.md — `b91b66d1806bc42ac339d9916287329ddb1ff04feb4b35182714cb8be0e5c612`
- 20-La-Biblioteca-plano-75-publicaciones-WhatsApp-La-Bandita-2026-09-15.md — `890cc954e5f2d0cc7faa9672c9b0f556187b9b497757007dcf9216a888b47c8b`
- 21-Musica-I-cosecha-del-muro-12-vivas-WhatsApp-La-Bandita-2026-09-15.md — `5aac38816f0972902569cddc3b8261f4d5315752fc124e89cd033da5764c8e87`
- 22-Lectura-II-la-repisa-del-muro-WhatsApp-La-Bandita-2026-09-15.md — `745acd47cc18fe4051c9ca82d72690bba2792169f3d20be06889f38f82248092`
- 23-Sala-del-muro-IPTV-Jellyfin-reproductores-WhatsApp-La-Bandita-2026-09-15.md — `b66d0efad6d3c2f1a75ebf347b5053e5b2355c728e99d8f2cd0d71c265fd0c46`
- 24-Taller-del-muro-Shizuku-root-sistema-WhatsApp-La-Bandita-2026-09-15.md — `bf6b303938edcf2d440c7fd90c7e7a31b13254f119c9b3d8d93e378562bdc311`
- 25-Sotano-del-muro-servidores-autoalojamiento-WhatsApp-La-Bandita-2026-09-15.md — `5745e934002f12770dbe063662455c5644f1f1d1fc87081e63ee57b385770ad4`
- 26-Cajon-del-muro-privacidad-parsers-miscelaneo-WhatsApp-La-Bandita-2026-09-15.md — `f3747c364201f10dd164ca8689773762124ee78913db933f12319c0d8b76af0c`
- 27-Musica-II-las-sucesiones-WhatsApp-La-Bandita-2026-09-15.md — `14bfce12082f3457d8ec7198b8d4e98e7a33f63797b506a5055a0e6d08683815`
- 28-El-tronco-raiz-gestion-y-tiendas-WhatsApp-La-Bandita-2026-09-15.md — `581c3925423b748df5f686584502a3151fc31e344091c38a7d1f4c31c12b8dcf`
- 29-Los-mayordomos-gestores-perfiles-bloat-WhatsApp-La-Bandita-2026-09-15.md — `61d63c7152c3dc10ff040bc4fdca5964bc47b8174a2233c457063e4266e6152e`
- 30-La-cara-del-sistema-lanzadores-teclados-WhatsApp-La-Bandita-2026-09-15.md — `ce540ba2c482f66835585a10e2c8126bbbb974c8cc55e825549a5a1500092014`
- 31-Los-pequenos-del-sistema-WhatsApp-La-Bandita-2026-09-15.md — `6ac5b730886f5aa37263e5620ef32f4294cd8300ba843826e98da32b6b64c89c`
- 32-El-cable-y-el-escudo-WhatsApp-La-Bandita-2026-09-15.md — `4c280e7486f42095cabf2b0d45d6877e13128f1c181d4295888efcb9ec6968c9`
- 33-Los-archivos-del-taller-WhatsApp-La-Bandita-2026-09-15.md — `d1a4123a0df89a9f0801fc4fb3b1cf08b2d2361bc80828945562d71fb7a0c03b`
- 34-Los-que-tenian-otro-nombre-ambiguos-WhatsApp-La-Bandita-2026-09-15.md — `b7da9441284e0bc0e04a8ce50d56f9614bcdb31e2dc6b5c512351ee1858c9317`
- 35-La-estanteria-la-estirpe-del-lector-WhatsApp-La-Bandita-2026-09-15.md — `1f549301fdb1ddfcac660603c665f76840f7ec4b8b0c915b718ea260692aac3a`
- 36-Los-libros-biblioteca-de-bolsillo-WhatsApp-La-Bandita-2026-09-15.md — `83c9aa7226fd3e0b4eb23421b6f4e98cd6e43dd76f942ace4c2aadbd07db5a0b`
- 37-La-puerta-grande-anime-video-I-WhatsApp-La-Bandita-2026-09-15.md — `896194a0e74778cf2e9a4952afb10b3fd2a21e49491022274769284fe7d2d283`
- 38-El-vivero-los-germinantes-WhatsApp-La-Bandita-2026-09-15.md — `28bbd5a3379fc513d81b4c9339d3b5a5d06dc97f78846ee334ec35e9836d59ed`
- 39-La-bodega-servidores-y-bibliotecas-WhatsApp-La-Bandita-2026-09-15.md — `5f496f87e89e9de750762ae6134f444afa1441df18a46380b66e9f7ab0737c73`
- 40-El-estudio-lectores-de-escritorio-WhatsApp-La-Bandita-2026-09-15.md — `b3bd4aa25ae1404d91f294f49a215a08dd3bfb6124037b427e9e9a31455284bf`
- 41-Los-cazadores-anime-y-video-III-WhatsApp-La-Bandita-2026-09-15.md — `983ca57a3b86ad8feb189951fde521c9c03be388cb16bf8c088864c3130d60e2`
- 42-La-fosa-el-sotano-II-WhatsApp-La-Bandita-2026-09-15.md — `4368e5b71ba203d40b8efe382f33879a50bf20c31c847d9b25eeb2629d0f0f1d`
- 43-La-corriente-geografia-de-las-fuentes-WhatsApp-La-Bandita-2026-09-15.md — `1b7d7eb27779855002e2c2f84482ccd5481c3b095179b35993202e15765d3d8e`
- 44-Los-pequenos-las-casas-que-no-hacen-ruido-WhatsApp-La-Bandita-2026-09-15.md — `71cd01f9aa0c0930f2fac698f5e832066a0f8c49b8c611e3a67ce6d1314e3d2e`
- 45-Las-canciones-la-voz-de-america-WhatsApp-La-Bandita-2026-09-15.md — `99150b9339b213feb56c7734454e115bc14adfd805f33a4386453c1ea5a80196`
- 46-La-sala-de-las-novelas-WhatsApp-La-Bandita-2026-09-15.md — `8c3a89c0dd3fc71dccc3ab2932121471dbcb7862181d7c0e035cb2872575c999`
- 47-La-ultima-puerta-del-catalogo-WhatsApp-La-Bandita-2026-09-15.md — `9dbd295366601e387e56df150e0eeeb85e6b88a6eb0a030b6d0239a08c01e8a5`
- 48-El-archivo-la-V25-vuelve-hecha-mejor-WhatsApp-La-Bandita-2026-09-15.md — `bb2860245070c15a7bd9363359738459a46744ec65b6c4e1fc8f46f82a97b4e2`
- 49-Las-mil-puertas-el-barrido-de-la-V25-WhatsApp-La-Bandita-2026-09-15.md — `e158eb9425a84d2de726a5fdf8e959b5a4234ed6f8bef599297bfa1440a11e7e`
- 50-La-discoteca-I-la-mina-de-las-231-WhatsApp-La-Bandita-2026-09-15.md — `76a1e85ae1af167550f00a30280dd7b966f93cda81b573f2bf4b5a65d07fa137`
- 51-La-discoteca-II-el-jugador-grande-y-la-mudanza-de-Finamp-WhatsApp-La-Bandita-2026-09-15.md — `5ce59041a374100ef1d288c1063e07a2ca146bd85d9faef6ea38da9db0c598b0`
- 52-La-discoteca-III-el-censo-completo-del-baile-WhatsApp-La-Bandita-2026-09-15.md — `ab6e944dfb02005d9f6aa7181e273456db3423dd6e27683b48d2ccda033aa62a`
- 53-Las-otras-forjas-gitlab-codeberg-y-los-sitios-WhatsApp-La-Bandita-2026-09-15.md — `ffea6b089c7c1f5588d3d1b2d513850cdcd0230e1eb3088e675c961db45b245b`
- 54-Las-puertas-del-sistema-y-el-taller-de-la-mina-WhatsApp-La-Bandita-2026-09-15.md — `8ec271980fd6fb0f229c021bdec58f86f337f33379b99975bbdf5f2e3e678e49`
- 55-Las-puertas-del-lector-y-las-bibliotecas-de-la-mina-WhatsApp-La-Bandita-2026-09-15.md — `c653eeeaa607c0a152eb9638e28583abb5d53f86e80ba8944313c65574c4c111`
- 56-Las-puertas-del-anime-y-los-servidores-de-la-mina-WhatsApp-La-Bandita-2026-09-15.md — `aab5a7a2714eb8e149f8ca8aa47782b792af848f13d61840a521931c6d65d150`
- 57-La-hornada-del-lector-la-mina-con-nombre-WhatsApp-La-Bandita-2026-09-15.md — `3542e60e2f54d9fac25ea65d5d226719f16c0e9fffb3ab17f90e603ef3d2a877`
- 58-La-hornada-del-anime-el-segundo-territorio-WhatsApp-La-Bandita-2026-09-15.md — `9d366d23c08d7273d8130af8b902dd7d16e9b26bcf0aed5190beaa76e4092abf`
- 59-La-hornada-del-taller-herramientas-de-la-mina-WhatsApp-La-Bandita-2026-09-15.md — `a3025ae63fb7ed9411d139fc5ccb53e86f54b83cf93de92c62c00e2d5147ec30`
- 60-La-hornada-de-las-bibliotecas-los-ordenadores-de-la-mina-WhatsApp-La-Bandita-2026-09-15.md — `8acd8930deb17742ce30dd64a1dbad2ae31807240aa9e346f8084256f0928bb2`
- 61-La-hornada-de-los-servidores-el-sotano-de-la-mina-WhatsApp-La-Bandita-2026-09-15.md — `1eb8b1d42fe132bc604ca6d0fed349756c7df45836e09e44ef26ba8946642718`
- 62-La-hornada-de-los-ayudantes-los-pequenos-del-censo-WhatsApp-La-Bandita-2026-09-15.md — `0ad060fd565fe8a8f935568beac313d7c79d2cbd7bc9ee25c3f955e7604e2bb0`
- 63-La-segunda-fila-del-lector-WhatsApp-La-Bandita-2026-09-15.md — `ec5fa79c17cd88781c6f1532ce73a0747f57a9256972c912e436bc6723367292`
- 64-La-segunda-fila-del-anime-WhatsApp-La-Bandita-2026-09-15.md — `7e0a1467f2eae46b83328eafe2a738f344bca97baf53e8744fc018856e112b5a`
- 65-La-segunda-fila-del-taller-WhatsApp-La-Bandita-2026-09-15.md — `c79ce4ece79b83b19aa4144fb3204a698310115e73f3cca8488e9eb898f264d8`
- 66-La-segunda-fila-de-las-bibliotecas-WhatsApp-La-Bandita-2026-09-15.md — `c77857076d6c07f6cb9bf7e83527962636f01ea7ac94e35fb461e429c1acf694`
- 67-La-segunda-fila-del-sotano-WhatsApp-La-Bandita-2026-09-15.md — `230a65934ec028f46170646eee5e2121ee6cc84597630c1f4af9e19b6af5a802`
- 68-La-segunda-fila-de-los-ayudantes-WhatsApp-La-Bandita-2026-09-15.md — `74306b81e34ee79202bd3dbdccaf9c06e1e433e41f87e58a287f00baea1dda19`
- 69-La-vara-de-las-forjas-I-gitlab-y-codeberg-WhatsApp-La-Bandita-2026-09-15.md — `4456a0bfe5ac62786728782564cb1e3cbb183a670e01f3928682b4a5247ac282`
- 70-La-vara-de-las-forjas-II-fdroid-y-las-tiendas-WhatsApp-La-Bandita-2026-09-15.md — `81f555182dfd298a2432491880e8c0228527f83e0f42ade0ffd20939f9683362`
- 71-Las-puertas-calladas-los-ceros-de-verdad-WhatsApp-La-Bandita-2026-09-15.md — `7cd0bcb98e23e763a8a1ff823d79eef5c0e82dc2b6ea09fe901727584cae2652`
- 72-Las-actas-del-censo-WhatsApp-La-Bandita-2026-09-15.md — `73816c2606a7908932939777eeb00941905e0209d02ad2b86a6d75214a8229f1`
- 73-Espejos-homonimos-y-mudanzas-el-libro-de-los-nombres-WhatsApp-La-Bandita-2026-09-15.md — `0bc3d0dd6b741c3b193322cd60749899716ea6cde22e94b8e50f5de6aa88a59e`
- 74-Los-vivos-de-la-semana-la-fila-de-las-fechas-WhatsApp-La-Bandita-2026-09-15.md — `6f84982962bec11aa18dff57157adabc3ddd1c8b048775735276e4d7e0fa709e`
- 75-El-podio-de-la-mina-los-veinte-mayores-WhatsApp-La-Bandita-2026-09-15.md — `1e3d09270bc312d0bbeb851d5ff4067517bcda3880624da1056c7c8a8e10ff42`
- 76-El-recuento-de-la-quincena-la-arquitectura-de-las-ochenta-WhatsApp-La-Bandita-2026-09-15.md — `ae0b1de39337e34b833301b9cebbfd4254aecd8d27796efd7eabe7a37bb0df49`
- 77-La-frontera-del-lunes-lo-que-queda-WhatsApp-La-Bandita-2026-09-15.md — `4e05a21f9fa0e8fe1ec9111ab5ae42d132e519ee7b649c3a76968ca65d60ec93`
- 78-LA-LISTA-del-techo-las-ochenta-en-una-pagina-WhatsApp-La-Bandita-2026-09-15.md — `f05e64434133bd5543addc4c68f64baa0241a8dbd4df7698f2ae7ac28638fcf9`
- 79-La-octogesima-el-techo-tocado-WhatsApp-La-Bandita-2026-09-15.md — `4d28abb85aa2c28955f432c3e78d8d980e7e91ef38ec37888979a4cd2aa6f35e`

### VERSIONES MULTIPLATAFORMA (04-VERSIONES-MULTIIDIOMA/) — hashes

- 04-VERSIONES-MULTIIDIOMA/Guía de versionado multiplataforma (15-sep).md — `ff0b14bc38439ee3227bbe18ae3a207bc0c3031ff782a12ad8dba026b1f14f8f`
- 04-VERSIONES-MULTIIDIOMA/discord/chino-CN/75-El-podio-de-la-mina-Discord-La-Bandita-2026-09-15-chino-CN.md — `ca827c65ec3bfd1c605ea7ecf1dcdd55833f6d6e181e35026418ed8a28e94ee6`
- 04-VERSIONES-MULTIIDIOMA/discord/chino-CN/79-La-octogesima-el-techo-tocado-Discord-La-Bandita-2026-09-15-chino-CN.md — `a3d162d4e3579cde358ad1f7e5b069c5eb081cd5ce15153e9c33a897cf136ac5`
- 04-VERSIONES-MULTIIDIOMA/discord/chino-CN/LEEME-de-la-carpeta.md — `0bd4e6c99ea70a4fcd7772f8aa3d880d9b47d09d2f1f55232230c52cf26cf783`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/00-LA-LISTA-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `02c3d148b0758d364241dcc73fbcdc4a3c9571cb9acf8bffab46594bb9f90cfa`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/01-Tiendas-de-APK-legales-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `eba9caa240be4d4c4309f97dba8f431315764f98efdf7d4d905cb6ef37b53239`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/02-Kototoro-manga-novelas-video-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `d683b55e1edecc46f90b21f66eb3c6492726bd0ba104730a5fe16722d22a2da4`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/03-Verificacion-de-Desarrolladores-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `dd36df0dadf2dd3f93dd744050759180972a6240fa9b1bf04e73247d6e2e5c9b`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/04-Extensiones-tres-arboles-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `8f9ac578bbd44a309fde302e3ae1d66a64cdb6173a8351ccdeb44f0fc1c7c644`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/05-TMO-cayo-los-clones-no-son-TMO-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `c7bff71038d7c0feeea3fa9f0e9d3af90ca97ee561feb29792ec45f5b784c5b6`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/06-Forks-de-lectores-segundas-generaciones-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `e3730290be19cf5d38fd860e7d5351b60e1e7a9249791e6720d1be41496ee682`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/07-Usagi-viva-cadena-Kotatsu-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `58780baaec7448303b0fd34c4d780dbc929bbc27e0c5fde2f00d312c5335facb`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/08-Musica-FOSS-clientes-con-repo-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `3066eb86df274b44bd2a3e26a44ecd07e6177edffe7d6032bea0d1f36a0e07b8`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/09-Herramientas-FOSS-caja-de-oficio-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `ff85318beb79f22f8941ca1d6d67b2316a46dfe435a1f0e958dd9d5033af5266`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/10-GLTools-no-se-receta-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `ca1993a36c89ef7c44ba38fea40ea0a56965dd493caeec272cad0dc21094cc1f`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/11-AniZen-vivo-el-espejo-no-es-el-repo-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `8ea8d66ca457055e8cc72393f02c8c33411e56a5dc9800c337ce7f34706ccf68`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/12-FMHY-wiki-de-pistas-no-catalogo-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `84889a2d103e11eb36071de32055d200cbfe56797a7e2d1b9f77f875fc939500`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/13-Rama-Aniyomi-Animetail-Tadami-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `cfa8e6aadd56f7bdcde063d663cbe2fb3ff6027dc8a6b2dd048e3b4d5846b56c`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/14-Rama-anime-puro-Animiru-Anikku-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `ff4654a86f54b2e904e69773b1103265ac707eaedc3a4b0fab26b60d77908f73`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/15-Rama-J2K-Yokai-Rokku-Reikai-Hayai-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `6e80a2f234755a84e29f5a7b1a6af03c30ec5bd3216dec73a35c65cb7f651200`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/16-Rama-SY-Komikku-el-clasico-y-el-rehijo-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `351d6ac8b87bd027b0788b247eb4e56ec8d911d6abb0f99b1a8856dc1e34d086`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/17-Capa-de-inmersion-aprender-japones-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `d9654c35ea2252ab658b6cfd7873405b584914d45e30c38cafe76411fffe9bbf`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/18-Libros-OpenlibExtended-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `2dcb3a53480680e5ccde8d78f5ef92c8be5bd6d69c108e228f223426e2e900c4`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/19-Panorama-multi-anime-manga-novelas-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `23cc548be35028ee2ba630aa96c56cbe88cc2d9abef22d1e45eb4d77f7cb10f9`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/20-La-Biblioteca-de-un-muro-a-75-guias-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `b897d222bd90121c418def553f2075c980d80d52d7acd0face6eb2748f2327f8`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/21-Musica-I-la-cosecha-del-muro-12-vivas-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `ca65a6f142530bfaaa1dcc3dbce5a76907ff71712338454de1566e39646cf792`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/22-Lectura-II-la-repisa-del-muro-siete-lectores-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `ee3088084e58c6a796b543925f04abbbea46d7b0d474bdd8bbe6bf49d0cf5461`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/23-La-sala-del-muro-IPTV-servidores-cine-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `e7dc17264781f0e02413673bac270c6253f331cfb83589b46837a6604940a103`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/24-El-taller-del-muro-Shizuku-root-sistema-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `33f9e4de03ab23d668b7b1d7e1f80d78d7e2b21542b8faddfa24ee1b52b9d327`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/25-El-sotano-del-muro-servidores-autoalojados-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `419f6fa280a38f0a582ce4350cc90b2ff7372f736e5ad570808f574dbc823766`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/26-El-cajon-del-muro-candados-adaptadores-miscelaneo-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `9926d55dbbec018cbda30b1092586ae1c34b446d2c09c75fb7e7f8ebb394e6e7`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/27-Musica-II-las-sucesiones-quien-hereda-a-quien-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `43e483fba8fbca3e77f45e67c04d8a8ec20268e480c80346f2170fa261302a34`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/28-El-tronco-raiz-gestion-y-tiendas-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `c2ccdf93cfdf94949c2b2c6dc7d6bc44578402ab163be1e02f2ebcfa0e858a6e`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/29-Los-mayordomos-apps-perfiles-bloat-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `15173565c7d5da1d16df27fb0197cb5b58a2916cb3ab9b28e23b98becd161fe2`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/30-La-cara-del-sistema-lanzadores-teclados-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `df97a96a79f6d94e3328f59c17ff1399b4212290a0ce0945e36efda9b385c8a6`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/31-Los-pequenos-del-sistema-una-sola-cosa-bien-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `22af22fa131f036c7b6c626d68c50ed2282d23028eaccc2255680584c4da02e4`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/32-El-cable-y-el-escudo-conectar-actualizar-defender-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `5defd60dade2de1eab8f73a97789b74c668dfd9290eb43f0116f6ecc665b7026`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/33-Los-archivos-del-taller-cajones-paquetes-guardian-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `bd047ffd26a4b40c8b59a744e9db3ecd874a1533b8f5932828b5f75e7297065e`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/34-Los-que-tenian-otro-nombre-la-vara-de-cada-pez-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `64146bfa4d4d3cb8dcec6a696cf38486d00a1167cee4a2593241c9db5864acd2`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/35-La-estanteria-la-estirpe-del-lector-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `c03976817aad9145497d44ff5b71c183d29b6278250f83312c1b7e189ab14f81`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/36-Los-libros-biblioteca-de-bolsillo-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `9ecb1d47ef03398741a5fe0be711f695de77d0a86a6eb5793998f1012e073a36`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/37-La-puerta-grande-anime-video-I-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `3c2f2507c696aed93f5289986a04c67ccc766579f02fc8f96b4dc6767dcd438d`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/38-El-vivero-los-germinantes-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `2812bdbc76a901058f389f79d7aee2169f9bf548eadab6da5b9670e2e84138e6`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/39-La-bodega-servidores-y-bibliotecas-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `b525445d36ff314d6d5f44720d0561d9c5e1a4277473361d8fbf5eaa22830ca8`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/40-El-estudio-lectores-de-escritorio-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `5e04de3a95b3836e8a7af36a33e61c31b1eb83b1825a0baaf7596c2a20836b7d`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/41-Los-cazadores-anime-video-III-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `38735c1e798ca1fe8ce96a5000327e4dadbad2d7684d1f5a7ee27e6431256a28`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/42-La-fosa-lo-profundo-del-mar-sotano-II-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `1dbcd42cb6c9cd63d20a2ea791cf332b1810a5c535184b50f7315e55f251354c`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/43-La-corriente-geografia-de-las-fuentes-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `406ae820a3c6a65ebc7347608e12566fc7aa699e5b49d32f785665d88f358f12`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/44-Los-pequenos-las-casas-que-no-hacen-ruido-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `f6dd8a50ec841fa8db0d93cc7fd4ecba307dc7ffd18db015cbe85cce0519a1cb`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/45-Las-canciones-la-voz-de-america-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `8a1b73735d90a7e1f8b9f3e66a22c8341c3178f1905a588295a0d8a2b9179ddd`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/46-La-sala-de-las-novelas-lectura-IV-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `a2b30d10f9938421e036dd8a8282037bccfcd77786fbf2feffd3dc8e48dfe1e6`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/47-La-ultima-puerta-del-catalogo-venera-y-veredictos-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `eb90ba811bb576431185733f774af48b40ba1e357a90879a4c6d68800a422027`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/48-El-archivo-la-V25-vuelve-hecha-mejor-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `0c5756e08e534835b952c76087374e932fd577b9b194977f09b8d34d491c1045`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/49-Las-mil-puertas-el-barrido-de-la-V25-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `dd65f55d547d9addb184a55a57b590bc3621d2013c526e1bafcbc561cceca86a`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/50-La-discoteca-I-la-mina-de-las-231-puertas-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `95b53869911d8d1cb589bdb44fadebd61a2716bdb7c589a87daf995263697733`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/51-La-discoteca-II-el-jugador-grande-y-Finamp-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `47be065e0cba81e85da0c81200cd05409efcd11db10f2b387221d623820e2c94`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/52-La-discoteca-III-el-censo-completo-del-baile-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `ae120ddacfd1f46f9bba5211952a18532dca49553faa70b41b79e151c42b2c0e`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/53-Las-otras-forjas-gitlab-codeberg-y-los-sitios-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `3397c1cc9390bd0944fcc947886d5723ba109cfa0b44d537c0bb74ffd49858eb`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/54-Las-puertas-del-sistema-y-el-taller-censo-mina-I-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `0a91aab613fe439d6c45653a6ee0bbf8aea9f91446c42f647815e792f0404157`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/55-Las-puertas-del-lector-y-bibliotecas-censo-mina-II-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `4dc17e2f6026e1ad25bf55d432c6008ab33ff89d8384987f109a47fb311fba28`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/56-Las-puertas-del-anime-y-los-servidores-censo-mina-III-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `b43ce30a01677b11f95dd426df7fdb666598cb18c9ca6a384bff0500b563e89b`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/57-La-hornada-del-lector-la-mina-con-nombre-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `2b8fc11a7a217298b4323d2f6a0dd344c0ff706fe1097247e02ea3afd5fc2241`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/58-La-hornada-del-anime-el-segundo-territorio-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `f6c8020d7e47f2f8cdb0eead48e6f16dded5475bcfdb96c9be2be451ef5e64c8`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/59-La-hornada-del-taller-herramientas-de-la-mina-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `b2a64aeb555165c8a946f5e577c5257b6366b85130aa455e9e502ee0bcfba2ad`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/60-La-hornada-de-las-bibliotecas-los-ordenadores-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `706cc360b0b5f5a0b240948c535794b040df8a9ed02681557d6f2dec73ce9ef3`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/61-La-hornada-de-los-servidores-el-sotano-de-la-mina-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `421254824cfd4414dbf299dc8b184e0cd06184fe906ee714e1104fd4a7dffb6e`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/62-La-hornada-de-los-ayudantes-los-pequenos-del-censo-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `cfb8b337bf0a85d9dbf4de56ed4402241b98a6f01e2109b999122a74ae0457c1`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/63-La-segunda-fila-del-lector-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `0401ea5675aa0bcdb4e24340b626c0841bb011f361c44a06279cd879913eef2c`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/64-La-segunda-fila-del-anime-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `516e088cda1f8c1f3448c8e008dd61927fc5ad90a4adfaa12a161d67ff5ab624`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/65-La-segunda-fila-del-taller-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `98475f6ee25966b1c97701e2e4c62adc6435c6234c739eddf40b11f6b2dc8fc3`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/66-La-segunda-fila-de-las-bibliotecas-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `2722a45b5df92736587b2cd28c642fdc7c1bbb9919041a9ae92ed3d2dc14c077`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/67-La-segunda-fila-de-los-servidores-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `4cb303dc64f9a3708ef1fe2e85decaf723d9cae2dfd1c58a08ec32bd69d6eecb`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/68-Los-canes-la-segunda-fila-final-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `1d19d12881f09ae5cb1316e7a1176597cd1f2487700170e9a8f22e2a432a833f`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/69-La-vara-por-las-forjas-I-Codeberg-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `316b5de0c22815d6bf8c499bbd7dce027f6c9d19abc0b35cdde9b48d10a3f337`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/70-La-vara-por-las-forjas-II-F-Droid-y-sitios-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `e80f41f2db4f9b58a2ea887e00fe25b0668f80fbb1b2651dc32457c9f295d07d`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/71-Los-ceros-hermanos-y-los-nombres-solos-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `36178675625a7919a6ff17f65d414205729b1fd733e42f25312a08e700a86214`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/72-Las-actas-del-censo-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `8575046970966e44c5b2b6961f1df4d35427d1ca4e65bb22f73c8d08afc5b81e`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/73-Los-espejos-y-los-homónimos-libro-de-nombres-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `66894322342e294b1204afd2963f440a3577f21eb22d3ca7f68811204d112378`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/74-Los-vivos-de-la-semana-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `fa119e93f15f59236c38f6c8a590bfc48330db5cf95a1a00b5bc2260fc2137e5`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/75-El-podio-de-la-mina-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `244aded23594d659ef48e12f82079352c49ee1ac501bdaadc297fc314f91bf76`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/76-El-recuento-la-arquitectura-de-las-ochenta-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `4637f607db6f8eb27582989906168aa65bf807258119b2ecb88ae97ffd4e4423`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/77-La-frontera-del-lunes-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `381691b0d2e73cc3d0cb55e77270a16a71ef9ff254b1a5291c4208f5c768e516`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/78-LA-LISTA-del-techo-la-pieza-final-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `57670f6d056be311b86f3f3ffe125545d3fa185dd4d4aea2dca5e03223f92cf0`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/79-La-octogesima-el-techo-tocado-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `ab0a4a4d7f76985b72380bbad98c98e95c72bde198248c5d76ecf39c109cb87e`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/80-Las-familias-de-extensiones-Discord-La-Bandita-2026-09-15-dominicano-ES.md — `ee650aeed5780bbc52f679e2490c04ce543a141f6b8c220679313838f0fa3d65`
- 04-VERSIONES-MULTIIDIOMA/discord/dominicano-ES/LEEME-de-la-carpeta.md — `7131e34f412ec5dfbcb41a56c9004c43d11fa293b676f98475e465d9712aaeb0`
- 04-VERSIONES-MULTIIDIOMA/discord/frances-FR/75-El-podio-de-la-mina-Discord-La-Bandita-2026-09-15-frances-FR.md — `b2558234990c2ef463eff102149cb690d2d3c7efcede5a32153476fd68f85b19`
- 04-VERSIONES-MULTIIDIOMA/discord/frances-FR/79-La-octogesima-el-techo-tocado-Discord-La-Bandita-2026-09-15-frances-FR.md — `8e75dee32003a6210cc8184fc2e2b915b7e05b3025d71eadcd105eb6f5b4048f`
- 04-VERSIONES-MULTIIDIOMA/discord/frances-FR/LEEME-de-la-carpeta.md — `09423466e946434ddc8d03392f7db2d3ac72dc6a3fca29980339646d70496b4d`
- 04-VERSIONES-MULTIIDIOMA/discord/hindi-IN/75-El-podio-de-la-mina-Discord-La-Bandita-2026-09-15-hindi-IN.md — `ffa6b2a0066c28673c079b61d0741844b4ad5292078d7f9cdd88d1bed1736586`
- 04-VERSIONES-MULTIIDIOMA/discord/hindi-IN/79-La-octogesima-el-techo-tocado-Discord-La-Bandita-2026-09-15-hindi-IN.md — `bab2b3a3e34d5447ca3044b5f8225203897a6bb9f475cfe3f9e23d56cd2f957b`
- 04-VERSIONES-MULTIIDIOMA/discord/hindi-IN/LEEME-de-la-carpeta.md — `6c31a95a072f1ae9253e63352a3a6828d653f8ded493a7fdbb11444aa8dd04ef`
- 04-VERSIONES-MULTIIDIOMA/discord/ingles-US/75-El-podio-de-la-mina-Discord-La-Bandita-2026-09-15-ingles-US.md — `73e9de1b00a804105cea7703318ffa0a3c08f683a707d58fe2e0ce311f329595`
- 04-VERSIONES-MULTIIDIOMA/discord/ingles-US/79-La-octogesima-el-techo-tocado-Discord-La-Bandita-2026-09-15-ingles-US.md — `e30a3a830539bfd2f6a78687cde136df388e6a479797fa69b3fd106c7da43f2d`
- 04-VERSIONES-MULTIIDIOMA/discord/ingles-US/LEEME-de-la-carpeta.md — `524c7dcb7bd4af71e3a9934aaf52fb806e71152bb40f0c974b76713de10f5653`
- 04-VERSIONES-MULTIIDIOMA/discord/portugues-BR/75-El-podio-de-la-mina-Discord-La-Bandita-2026-09-15-portugues-BR.md — `76d39f8eeb6a2ef81acae4133bc513e8382f82b4efc54edbc1c54d1a93684c18`
- 04-VERSIONES-MULTIIDIOMA/discord/portugues-BR/79-La-octogesima-el-techo-tocado-Discord-La-Bandita-2026-09-15-portugues-BR.md — `51d1b6b9b64894c031ad57b18f427045ce7a2b24dde2bfb160f0d901c2b424fd`
- 04-VERSIONES-MULTIIDIOMA/discord/portugues-BR/LEEME-de-la-carpeta.md — `363f1cdf788fc95e90e6bb9582f9eda7d41161533bc0aacf26da8ec54788c0de`
- 04-VERSIONES-MULTIIDIOMA/discord/ruso-RU/75-El-podio-de-la-mina-Discord-La-Bandita-2026-09-15-ruso-RU.md — `a78978e2af9e445ffc7065c8bbb994c92cbb2e5bba6cdfc809a69fe72ea468af`
- 04-VERSIONES-MULTIIDIOMA/discord/ruso-RU/79-La-octogesima-el-techo-tocado-Discord-La-Bandita-2026-09-15-ruso-RU.md — `b487dfcaece675bb4c5d0b0fbd22d82dbdbb16e4ac3c37336b132f63e1cb8e36`
- 04-VERSIONES-MULTIIDIOMA/discord/ruso-RU/LEEME-de-la-carpeta.md — `cfc217e7dda04ebb9b3d0749ba17f4fd45fa095bad271831667829bbc78c8494`
- 04-VERSIONES-MULTIIDIOMA/facebook/chino-CN/75-El-podio-de-la-mina-Facebook-La-Bandita-2026-09-15-chino-CN.md — `c62594ef7c07991a6c66ffbf6cb9f300d1bd7c9e5d194940c9a4f573f9e567d9`
- 04-VERSIONES-MULTIIDIOMA/facebook/chino-CN/LEEME-de-la-carpeta.md — `42a76edad49170fad13eb5aaa2f20c0e302e8e86423f7331b28b1a599d343fd7`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/00-LA-LISTA-ecosistema-libre-en-16-guias-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `fdce55412d0887b369bec2b72062e2ff0cb878f3afd2a9b0a01fdac7ef0324aa`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/01-Tiendas-APK-legales-mods-reloj-2027-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `b100c56d36aa7507c90e7c1b82825cb44e06c93097399488c709346f103c61e0`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/02-Kototoro-manga-novelas-video-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `bca6dbc90f83ad9b72ba60ff77dc72563b31df2a7583f9bbf3677c67dbd524a2`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/03-Verificacion-Desarrolladores-hito-30-sep-2027-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `39e433e4e0b20a6a9a8bee1f42779ec49dd6e5e78941946d3d7da2367418d4c6`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/04-Extensiones-tres-arboles-hubs-parsers-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `e7b90b8737d962c9fa333cad2fbe4ffc416a1a2a6f143c66f171c67052828f01`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/05-TMO-caida-clones-no-iniciar-sesion-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `8b9023146012796099b6bef50b24381bda9da29f59d4ff3553dc1bb558b8b539`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/06-Forks-lectores-Mihon-Aniyomi-segundas-generaciones-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `8b32c55a17907738b20d6cc4ea928f7b0e31971c79eb98881d3b2c3880957113`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/07-Usagi-viva-cadena-Kotatsu-Yukimi-Usagi-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `6eb67aed56d0973e1ee7f478712fdea8050630c9bbc028fffd9573be002523f5`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/08-Musica-FOSS-clientes-con-repo-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `17b9831f15df176e2969638aca1b4bd9d84cc5727fc08646f1c584fc07ddb037`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/09-Herramientas-FOSS-caja-de-oficio-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `074f0f845c62a97bd5691bdc6fcbb1173ea6aa796df9492fa7e4b083622d721b`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/10-GLTools-no-se-receta-spoof-GPU-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `92830e7241501560c5e80fbcca8d6353c1c1b3db439aa06171e6c5f021114286`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/11-AniZen-vivo-issue-no-enviado-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `e280f35e70a1d847dd412c0133423c492e9cd6b77a9b5ccb4b7104f614f3773d`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/12-FMHY-wiki-de-pistas-no-catalogo-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `804889096d1ea68c2764be3dc12244ed256394195e428c1a5169d78c74eeb604`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/13-Rama-Aniyomi-Animetail-anime-y-manga-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `9e4b14bb9ce030cc56775cffc40a6798d7451bbf2525a7a8afd3cdf174a866a8`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/14-Rama-Animiru-Anikku-anime-puro-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `5ec49f4ff907b173709a42f69f999187a4b2f30838d90693afea24ce28000eb7`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/15-Rama-TachiyomiJ2K-Yokai-Rokku-Reikai-Hayai-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `b3ec4c34c7fb6779913399f8ed2f22f06a4dc6d459359fd406e44076ac93333f`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/16-Rama-TachiyomiSY-Komikku-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `ef547c004931eee2e45bf33a0f0f8fffd4b635e865b4e37d6cee8058be7baab1`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/17-Capa-inmersion-Chimahon-Hoshi-Yomikai-Yomi-Koharia-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `8dbd63ac5321b45a7e66683f15183e8abfbea18a8cb71a60d59d40d2781a6cd3`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/18-Libros-OpenlibExtended-cliente-Annas-Archive-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `f5ffc6022663f5e886692614fc9d66a3d2aaf116fd3a363c1482db7cfd7123f4`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/19-Panorama-multi-anime-manga-novelas-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `b91b66d1806bc42ac339d9916287329ddb1ff04feb4b35182714cb8be0e5c612`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/20-La-Biblioteca-plano-75-publicaciones-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `890cc954e5f2d0cc7faa9672c9b0f556187b9b497757007dcf9216a888b47c8b`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/21-Musica-I-cosecha-del-muro-12-vivas-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `5aac38816f0972902569cddc3b8261f4d5315752fc124e89cd033da5764c8e87`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/22-Lectura-II-la-repisa-del-muro-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `745acd47cc18fe4051c9ca82d72690bba2792169f3d20be06889f38f82248092`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/23-Sala-del-muro-IPTV-Jellyfin-reproductores-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `b66d0efad6d3c2f1a75ebf347b5053e5b2355c728e99d8f2cd0d71c265fd0c46`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/24-Taller-del-muro-Shizuku-root-sistema-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `bf6b303938edcf2d440c7fd90c7e7a31b13254f119c9b3d8d93e378562bdc311`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/25-Sotano-del-muro-servidores-autoalojamiento-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `5745e934002f12770dbe063662455c5644f1f1d1fc87081e63ee57b385770ad4`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/26-Cajon-del-muro-privacidad-parsers-miscelaneo-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `f3747c364201f10dd164ca8689773762124ee78913db933f12319c0d8b76af0c`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/27-Musica-II-las-sucesiones-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `14bfce12082f3457d8ec7198b8d4e98e7a33f63797b506a5055a0e6d08683815`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/28-El-tronco-raiz-gestion-y-tiendas-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `581c3925423b748df5f686584502a3151fc31e344091c38a7d1f4c31c12b8dcf`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/29-Los-mayordomos-gestores-perfiles-bloat-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `61d63c7152c3dc10ff040bc4fdca5964bc47b8174a2233c457063e4266e6152e`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/30-La-cara-del-sistema-lanzadores-teclados-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `ce540ba2c482f66835585a10e2c8126bbbb974c8cc55e825549a5a1500092014`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/31-Los-pequenos-del-sistema-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `6ac5b730886f5aa37263e5620ef32f4294cd8300ba843826e98da32b6b64c89c`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/32-El-cable-y-el-escudo-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `4c280e7486f42095cabf2b0d45d6877e13128f1c181d4295888efcb9ec6968c9`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/33-Los-archivos-del-taller-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `d1a4123a0df89a9f0801fc4fb3b1cf08b2d2361bc80828945562d71fb7a0c03b`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/34-Los-que-tenian-otro-nombre-ambiguos-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `b7da9441284e0bc0e04a8ce50d56f9614bcdb31e2dc6b5c512351ee1858c9317`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/35-La-estanteria-la-estirpe-del-lector-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `1f549301fdb1ddfcac660603c665f76840f7ec4b8b0c915b718ea260692aac3a`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/36-Los-libros-biblioteca-de-bolsillo-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `83c9aa7226fd3e0b4eb23421b6f4e98cd6e43dd76f942ace4c2aadbd07db5a0b`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/37-La-puerta-grande-anime-video-I-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `896194a0e74778cf2e9a4952afb10b3fd2a21e49491022274769284fe7d2d283`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/38-El-vivero-los-germinantes-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `28bbd5a3379fc513d81b4c9339d3b5a5d06dc97f78846ee334ec35e9836d59ed`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/39-La-bodega-servidores-y-bibliotecas-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `5f496f87e89e9de750762ae6134f444afa1441df18a46380b66e9f7ab0737c73`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/40-El-estudio-lectores-de-escritorio-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `b3bd4aa25ae1404d91f294f49a215a08dd3bfb6124037b427e9e9a31455284bf`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/41-Los-cazadores-anime-y-video-III-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `983ca57a3b86ad8feb189951fde521c9c03be388cb16bf8c088864c3130d60e2`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/42-La-fosa-el-sotano-II-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `4368e5b71ba203d40b8efe382f33879a50bf20c31c847d9b25eeb2629d0f0f1d`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/43-La-corriente-geografia-de-las-fuentes-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `1b7d7eb27779855002e2c2f84482ccd5481c3b095179b35993202e15765d3d8e`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/44-Los-pequenos-las-casas-que-no-hacen-ruido-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `71cd01f9aa0c0930f2fac698f5e832066a0f8c49b8c611e3a67ce6d1314e3d2e`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/45-Las-canciones-la-voz-de-america-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `99150b9339b213feb56c7734454e115bc14adfd805f33a4386453c1ea5a80196`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/46-La-sala-de-las-novelas-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `8c3a89c0dd3fc71dccc3ab2932121471dbcb7862181d7c0e035cb2872575c999`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/47-La-ultima-puerta-del-catalogo-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `9dbd295366601e387e56df150e0eeeb85e6b88a6eb0a030b6d0239a08c01e8a5`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/48-El-archivo-la-V25-vuelve-hecha-mejor-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `bb2860245070c15a7bd9363359738459a46744ec65b6c4e1fc8f46f82a97b4e2`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/49-Las-mil-puertas-el-barrido-de-la-V25-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `e158eb9425a84d2de726a5fdf8e959b5a4234ed6f8bef599297bfa1440a11e7e`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/50-La-discoteca-I-la-mina-de-las-231-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `76a1e85ae1af167550f00a30280dd7b966f93cda81b573f2bf4b5a65d07fa137`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/51-La-discoteca-II-el-jugador-grande-y-la-mudanza-de-Finamp-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `5ce59041a374100ef1d288c1063e07a2ca146bd85d9faef6ea38da9db0c598b0`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/52-La-discoteca-III-el-censo-completo-del-baile-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `ab6e944dfb02005d9f6aa7181e273456db3423dd6e27683b48d2ccda033aa62a`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/53-Las-otras-forjas-gitlab-codeberg-y-los-sitios-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `ffea6b089c7c1f5588d3d1b2d513850cdcd0230e1eb3088e675c961db45b245b`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/54-Las-puertas-del-sistema-y-el-taller-de-la-mina-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `8ec271980fd6fb0f229c021bdec58f86f337f33379b99975bbdf5f2e3e678e49`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/55-Las-puertas-del-lector-y-las-bibliotecas-de-la-mina-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `c653eeeaa607c0a152eb9638e28583abb5d53f86e80ba8944313c65574c4c111`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/56-Las-puertas-del-anime-y-los-servidores-de-la-mina-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `aab5a7a2714eb8e149f8ca8aa47782b792af848f13d61840a521931c6d65d150`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/57-La-hornada-del-lector-la-mina-con-nombre-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `3542e60e2f54d9fac25ea65d5d226719f16c0e9fffb3ab17f90e603ef3d2a877`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/58-La-hornada-del-anime-el-segundo-territorio-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `9d366d23c08d7273d8130af8b902dd7d16e9b26bcf0aed5190beaa76e4092abf`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/59-La-hornada-del-taller-herramientas-de-la-mina-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `a3025ae63fb7ed9411d139fc5ccb53e86f54b83cf93de92c62c00e2d5147ec30`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/60-La-hornada-de-las-bibliotecas-los-ordenadores-de-la-mina-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `8acd8930deb17742ce30dd64a1dbad2ae31807240aa9e346f8084256f0928bb2`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/61-La-hornada-de-los-servidores-el-sotano-de-la-mina-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `1eb8b1d42fe132bc604ca6d0fed349756c7df45836e09e44ef26ba8946642718`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/62-La-hornada-de-los-ayudantes-los-pequenos-del-censo-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `0ad060fd565fe8a8f935568beac313d7c79d2cbd7bc9ee25c3f955e7604e2bb0`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/63-La-segunda-fila-del-lector-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `ec5fa79c17cd88781c6f1532ce73a0747f57a9256972c912e436bc6723367292`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/64-La-segunda-fila-del-anime-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `7e0a1467f2eae46b83328eafe2a738f344bca97baf53e8744fc018856e112b5a`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/65-La-segunda-fila-del-taller-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `c79ce4ece79b83b19aa4144fb3204a698310115e73f3cca8488e9eb898f264d8`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/66-La-segunda-fila-de-las-bibliotecas-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `c77857076d6c07f6cb9bf7e83527962636f01ea7ac94e35fb461e429c1acf694`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/67-La-segunda-fila-del-sotano-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `230a65934ec028f46170646eee5e2121ee6cc84597630c1f4af9e19b6af5a802`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/68-La-segunda-fila-de-los-ayudantes-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `74306b81e34ee79202bd3dbdccaf9c06e1e433e41f87e58a287f00baea1dda19`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/69-La-vara-de-las-forjas-I-gitlab-y-codeberg-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `4456a0bfe5ac62786728782564cb1e3cbb183a670e01f3928682b4a5247ac282`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/70-La-vara-de-las-forjas-II-fdroid-y-las-tiendas-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `81f555182dfd298a2432491880e8c0228527f83e0f42ade0ffd20939f9683362`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/71-Las-puertas-calladas-los-ceros-de-verdad-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `7cd0bcb98e23e763a8a1ff823d79eef5c0e82dc2b6ea09fe901727584cae2652`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/72-Las-actas-del-censo-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `73816c2606a7908932939777eeb00941905e0209d02ad2b86a6d75214a8229f1`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/73-Espejos-homonimos-y-mudanzas-el-libro-de-los-nombres-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `0bc3d0dd6b741c3b193322cd60749899716ea6cde22e94b8e50f5de6aa88a59e`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/74-Los-vivos-de-la-semana-la-fila-de-las-fechas-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `6f84982962bec11aa18dff57157adabc3ddd1c8b048775735276e4d7e0fa709e`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/75-El-podio-de-la-mina-los-veinte-mayores-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `1e3d09270bc312d0bbeb851d5ff4067517bcda3880624da1056c7c8a8e10ff42`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/76-El-recuento-de-la-quincena-la-arquitectura-de-las-ochenta-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `ae0b1de39337e34b833301b9cebbfd4254aecd8d27796efd7eabe7a37bb0df49`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/77-La-frontera-del-lunes-lo-que-queda-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `4e05a21f9fa0e8fe1ec9111ab5ae42d132e519ee7b649c3a76968ca65d60ec93`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/78-LA-LISTA-del-techo-las-ochenta-en-una-pagina-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `f05e64434133bd5543addc4c68f64baa0241a8dbd4df7698f2ae7ac28638fcf9`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/79-La-octogesima-el-techo-tocado-Facebook-La-Bandita-2026-09-15-dominicano-ES.md — `4d28abb85aa2c28955f432c3e78d8d980e7e91ef38ec37888979a4cd2aa6f35e`
- 04-VERSIONES-MULTIIDIOMA/facebook/dominicano-ES/LEEME-de-la-carpeta.md — `07dfde752ecd8f40fadf6632b54429c0ba1ed99cd63ef77863507c39ba19018f`
- 04-VERSIONES-MULTIIDIOMA/facebook/frances-FR/75-El-podio-de-la-mina-Facebook-La-Bandita-2026-09-15-frances-FR.md — `6819c1afb6651c067d3c68cf3d01c81feb328968ac529a177040a5b1be800f68`
- 04-VERSIONES-MULTIIDIOMA/facebook/frances-FR/LEEME-de-la-carpeta.md — `5e500405e9d8573a15e2733900b686e5eab389434b39669fc85d6365c5041471`
- 04-VERSIONES-MULTIIDIOMA/facebook/hindi-IN/75-El-podio-de-la-mina-Facebook-La-Bandita-2026-09-15-hindi-IN.md — `bb713127b2d6e1be336c5d114ba7c776da1b94ccecd702d6dbe3a4bad1e1a952`
- 04-VERSIONES-MULTIIDIOMA/facebook/hindi-IN/LEEME-de-la-carpeta.md — `f3004983503de96fd911720b8564e6e699d72a23a26e716bc05a74e8c997c43a`
- 04-VERSIONES-MULTIIDIOMA/facebook/ingles-US/75-El-podio-de-la-mina-Facebook-La-Bandita-2026-09-15-ingles-US.md — `0c06d85ae0d689d3346ff3eb41869f4a6cc3ddd367ceb228c84030f996c6082a`
- 04-VERSIONES-MULTIIDIOMA/facebook/ingles-US/LEEME-de-la-carpeta.md — `0f61299f1e5a5133344d043b0de012f3ec2c5dcf7df2cccd2f89bcdb7454f5ac`
- 04-VERSIONES-MULTIIDIOMA/facebook/portugues-BR/75-El-podio-de-la-mina-Facebook-La-Bandita-2026-09-15-portugues-BR.md — `b62df2149a0db7d081cff0e77836c7737bf120965e3b55f433c4848e7ad50881`
- 04-VERSIONES-MULTIIDIOMA/facebook/portugues-BR/LEEME-de-la-carpeta.md — `1c5b66ea7af041dbf8795533df4fed13407d795103c8256a56a82204d025fee7`
- 04-VERSIONES-MULTIIDIOMA/facebook/ruso-RU/75-El-podio-de-la-mina-Facebook-La-Bandita-2026-09-15-ruso-RU.md — `cb4d78f9526e29933a64d9fc02a0cf2445f50f647b623458797ba94ec18c9e38`
- 04-VERSIONES-MULTIIDIOMA/facebook/ruso-RU/LEEME-de-la-carpeta.md — `a9963027dfaee9a103de4e743e1434a84a32d3b8ad91d84f39307b50225918f3`
- 04-VERSIONES-MULTIIDIOMA/reddit/chino-CN/75-El-podio-de-la-mina-Reddit-La-Bandita-2026-09-15-chino-CN.md — `8de15b770ed32902a91cba5c8f7ef97ea3b3d399858a97fb7c110c6910b817f1`
- 04-VERSIONES-MULTIIDIOMA/reddit/chino-CN/79-La-octogesima-el-techo-tocado-Reddit-La-Bandita-2026-09-15-chino-CN.md — `6535fb038b8abad3bf19c73b632037ea64d6e1cd59266c623565af8c079551df`
- 04-VERSIONES-MULTIIDIOMA/reddit/chino-CN/LEEME-de-la-carpeta.md — `569d985eb575d85f4ad7e781375f04284320865c1c3ba2fcf08d089d4a24956f`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/00-LA-LISTA-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `d85bd65827452c53164bbc277e3648cd8656b0f511a4cd54c621ddc648fd4a9a`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/01-Tiendas-de-APK-legales-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `5d01c90b63414df8a5195b89fdef413dfe6d52d6c0473b68dc1a62cb6a228ac6`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/02-Kototoro-manga-novelas-video-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `030d47ab9aa0d32b79d80f55d4cb33d3b0770a6d5b9f7034b5a47f5cffb01263`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/03-Verificacion-de-Desarrolladores-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `5dd8da3bbcba33d35163724e73883713f2d52f8bc2976e9c7725ca3624eb9fc8`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/04-Extensiones-tres-arboles-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `40a118e7051acf84e33ee660de42814e24ecebbfd965ea941f2ecafcd592cf59`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/05-TMO-cayo-los-clones-no-son-TMO-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `b19f4793266002fb093ad5f89298630feb28499c894f63ff387a2384439709ce`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/06-Forks-de-lectores-segundas-generaciones-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `c0f2671783ccaee55db0fccd469ccf9103b5f538718027096d7847ff4e2d668a`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/07-Usagi-viva-cadena-Kotatsu-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `42ad987f93ea957d7e060d25173b432f3ce67c7b58d3d2fef1b161ee2dd2fb4c`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/08-Musica-FOSS-clientes-con-repo-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `48515a3dca133a055f5a68a44eb3ab30264668ca44cd23f27ba120fc58d1aa60`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/09-Herramientas-FOSS-caja-de-oficio-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `5689d815002be197b8927acd546d42586cdde15d9d631313afedee9a1584cd19`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/10-GLTools-no-se-receta-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `66bedb0897be5587b3113a6dee79cdc3736dbbbaae9592e990205484e52d5f14`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/11-AniZen-vivo-el-espejo-no-es-el-repo-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `6e6d78668c37d3a4fc28ec651ac184b1d6d42a3c14602764401e8c19d54f3cc0`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/12-FMHY-wiki-de-pistas-no-catalogo-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `37926a5c4361f4f745e5654408b2abc849ae94bb33ea70443db0d59d3ec70642`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/13-Rama-Aniyomi-Animetail-Tadami-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `fafbaf324f96ff3f7b913cecbc636de663aff8aca3002e112bb00a29e945eac6`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/14-Rama-anime-puro-Animiru-Anikku-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `162d857699a3a550d3148e1a057969d759cf9eab0ee172333bf980172ac38bb6`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/15-Rama-J2K-Yokai-Rokku-Reikai-Hayai-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `97bb4b30d620d38f79464694cc0e31d22c14abb397ca60b21c71a18567bb6752`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/16-Rama-SY-Komikku-el-clasico-y-el-rehijo-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `d218d7069e02fa7a1126477b29605e5332dc029c317270032d27e897f67a6994`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/17-Capa-de-inmersion-aprender-japones-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `c8e7993097ee184662b4d0cc57acfee944266b2ef435651c64f410ce372b3d5f`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/18-Libros-OpenlibExtended-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `97ba465ac4e6fb392b853666783e0c699c8d507d1431c265f3deb1c7c78a5317`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/19-Panorama-multi-anime-manga-novelas-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `7550f7a1bbb0b8e7e3d4de64259babfb83dd7df7c372a10a01e9cd2597b3b431`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/20-La-Biblioteca-de-un-muro-a-75-guias-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `ef8a72cf3b5e204ca86dee13cb84d7af564524508ea75b596193cd4cdc08dc8a`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/21-Musica-I-la-cosecha-del-muro-12-vivas-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `a237bebbb6e01cc152dfa7eba55ab710fb93634130f5ec4c13a1ff58cc8f1c1c`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/22-Lectura-II-la-repisa-del-muro-siete-lectores-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `89c77b08fd280000c5cfcb395689e2dbd106e28d6a495fbb37222c9f9148000a`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/23-La-sala-del-muro-IPTV-servidores-cine-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `41d30670a885a8f87374f25df79c8e9d05d2c879f225019211fc058236c17135`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/24-El-taller-del-muro-Shizuku-root-sistema-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `3f627c308b775d6cb1e61addb2b307bfef8baee9123c0138ea3caacde036d2b3`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/25-El-sotano-del-muro-servidores-autoalojados-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `1949b56780516781d299ef830d23a790b6ce22df4c4861cff663d3ea23cf7235`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/26-El-cajon-del-muro-candados-adaptadores-miscelaneo-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `8bd7c4a3227a56a53f54a060507ef066d0434dffd49603163de3a270b56e4c9b`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/27-Musica-II-las-sucesiones-quien-hereda-a-quien-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `a6f1e96cf8799e31138eca1d4d59b66ad77997a0dd843803cf4c1cd84e78c324`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/28-El-tronco-raiz-gestion-y-tiendas-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `e54244d38552c23e73f298a4902386e21fd8e5b42ccfdce22c5da21f148f8149`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/29-Los-mayordomos-apps-perfiles-bloat-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `a7b90ae5c7317c55629f4e48552f9defb12c18a8368a5b15a782549db2713a6e`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/30-La-cara-del-sistema-lanzadores-teclados-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `490e5b395d9621e886de890eedc5cd96b5bb351d327501158cb299f5e355199f`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/31-Los-pequenos-del-sistema-una-sola-cosa-bien-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `f7a8badd2980917aba13a9c1041ec225ba034341aefc08646c2638548418b8d0`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/32-El-cable-y-el-escudo-conectar-actualizar-defender-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `6e37127503dcd0c1309ba73b27cc56e46bbd4920858fa02edbacec6a4564dce4`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/33-Los-archivos-del-taller-cajones-paquetes-guardian-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `7f958d58fe2c01023034d954240cc653f0229b5e473f315abe6ed330dc46816d`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/34-Los-que-tenian-otro-nombre-la-vara-de-cada-pez-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `315edf5a54344449ffe031efb4d98541497a3471f6b9b0f3e0202b0eab9348de`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/35-La-estanteria-la-estirpe-del-lector-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `886444559bea70748b638ed965b27e2795191629eb616f1b5eba8c4e3481f9d0`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/36-Los-libros-biblioteca-de-bolsillo-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `d3ca04f4169a4fa616e5884d7f7adec9d3accb6c83b5307441ae4eb694bde788`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/37-La-puerta-grande-anime-video-I-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `01e090066bf4921bffb7279bc62eb35579bec713ce3269b44f3d6657908d6568`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/38-El-vivero-los-germinantes-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `367c6f816cb2c613ef89cdbd7c61b954174bb9b2de0d1d3385ad46f90c247681`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/39-La-bodega-servidores-y-bibliotecas-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `793ef5dd5c5c55a28561ee703d6005ceb390d51212fec0057969d0f475175076`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/40-El-estudio-lectores-de-escritorio-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `68c25d6944cd0dd056fd0e9606b85739c088f724b34bfe53e8dc206894b28c03`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/41-Los-cazadores-anime-y-video-III-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `7bdce4339a5f2a0d368e49ad94b1a9962bf2bff2a2f6c2332c226813239f1643`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/42-La-fosa-lo-profundo-del-mar-sotano-II-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `24c95cbbaa250c2f9bbdb99f75b0cb32527a3834b9a3c2515bcac71382afc444`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/43-La-corriente-geografia-de-las-fuentes-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `a300bc193481e8c38680e98f79367ae94bc55930fc2f8ddef60e51f50e060b2d`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/44-Los-pequenos-las-casas-que-no-hacen-ruido-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `ee440efa0dfe663dd52e59ae814f65bfb8679f8fe99524a3e4d7eb650fc29b12`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/45-Las-canciones-la-voz-de-america-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `19d20a3baaea077b5fd060244339986d419fb13329024fec8eb498ea1c1858a9`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/46-La-sala-de-las-novelas-lectura-IV-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `4568d9d2ca895ce36afaa8b83a84a3ca02d0c81f372deeed37d3492a3e352dc4`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/47-La-ultima-puerta-del-catalogo-venera-y-veredictos-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `5a87c21b247b624b23c6fb362acbd7aa82a3e8d63ddb21cf7144e71c6a9c33e8`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/48-El-archivo-la-V25-vuelve-hecha-mejor-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `80cff1324d3e73f1753bb4f5f83f428c37efca1222b4e1df788d58a41af538d8`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/49-Las-mil-puertas-el-barrido-de-la-V25-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `f0c1a9791fb1d6a96a406ba6a8818037ef7900cc7076c88d9887a059b1702c0b`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/50-La-discoteca-I-la-mina-de-las-231-puertas-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `61a679406bbbc79676500a106eb6e056e8d406fc20b9790491ff77b7153cc5b0`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/51-La-discoteca-II-el-jugador-grande-y-Finamp-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `4eed7d49f7eab680a2dda1d948f364388bcbd9f39903f785ac5cbcf4bb76ee1f`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/52-La-discoteca-III-el-censo-completo-del-baile-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `48ca9019fd05c0339af662d03d8268fe0f206c2c0b0b2d2fe6775f77fa3162c2`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/53-Las-otras-forjas-gitlab-codeberg-y-los-sitios-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `49addafa5670f6db7f4cb7d59e1bc681e62c7ae98ce4963f97c7cf2aa12cfa21`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/54-Las-puertas-del-sistema-y-el-taller-de-la-mina-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `44648fe49cfde08785bf4478777decd6b732cc2ecc00a0fcfcc65f1bee11b14a`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/55-Las-puertas-del-lector-y-las-bibliotecas-de-la-mina-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `eafef095d1f9855af2c141a0ef1b6dbb525a8c20806c7bdba4c4c6ae682446cc`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/56-Las-puertas-del-anime-y-los-servidores-de-la-mina-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `4595db56816ca009e3085f764c99177e4d91b1432a51a8b1623d17abac9f8395`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/57-La-hornada-del-lector-la-mina-con-nombre-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `4b282033e4d163ac501f44ae28168948851b1f69b7c1904f848134ca9c3762e7`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/58-La-hornada-del-anime-el-segundo-territorio-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `4fbb0e2095eb372958701b3bb7abfcd43157a62d59ccfdcd899c9a77e6762692`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/59-La-hornada-del-taller-herramientas-de-la-mina-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `96521405d46661bc4e1638c3c97a817330dca63a24d77238343a43d12ef350a4`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/60-La-hornada-de-las-bibliotecas-los-ordenadores-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `97c7a4227f23c8187aab38e8499918035ce12e74b8e2cf8e9c930478d4205f8e`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/61-La-hornada-de-los-servidores-el-sotano-de-la-mina-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `4c5893c271df5e36a2f340cb6b5114e7f7f4713cb6e946fb6794a0a4e34c7d85`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/62-La-hornada-de-los-ayudantes-los-pequenos-del-censo-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `408dc11db3598f592ba372c2cfa989d442d83199b9b8fed82ce50d3c27733b45`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/63-La-segunda-fila-del-lector-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `a71ed9dcc6f7cf142eb4fb644d8f93610bd650340c0a9afb924fa5523a97a7b5`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/64-La-segunda-fila-del-anime-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `ba31b8c7163df6a1c5c0afec83896e84af99f7e04cf910b03a60cdb1c2f856e0`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/65-La-segunda-fila-del-taller-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `703a8ee4138bb029b4412fc5e1bac8125da879f2ac072d966953f37d7eb53d24`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/66-La-segunda-fila-de-las-bibliotecas-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `527b2ccce4bce7c1d73002e972ff238f6c01801eaf0f94a27c74d2c9a1b029f3`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/67-La-segunda-fila-del-sotano-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `f00ff1ab18b255cc7aaa263d9812eec7a9b4f27cc75aad663bec8f121e28e257`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/68-La-segunda-fila-de-los-ayudantes-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `aec126dbcbb8b44ba238db90c2dd5a6ee795bd49837f471b8bf79a2c08ca0300`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/69-La-vara-de-las-forjas-I-gitlab-y-codeberg-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `5b5cfd36ea280a9c496ef1a0f1d2406031167c28a1a26f1f2ea99e694c2b854e`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/70-La-vara-de-las-forjas-II-fdroid-y-las-tiendas-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `8a0760646ff5d7f1c6b965bf797a4f97368382118a9f39413a597f6b6e78b56e`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/71-Las-puertas-calladas-los-ceros-de-verdad-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `35e677fe818875f34e0a338a387703a75cfab1e7ef07147765a099f2ac1cd6fc`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/72-Las-actas-del-censo-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `115709b55cfa17b61d9f36cb4178842dae0c2ea44a8e9f18d6481237537b2cb5`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/73-Espejos-homonimos-y-mudanzas-el-libro-de-los-nombres-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `38b04423f954e7ea95b45bb5c29a950358efd944c25aa5cb21f4b0a0898fad84`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/74-Los-vivos-de-la-semana-la-fila-de-las-fechas-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `3da5cd3aca392e94126a794fe6e6c25197e94d545f2737100c61d9e098817b89`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/75-El-podio-de-la-mina-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `882e65fc2fbeb2639de723d5e530482cc25b817409eb303119c73673af9f6a82`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/76-El-recuento-de-la-quincena-la-arquitectura-de-las-ochenta-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `553d2e7d6bf7a2de5f82f1b79de706742a320a15a17d7eadd7b39bc388fe496c`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/77-La-frontera-del-lunes-lo-que-queda-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `d9021d74eb5116671400e0a9c2fb888f90007bdbd32f3e5fa5bcc88011591927`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/78-LA-LISTA-del-techo-las-ochenta-en-una-pagina-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `52cf090ff5fb846d23cd9f6fd533fb8be39f5cd2f1c41994bf863fd98c6b607a`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/79-La-octogesima-el-techo-tocado-Reddit-La-Bandita-2026-09-15-dominicano-ES.md — `ccfad16f73774b87183e8bcc9327d976b5e15f6d7e42a420219caea749180cf2`
- 04-VERSIONES-MULTIIDIOMA/reddit/dominicano-ES/LEEME-de-la-carpeta.md — `c96558f015ffc636fef64476b5ef6f6d8116a0577700e1bec2c025f52b3b4dbb`
- 04-VERSIONES-MULTIIDIOMA/reddit/frances-FR/75-El-podio-de-la-mina-Reddit-La-Bandita-2026-09-15-frances-FR.md — `b4e6c98cccec67f4ce29548f5fa3c15d8af2e32524b4ae77647ae179eeb879d0`
- 04-VERSIONES-MULTIIDIOMA/reddit/frances-FR/79-La-octogesima-el-techo-tocado-Reddit-La-Bandita-2026-09-15-frances-FR.md — `9e9542c4e87eab884eb78ea927371acc8667434e303853f80da03bbb399b2385`
- 04-VERSIONES-MULTIIDIOMA/reddit/frances-FR/LEEME-de-la-carpeta.md — `dd03211a7c5d80e02fa5b28ebb943481320c9bcae01861e8a4714c0425801a32`
- 04-VERSIONES-MULTIIDIOMA/reddit/hindi-IN/75-El-podio-de-la-mina-Reddit-La-Bandita-2026-09-15-hindi-IN.md — `dc477c9d143eafeb0b835a5175f2ec50021e0e1751858f91ca8ccf1ccd59cdc1`
- 04-VERSIONES-MULTIIDIOMA/reddit/hindi-IN/79-La-octogesima-el-techo-tocado-Reddit-La-Bandita-2026-09-15-hindi-IN.md — `067dea9f60ed15e4c9d362dfd512c2e8466bb474d566406f2b98924498ca2dd4`
- 04-VERSIONES-MULTIIDIOMA/reddit/hindi-IN/LEEME-de-la-carpeta.md — `7c26dac041b875100e2eba154fdfbbc9b12d4729fa7e8fdfc2b35ed36e176b58`
- 04-VERSIONES-MULTIIDIOMA/reddit/ingles-US/75-El-podio-de-la-mina-Reddit-La-Bandita-2026-09-15-ingles-US.md — `a27942b95831d2f1b1a27d9dad628b76214c673873bc2b7133311ceca2d8f97d`
- 04-VERSIONES-MULTIIDIOMA/reddit/ingles-US/79-La-octogesima-el-techo-tocado-Reddit-La-Bandita-2026-09-15-ingles-US.md — `28fe54c625c55dbb40d1838f63e82bcd9c80c2ce49828232a306d5ecb60a59af`
- 04-VERSIONES-MULTIIDIOMA/reddit/ingles-US/LEEME-de-la-carpeta.md — `91b961c1acefc478e80fe7b8732fc105c494de859de5197fea274629c1a1d1b7`
- 04-VERSIONES-MULTIIDIOMA/reddit/portugues-BR/75-El-podio-de-la-mina-Reddit-La-Bandita-2026-09-15-portugues-BR.md — `e5ea191d6866448cb84cef859129ce07d80ef69e2e4bd9aad2adcbe9eff5ec97`
- 04-VERSIONES-MULTIIDIOMA/reddit/portugues-BR/79-La-octogesima-el-techo-tocado-Reddit-La-Bandita-2026-09-15-portugues-BR.md — `9b037cc473d9eef51606b40a47da265a5470ec9f648691c4d95a72464ea1c4c2`
- 04-VERSIONES-MULTIIDIOMA/reddit/portugues-BR/LEEME-de-la-carpeta.md — `56e03d251fe1037173a8355ec963f890550384c673bbbae783b062c2804248ac`
- 04-VERSIONES-MULTIIDIOMA/reddit/ruso-RU/75-El-podio-de-la-mina-Reddit-La-Bandita-2026-09-15-ruso-RU.md — `af465b2ca0aa43a96d0eeb845506cf16461998894ca010a9fe8b9f23492d622c`
- 04-VERSIONES-MULTIIDIOMA/reddit/ruso-RU/79-La-octogesima-el-techo-tocado-Reddit-La-Bandita-2026-09-15-ruso-RU.md — `620f71b52393967c324fa13efb58c44962fb199960ae59e471e32efce29b924d`
- 04-VERSIONES-MULTIIDIOMA/reddit/ruso-RU/LEEME-de-la-carpeta.md — `f8cb694f627d8e81135ad061f9ad4f85e30a8f5b682a96c1346e95adc693dd77`
- 04-VERSIONES-MULTIIDIOMA/rethubs/chino-CN/75-El-podio-de-la-mina-Rethubs-La-Bandita-2026-09-15-chino-CN.md — `757667fef7494799582bc3e299ad215704225aada44d38dd24e4e354ab1b9213`
- 04-VERSIONES-MULTIIDIOMA/rethubs/chino-CN/LEEME-de-la-carpeta.md — `940570b090184b7c657c255c230e2e71df4e312a2f7b7216c6917a2213e0f8f0`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/00-LA-LISTA-indice-del-ecosistema-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `957f745b1312cc6abf0d146c70f825ff7b3e7bf1d96c07deebf0610d526def7b`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/01-Tiendas-de-APK-legales-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `d5ea7afa0cf52416a8a41affbddb84ab3b8ae4ffa067880211feb4bdd5d69f57`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/02-Kototoro-biblioteca-multiple-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `2068862832da0b2995f23599489c6b8917d9cd7c0fd183957ee1ded39a579453`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/03-Verificacion-Desarrolladores-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `b5a9c696075de603a1b1332bb83a8e4bcfbcf9ef6edc3605d7b9637861f0483b`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/04-Extensiones-tres-arboles-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `9f73a3ac2e095e5394279fbf469a51583652d0a83371f487098cbffaaf838480`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/05-TMO-cayo-clones-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `f4db551804d753a000f189df9e369fbf22f8ae10d16e15d4d4ef229a65aa91b5`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/06-Forks-de-lectores-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `1b165d028fac951a7774f969f07a1e30e9239228f6347e385f224cb6e3620b76`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/07-Usagi-viva-Kotatsu-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `9ad78342016acb6718d534cef5f1f1c2390e2b638ad3029bc4d32c1b39b4da0e`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/08-Musica-FOSS-clientes-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `6c86bdd1724ae070f01d31f1414aa9600964135f0d6746cb3c99aaf4b41499a0`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/09-Herramientas-FOSS-caja-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `df1c6593dcd6564ac87a5c7cb4b68dea1b203412d3dcbebc1b37768f47f21b4b`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/10-GLTools-no-se-receta-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `f5da860b9343d27b1b5dcbc5b900d3587bf9ef72afc6710b43bab95004d11c23`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/11-AniZen-espejo-no-repo-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `76e2172775a1e8302657511287d187aa6f466b9a4d27955b1728bb2878b1d8be`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/12-FMHY-wiki-pistas-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `176e6c70693d795cf848c8079121fb6ce742f51578f34f3e18e9ee97d1408530`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/13-Rama-Aniyomi-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `24d728e86de3ed03214d5f34b7ed8ccc2418c485ac3ff57a99e820677ba31836`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/14-Rama-anime-puro-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `94b5bb1a37643cbf2b715d289b6f630a6175804bfe37b35d19225a9f656d1c88`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/15-Rama-J2K-abuelo-volvio-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `28fbd1a7186cd2f448a11d77d3a551d49061cfe83ec10944b37d661786648f68`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/16-Rama-SY-Komikku-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `c0dafd5eadc80111310ce0341199d2f180c4d6cba03ec6fa48f8f07175d52a71`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/17-Capa-de-inmersion-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `c9cc821166555c5548f7ae213cddc54ae92758e5b1bd82e5623d59f183a4de81`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/18-Libros-OpenlibExtended-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `8774a71f2c928ff1ab71cb883055c83b13f43d952e89f61e0c36f21401b49662`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/19-Panorama-multi-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `2ab3ed6c41d15d4ee125754c53a07ed1dd1c2eca8ea5880f9f765530c8f54a81`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/20-La-Biblioteca-plano-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `af70b80c77fc51658a200c430945ec0204c392721222ebc26400788e02ffbf0c`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/21-Musica-I-cosecha-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `ed8c2d727c018ced2e41467d20af96b74997a28c1c267f40e2397fcf631ae79e`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/22-Lectura-II-repisa-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `54ff1531fcf1c10b2a87ae9404127dd821f65a6d50b0d7d364e611b6d1d37377`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/23-La-sala-IPTV-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `8a1f9243946781d9e7f33eafe57591974ee4bccef80474a9a80d83f0d9494104`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/24-El-taller-llaves-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `0e03edde7e53a98fbb35ea6460df01abea21f8dde49b3a70f62f5f5a17699eb9`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/25-El-sotano-autoalojados-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `99758b96f708c1c493dbee8a1a49b7954e6f1af8f5f59f7809a3b8fc9aeb6d30`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/26-El-cajon-miscelaneo-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `9530bd628e64d39aebcc67babc18707510bb37e2de6de462fed3a48704023770`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/27-Musica-II-sucesiones-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `265f76abbf5dbbaa3cc2ac34fe1f783b52198b84d46b97fbf6999b0e1bcf0056`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/28-El-tronco-raiz-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `9610a3117f8fddece543749605733336ad4167890f4e8f33e537b123daaabbfa`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/29-Los-mayordomos-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `cd943ca3e63ade8a3fc0ca9e5aa2253ee6e4f8368d7b59be5ad89bbd2c7f0c62`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/30-La-cara-del-sistema-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `4f7a48727235b3cd75a00b55e0d9fa3b0e6d9d7dff510bd256e6afb9e630019c`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/31-Los-pequenos-sistema-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `37bf520d105ca5102873a62b5923744d9213895e52e2967804f2c85653f8b6e0`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/32-El-cable-y-el-escudo-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `8f0b184dcec9b722bab6afa947f2a49addca48732c618f9c2e667ed566cde553`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/33-Los-archivos-del-taller-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `788bf7083834a2a3a9a1d21cd4988c694f6c01bb559d356a7405e16d95be3a9a`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/34-Los-que-tenian-otro-nombre-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `aaa37bb387d852cd00b9c98041533c03277eb60f9003328dd2ef8511f014c5ec`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/35-La-estanteria-estirpe-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `8cffc9c1d6e56b05b2193a914f67de22d343df277ea4d764fa123648957268e8`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/36-Los-libros-bolsillo-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `b2c50c1cbec066d3c1ea0242290ee0ddbe958a92eeffba25494a593a0135b200`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/37-La-puerta-grande-anime-I-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `1b80c3cea390da6ac1d65338e667d6e1dc33372be4fd4b45951be0072aef309b`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/38-El-vivero-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `2dbbf264295df4b922b2eed0a2cfbb48ded73b91f43a8c214c4c2bb020d1dd2e`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/39-La-bodega-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `990b1a884d48457a0680d0b0473f8d18e9c05d6212f236c3135db8aff8eb835a`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/40-El-estudio-escritorio-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `da9662574a21f08f30d6b52be6b9a96c02c57a114bc2355e9673855ca22887ab`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/41-Los-cazadores-anime-III-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `826f0a4da0859efcf8becd177a6b0d869417eb9d457b4eb63f65d602356cfe04`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/42-La-fosa-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `e3c0f1218b726a19c2996249aae550c09f90b98f3a99ecbbff45786ef24f8a19`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/43-La-corriente-fuentes-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `b5d45f1f7a86fff6f760f34e3c6a922de91e27610703af33bfba39068daa89e9`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/44-Los-pequenos-sin-ruido-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `a2f87c6762368771eddeb8b3afeda573b5d6c7626f943ae7bdb64f888a7dc817`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/45-Las-canciones-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `4e3abcae7118dcffb0146fb587699b7464e5143a2316fcef006a1697b3d3dff6`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/46-La-sala-de-las-novelas-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `573c1167e9ec1a0f607d69382046f82a75abfe0f6323d9a7cad488f7464a1cb4`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/47-La-ultima-puerta-Venera-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `00d6489f4b37e2f36f7b2598abec85e223fd8a5700e859734471dba6adc710e9`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/48-El-archivo-V25-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `056aed46efb41c62ef2e473ce270becf44ca35b496b842e8faf799432832a927`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/49-Las-mil-puertas-683-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `7ad472eccb4ad6757851b19e7c1d70b91769c4a8aca7ccc7ebdb17dc5d53757a`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/50-La-discoteca-I-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `1081af191da15bcc241874f286b20e973af5afc429aa271f8690be44430422e6`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/51-La-discoteca-II-Finamp-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `e82bf1c45e647f1679cf01265d21b0bdeebe27cee61798053307f4db91624c83`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/52-La-discoteca-III-censo-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `ddbdabd5a2eb4e65145c36036cdc785271a59b3d40fdcbe610ab030f1338899e`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/53-Las-otras-forjas-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `c6aa7df9a4b10d5b5c7f7c0a1fc6fa0f1422ed507afac41957986af963e528c0`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/54-Censo-sistema-102-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `8f97c03c90e32428e89e1f9c5a5467ffa8b3a86f13b68679fcce9fc69c52043d`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/55-Censo-lector-207-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `d20775f7fb4b9969c5c415c6f581f994a2cfe251cb4c1163a958f752f57877f1`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/56-Censo-anime-186-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `4ee987c248af47679cf162e96e17ac423540a4b358e361a1f84ee43ee921fc77`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/57-Hornada-del-lector-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `51533791fdf87180043ee29adf22f92b034839fff2136d94782e2bef2aac8a8b`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/58-Hornada-del-anime-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `3dc760874c14c3ca34e7dc7bc2494786f330a9d14b9bf25c068ede65bfd9d1b8`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/59-Hornada-del-taller-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `1928b37a6826f75abf127fd71be6e3898f4e801810e423576966691916ffeb80`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/60-Hornada-bibliotecas-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `2db2eed153cd552930b3b56d830372491c8d06e4278fa06a9b40f4b37f7e4ee1`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/61-Hornada-servidores-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `3798fa079772f54a46ce4bb732bb74ec9e35c20d0e6d6c933435dcaeef4283b6`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/62-Hornada-ayudantes-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `6eaec956caaa9fdc5c2011137cf004dbbaeac31aa9580b3de0bf335a0971afe6`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/63-Segunda-fila-del-lector-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `7c74cb4a39c877459ae5c5ebc18a820980173506691e48417ebcc8345e9d518e`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/64-Segunda-fila-del-anime-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `0b4df29eecb1cb04e7f82405e92f8a629ea2dc97954a4b8d0fcd8f1da5784011`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/65-Segunda-fila-del-taller-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `b441889391ff5313869c289f1f26c45e7818a156d7f16bd616f6aabfdf99df8e`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/66-Segunda-fila-bibliotecas-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `21903c1c0164e77306a34f8cedd041059840d947b084eb7719ceac83b12c1daf`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/67-Segunda-fila-servidores-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `1c3123113267bad25e006732a9be661133875f091e4bcfd4f22384659439b084`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/68-Los-canes-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `0c509d3033acdbac43e8cdc2cb5394d91bd10ece14630a50a497d1197401fa7a`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/69-Vara-forjas-I-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `642b1e1e35ae3b8bdf75ab6fb3cef09e1adb9ca8b4dbd8e2876b082c5eaeaabf`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/70-Vara-forjas-II-FDroid-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `0e7ef2e7a78d0fa46e53494a6c332e921b095cb1601a474f5847ba4e31e4a5b1`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/71-Los-ceros-verdaderos-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `8103035c729be1644fb0d227e9f9669de3170e61abe26dc2e8d2d10b3a9448d3`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/72-Las-actas-del-censo-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `7dc058bbbdf8017ecdc97053e764cad49b0ea96bb2759b02e237898ec37fe0a0`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/73-El-libro-de-nombres-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `48fc00496bda836c57cd670552610457c68cfbffa9abb197967efb2a003ea85a`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/74-Los-vivos-de-la-semana-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `a5835aecf33d888a22ee04713aa60e206d77115455622b23af182133c107da91`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/75-El-podio-de-la-mina-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `102274f8bba967f2dddeaf79d9149c4497b9fd63d73e564ca20ee7e4a9977809`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/76-El-recuento-80-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `91459b4db9a9993049885f6723bbd727643e0cb1d70de6e497be792fe5fdfbbb`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/77-La-frontera-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `ecd9302d0fd9a7cd653520c0fd87984581b20a7c6d324a72c760a3e89881143e`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/78-LA-LISTA-techo-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `52290234d8f3cfe178a3f0f158cc1043d6b4d4e8e22e5341c0b76fb0ea334392`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/79-La-octogesima-Rethubs-La-Bandita-2026-09-15-dominicano-ES.md — `9be7cbfcd4d72560ef2355e73c210a92d28e570f5b409843448016f83b7413a3`
- 04-VERSIONES-MULTIIDIOMA/rethubs/dominicano-ES/LEEME-de-la-carpeta.md — `781577dc7cca8ec9c5c7f6fa0062e102253563845eed080bce92e749430b0220`
- 04-VERSIONES-MULTIIDIOMA/rethubs/frances-FR/75-El-podio-de-la-mina-Rethubs-La-Bandita-2026-09-15-frances-FR.md — `539178350be95197d7a1ba0ef70f4a9f9a6caf4b56f70e4d0ea47307cfc978ff`
- 04-VERSIONES-MULTIIDIOMA/rethubs/frances-FR/LEEME-de-la-carpeta.md — `1fd06d867c6c788eae7c41cf16a87912bce57278f177b5dbab3d78bd48e8f08a`
- 04-VERSIONES-MULTIIDIOMA/rethubs/hindi-IN/75-El-podio-de-la-mina-Rethubs-La-Bandita-2026-09-15-hindi-IN.md — `87557251630b8442ba5afb9f3cdd875c635e8a2fb2c64f96e2b18eae178b9c41`
- 04-VERSIONES-MULTIIDIOMA/rethubs/hindi-IN/LEEME-de-la-carpeta.md — `4184614bc25e0c04f48b21b83bb537df389a8d87da0416a768d68820bfa6b639`
- 04-VERSIONES-MULTIIDIOMA/rethubs/ingles-US/75-El-podio-de-la-mina-Rethubs-La-Bandita-2026-09-15-ingles-US.md — `2e2c2c13b504adc0f263c3a05d0fbc982fd7c95c823f188f62d2f830e2b1935b`
- 04-VERSIONES-MULTIIDIOMA/rethubs/ingles-US/LEEME-de-la-carpeta.md — `10753b2e4d6fd060d1424057d2a9f3d91a9dcdc4b5625d4f61816daa0ed61040`
- 04-VERSIONES-MULTIIDIOMA/rethubs/portugues-BR/75-El-podio-de-la-mina-Rethubs-La-Bandita-2026-09-15-portugues-BR.md — `65545a6e2b380e762f7a0ff0ed385ba22d71f38d4ffaca398074117ba8a87f47`
- 04-VERSIONES-MULTIIDIOMA/rethubs/portugues-BR/LEEME-de-la-carpeta.md — `defd43ce93b28125ef5bb04196da580594f98a14995eb20fa06db6201dc66932`
- 04-VERSIONES-MULTIIDIOMA/rethubs/ruso-RU/75-El-podio-de-la-mina-Rethubs-La-Bandita-2026-09-15-ruso-RU.md — `a2227a7b22374225e60fcc021e3b303bee671ba1fe3dc62bb3f8fb3e4ade859b`
- 04-VERSIONES-MULTIIDIOMA/rethubs/ruso-RU/LEEME-de-la-carpeta.md — `a0731ab13f82fc7fa8066cf2bac4c0103f50afe9b160818b61c1a00c1a7e7559`
- 04-VERSIONES-MULTIIDIOMA/telegram/chino-CN/75-El-podio-de-la-mina-Telegram-La-Bandita-2026-09-15-chino-CN.md — `341a6c51a6a374c461efa45185840de1c9aabe5da0dcbeaa164dffa0e3755d32`
- 04-VERSIONES-MULTIIDIOMA/telegram/chino-CN/LEEME-de-la-carpeta.md — `247ac391d3b6f476e87b2cc868e0c4e6a641179248e46aa5c0caa0b3c385fc0b`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/00-LA-LISTA-indice-del-ecosistema-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `709b3676fd0403fe6d496b6b144a3cbc621ac7b7f7ed1fd83c9936d63ab3fe96`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/01-Tiendas-de-APK-legales-reloj-2027-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `ce5b2379e04e84b239ce13951356bb7c4e7fb679e928ff3f0b15553a6b60ce42`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/02-Kototoro-manga-novelas-video-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `7ac95d4fae3c721a5cc7721f25b092f06ce4008935a3f94df498224caf4a4839`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/03-Verificacion-de-Desarrolladores-cronograma-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `38f939389dab936a63229daeef28b763a28a3fd65cf0d8a50fcef602859067cc`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/04-Extensiones-tres-arboles-hubs-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `1527c1aadbb6bcbd04362086e5d1099a419cad10eed4b72d2bb2fae08c82347a`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/05-TMO-cayo-clones-no-son-TMO-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `7e69ae879673037f5db3aa8d9445bdc3dad859a554153426b55278ae4823bd17`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/06-Forks-de-lectores-segundas-generaciones-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `599fd65bc670fb80d12e6f5eaf3190081b9e2587da9f14587f0138924c415d70`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/07-Usagi-viva-cadena-Kotatsu-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `24ef8b3a2e90d7e617c622825faecac514ff6b53e01d051a99b0fbfe26a5706c`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/08-Musica-FOSS-clientes-con-pulso-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `c07c3c7a354733b82aee8aca9a629c847d8166d6bb075d4921029504c36b3168`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/09-Herramientas-FOSS-caja-de-oficio-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `98bbc5e64859dc985708be8ae8800b415aaa2b25ea1e714df39c7b43194d9f91`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/10-GLTools-no-se-receta-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `c7edd9c26c6d88fd8d64bed0a31a00f733dafe7506284562e3690762191ecca9`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/11-AniZen-vivo-v05211-espejo-no-repo-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `cb6a8c80271a9c27c5f35b29772827b49b5dd49994e7e866275e7e588a7b4fc1`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/12-FMHY-wiki-de-pistas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `9d2c7d67fd53dd42a006d36e8eaa1f4f99247e9428e2ce6a097aa359295ae840`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/13-Rama-Aniyomi-manga-anime-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `330088448fa18f74d908f9a01d504e774d8d8edb02a07c6d481444b3410b80b7`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/14-Rama-anime-puro-Animiru-Anikku-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `99d9e4f8a7212bbe4adc447ce76d7bb0135a6683a14ff3b21c6263c4298927c0`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/15-Rama-J2K-el-abuelo-volvio-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `9608d1d5f7371558bc8883a61c8547c3531b0ac55ed6cc7af1d991ba2198d9b9`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/16-Rama-SY-Komikku-clasico-y-rehijo-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `861834312f45e3cf402679a11f1b68778715bbf43442df889222bba61cc67b57`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/17-Capa-de-inmersion-japones-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `54137c8cdb4deaeb4eb626068364c8119a542a00a6c28e448002d19223958a0a`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/18-Libros-OpenlibExtended-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `02ceef68269b90d9ef39bc1b9a716f177f694b978dbe5b9409d9285bcecc7686`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/19-Panorama-multi-todo-en-la-mano-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `c8bb6ac73d00df45a62e3fc5b2d512c27b2303db40c2ba7c8c0a6c5d4e4ead5c`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/20-La-Biblioteca-plano-de-75-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `353a5a18583cc7f32d724e027720da67ad6bea619b4bb242e40dbb4ef5be6a87`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/21-Musica-I-cosecha-12-vivas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `9e85815d1264541a66d0da5d29a7375f51df8116f01a99ba77775dd6bdf842a2`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/22-Lectura-II-repisa-del-muro-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `e8af9bde7a958f7f91009601c6d996bf8682822870a9dd03c2c29a7a4cef30c9`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/23-La-sala-IPTV-cine-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `91dc22865107c8a3f3b65519467f5426d1f285702de5718e1142b82b62d342b5`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/24-El-taller-Shizuku-root-llaves-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `d1f252d8fd4884b7b06900bd51ee434e7c657166f443572aaef6267fe7835abd`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/25-El-sotano-autoalojados-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `65513227efb1a699bb43b5e4f7619876e4a5c71ba97f9fd6d0b8da8eea5a834a`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/26-El-cajon-miscelaneo-verificado-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `a7f9cc8479e9e4c589aa18b78d86dde7e2d8f01569a1cb49c05270c9a51385f7`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/27-Musica-II-sucesiones-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `4b007a06953074fd8a6dc3d20091ca47e28f2f106e24689e663cfbe6f87c23c3`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/28-El-tronco-raiz-tiendas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `b7b07074b92ea022bb6f346abd04a4b5da7033072541732d941d8a8f288f8ae7`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/29-Los-mayordomos-perfiles-bloat-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `fec379df0b87ca8b6e8bdf7acbcef3a6cb9822021d9a905d31e45ff5d6003007`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/30-La-cara-del-sistema-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `f487d48848e2f78519baf0e3ff09481ca406f85dcb0d538c9b379c87d4e02aac`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/31-Los-pequenos-del-sistema-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `6901b14a0c125a18fa0469e9df25ea68e6460df6b706c2fe57ac8d9dbd32a31d`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/32-El-cable-y-el-escudo-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `d21e9cf930827534f7c273da13c1151e8fe46232a9c9c4b95b7667d13c85d3db`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/33-Los-archivos-del-taller-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `43e4ec3e7a466df39e7112b8145e3017725db24f8bc92f544a47ff3e59739c4c`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/34-Los-que-tenian-otro-nombre-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `ccca43cd55e0a90fa2b7eaa55799f5b7fd3e3217dfa7c79f39b1420ad002d1b3`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/35-La-estanteria-estirpe-del-lector-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `0b6960f3daabc27f8c6a19f843fb7375a0213e4fbd35ce9584177a623963d278`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/36-Los-libros-biblioteca-bolsillo-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `82e114e895326971004c155df74bec89d97da6b030b909e980ed7dd82fb8067a`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/37-La-puerta-grande-anime-I-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `bf3062f0d93f5b8b5523850143fc1de7ca8d361797aab3c5e4a6e0145a384b88`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/38-El-vivero-germinantes-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `67ddc04908bf101283bdd0d5c531bcdfebad1777433ee04f6390e6e42da9c089`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/39-La-bodega-servidores-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `8afaf502bfb01b393dc3c449820965cf22024bcaa09036f6875f4f3c06d41fd0`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/40-El-estudio-lectores-escritorio-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `ed8cafd60be2837784447296bb42f8523255f1d3e410e14f1271df22241b9516`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/41-Los-cazadores-anime-III-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `8023c72096cb5b1a6de5fa5b62097dd7022d036f6acf6b962a80e15e499483f8`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/42-La-fosa-lo-profundo-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `6db51fad5aae0a003bb36651d00cce1eac0c5e332b945acbda483e431b7acd62`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/43-La-corriente-geografia-fuentes-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `dd38cc652b7898735eded5f37ea53652e17b8f2aef6d966059ca8dcf8d7e4103`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/44-Los-pequenos-casas-sin-ruido-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `f73b6a3c6da09b1c2a14bb30fa652b262acd85d58ea82c811d0c90fdf68b0ee0`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/45-Las-canciones-voz-de-america-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `71be258014a0dca40090734342ad28d53abdecf73e2cee6b899438e14371e920`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/46-La-sala-de-las-novelas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `1570dacd097a6bf99c56764de4eb80a316b0a2cb9786f18dceb6504d3507795b`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/47-La-ultima-puerta-Venera-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `98ed6adb2bcd247e0b0dfdf17084a0c53ff91d649f0f3ac8cb77c11a2910473a`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/48-El-archivo-V25-vuelve-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `40aff4107099ec66a77d81ecad5d2987dba7304560efbd301b65f992abdacf7a`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/49-Las-mil-puertas-barrido-683-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `d294a0ed076beb6aa1df12fa55ab46b1f1889687441a5280e99731f227d93ecd`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/50-La-discoteca-I-231-puertas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `ddcbcf77038e7dd060200878753f646958330c1be88d81d1f4158930d15b41ef`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/51-La-discoteca-II-Finamp-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `4a2133bce2f1ade04cc966bb162a7914698a35b47d53613d8452c5e2c0caa8d3`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/52-La-discoteca-III-censo-163-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `43f11e10ca93c4255a0da515512e703cdbffa12806dc61bab09139fde074395d`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/53-Las-otras-forjas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `508d59fd18b67ad2adf266b12b3bc60b5bdf94cd3b74cff9fe638904e92c71e6`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/54-Censo-sistema-taller-102-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `7a93fb2b3880ec9f09f9a6df5374094e6abb6b332c9c9282940cc69fb334e2d8`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/55-Censo-lector-bibliotecas-207-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `1a8626b70182b37803f1cb9956dfbe9de280710deb549b5b6793513a77682662`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/56-Censo-anime-servidores-186-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `811ed97c2453dc09fb48e92a429fafcf397e2da8b3a063693c0ecf2f80446d52`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/57-Hornada-del-lector-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `e9fea26e3e2cd3e3d20625cf805b56ce54ff518c17dd96a846558f45ebe77d31`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/58-Hornada-del-anime-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `a509682685984ddc19ee741e304df7e4894af3418556d57d9a3e3025d0113bc5`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/59-Hornada-del-taller-herramientas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `4ba95f90827717abc88296fbd8f5e8ff04c01ecbbdf5ad98ac13367e5bd291a2`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/60-Hornada-bibliotecas-ordenadores-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `525f4d0b2126f4a4010d517ee555d58fa5ec013f0e50e2bde5a1740be624e01b`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/61-Hornada-servidores-sotano-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `0fc3fef6d2a5bc5394007a4e1a359b6d94622421affbc1f5fe339e25289e04f2`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/62-Hornada-ayudantes-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `eaa5a4c43d0b8cd579e6551196d986d437d44f841dd8e540a4841da7e12109d9`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/63-Segunda-fila-del-lector-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `fe88bbef09f606f668e4a003124b1778eacd72f42bf296982e694c0f738200f6`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/64-Segunda-fila-del-anime-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `a49efcfadc88b8f38fe8433dea3cb5edcb9a85b4db45ed55987e29d9fa3f3582`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/65-Segunda-fila-del-taller-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `82b0529db26f814c44cef70e391733123181aa5b058460431ecbbdd93019c0a8`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/66-Segunda-fila-bibliotecas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `0ff61efa6cc557914f45359766fb3c7a4184e086b1c5f8770c66c8d93c5b5a5b`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/67-Segunda-fila-servidores-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `c960e45ccfe0f2ff79ab78808682ed06160ddb03a80273394847458b81b9886c`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/68-Los-canes-segunda-fila-final-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `881cff01d496dd5d24e1732c4226554ddfcab7db74caa2347f71e8a2b8e6f9b2`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/69-Vara-forjas-I-Codeberg-GitLab-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `599ed9ae8066b93ceaa072bc8f1d8b8b4d2139a4c7d6dcc7d317f2e3077d79fe`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/70-Vara-forjas-II-FDroid-tiendas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `99c8840d7a09cd2b6eee44ee40ff9fef25dfe756fec0b129be994c66dd6b43e2`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/71-Los-ceros-verdaderos-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `d240890397a471181ba33d1e1ec7d4c86a4da35ec26209993b7f72c8f08babcf`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/72-Las-actas-del-censo-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `3e681daf44ae8b615a7935fd9cf16bd35d3ca5d2332fa2c6138d6d7aaaa348c9`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/73-Espejos-homonimos-mudanzas-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `4aadbce214e684daedb3c90996bd20ca15a91a28ec87be6438e251d790450e93`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/74-Los-vivos-de-la-semana-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `e03a0c6222fb3107da9463cb1c25da1b0bbfde4a2dba6146b7f1e1d6d2c1dd0f`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/75-El-podio-de-la-mina-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `d6c69c2d31cd2189b98bac770d7cd15ff3c93efcb3b43d3d4a85c74679ae2802`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/76-El-recuento-arquitectura-80-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `7bf6ea707623356e9e72a612f666be6297e9ec457493fd65e46011a2464cc14d`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/77-La-frontera-del-lunes-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `1576a89f4c4394b728ab29627639801b1a7a117bd6d4620d15b7f33c9f1b1ca9`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/78-LA-LISTA-del-techo-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `719dcb21579b6cfa15d413b1975ba095242ee4474881a32bec5e1848b7c2fd2c`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/79-La-octogesima-el-techo-tocado-Telegram-La-Bandita-2026-09-15-dominicano-ES.md — `b89fe41908b2f7978df82767f8fab29308bb89d3204de2ef74fff6a98df7dc61`
- 04-VERSIONES-MULTIIDIOMA/telegram/dominicano-ES/LEEME-de-la-carpeta.md — `268ec0ae50ae255edb5b0f53ac0f8f36caf78d09f0d61d78658c3a1ed85adec5`
- 04-VERSIONES-MULTIIDIOMA/telegram/frances-FR/75-El-podio-de-la-mina-Telegram-La-Bandita-2026-09-15-frances-FR.md — `341e7d56e1be456ca7a734d4f5e980b6c7c80d47800632a4802a2c8584fd83a3`
- 04-VERSIONES-MULTIIDIOMA/telegram/frances-FR/LEEME-de-la-carpeta.md — `2fba788c75d17fd797b2fb6796fe9fcec99c6a487ef393903cc54399ec12fcf4`
- 04-VERSIONES-MULTIIDIOMA/telegram/hindi-IN/75-El-podio-de-la-mina-Telegram-La-Bandita-2026-09-15-hindi-IN.md — `2237c4042c45a33eac2fbdefb1fc50991df4b0a893b4b1fd5ee412a2355f3fda`
- 04-VERSIONES-MULTIIDIOMA/telegram/hindi-IN/LEEME-de-la-carpeta.md — `af3225b5a7477fb238a069f3f14e14cf7a984c9c415dfe94a1902c7a9c1703fe`
- 04-VERSIONES-MULTIIDIOMA/telegram/ingles-US/75-El-podio-de-la-mina-Telegram-La-Bandita-2026-09-15-ingles-US.md — `70e6031d354e79fd98412fa47569e9896a5db0b5b529c7a0ce44c6bae3f0be90`
- 04-VERSIONES-MULTIIDIOMA/telegram/ingles-US/LEEME-de-la-carpeta.md — `cfa1679ed012a3072701991196f7613a29dc554d31e6fa8a6760d208aa8cce34`
- 04-VERSIONES-MULTIIDIOMA/telegram/portugues-BR/75-El-podio-de-la-mina-Telegram-La-Bandita-2026-09-15-portugues-BR.md — `312d34f82bc625ce104e1eb94d72d07bed00bef28f1b38d4698f0ee017777ef3`
- 04-VERSIONES-MULTIIDIOMA/telegram/portugues-BR/LEEME-de-la-carpeta.md — `08aa0c6774cebaaf5d5d87e9eed6184fc7198d9aec2363573a0394605272b520`
- 04-VERSIONES-MULTIIDIOMA/telegram/ruso-RU/75-El-podio-de-la-mina-Telegram-La-Bandita-2026-09-15-ruso-RU.md — `fc03bbd2c6ee2990ec2957abc85377dd839cb9ce9f166a5d7b6ea4a5133c26cc`
- 04-VERSIONES-MULTIIDIOMA/telegram/ruso-RU/LEEME-de-la-carpeta.md — `513840bb44364fe842dc2ef7d03ca2ff67686859efdf40d1b83cf6f3b58f7613`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/chino-CN/75-El-podio-de-la-mina-WhatsApp-La-Bandita-2026-09-15-chino-CN.md — `c62594ef7c07991a6c66ffbf6cb9f300d1bd7c9e5d194940c9a4f573f9e567d9`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/chino-CN/LEEME-de-la-carpeta.md — `d5b758b326aaaaa02dea5f42498ddc28f0635546373ec105b9df8b417e03b3c0`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/00-LA-LISTA-ecosistema-libre-en-16-guias-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `fdce55412d0887b369bec2b72062e2ff0cb878f3afd2a9b0a01fdac7ef0324aa`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/01-Tiendas-APK-legales-mods-reloj-2027-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `b100c56d36aa7507c90e7c1b82825cb44e06c93097399488c709346f103c61e0`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/02-Kototoro-manga-novelas-video-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `bca6dbc90f83ad9b72ba60ff77dc72563b31df2a7583f9bbf3677c67dbd524a2`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/03-Verificacion-Desarrolladores-hito-30-sep-2027-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `39e433e4e0b20a6a9a8bee1f42779ec49dd6e5e78941946d3d7da2367418d4c6`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/04-Extensiones-tres-arboles-hubs-parsers-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `e7b90b8737d962c9fa333cad2fbe4ffc416a1a2a6f143c66f171c67052828f01`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/05-TMO-caida-clones-no-iniciar-sesion-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `8b9023146012796099b6bef50b24381bda9da29f59d4ff3553dc1bb558b8b539`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/06-Forks-lectores-Mihon-Aniyomi-segundas-generaciones-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `8b32c55a17907738b20d6cc4ea928f7b0e31971c79eb98881d3b2c3880957113`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/07-Usagi-viva-cadena-Kotatsu-Yukimi-Usagi-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `6eb67aed56d0973e1ee7f478712fdea8050630c9bbc028fffd9573be002523f5`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/08-Musica-FOSS-clientes-con-repo-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `17b9831f15df176e2969638aca1b4bd9d84cc5727fc08646f1c584fc07ddb037`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/09-Herramientas-FOSS-caja-de-oficio-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `074f0f845c62a97bd5691bdc6fcbb1173ea6aa796df9492fa7e4b083622d721b`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/10-GLTools-no-se-receta-spoof-GPU-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `92830e7241501560c5e80fbcca8d6353c1c1b3db439aa06171e6c5f021114286`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/11-AniZen-vivo-issue-no-enviado-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `e280f35e70a1d847dd412c0133423c492e9cd6b77a9b5ccb4b7104f614f3773d`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/12-FMHY-wiki-de-pistas-no-catalogo-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `804889096d1ea68c2764be3dc12244ed256394195e428c1a5169d78c74eeb604`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/13-Rama-Aniyomi-Animetail-anime-y-manga-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `9e4b14bb9ce030cc56775cffc40a6798d7451bbf2525a7a8afd3cdf174a866a8`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/14-Rama-Animiru-Anikku-anime-puro-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `5ec49f4ff907b173709a42f69f999187a4b2f30838d90693afea24ce28000eb7`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/15-Rama-TachiyomiJ2K-Yokai-Rokku-Reikai-Hayai-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `b3ec4c34c7fb6779913399f8ed2f22f06a4dc6d459359fd406e44076ac93333f`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/16-Rama-TachiyomiSY-Komikku-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `ef547c004931eee2e45bf33a0f0f8fffd4b635e865b4e37d6cee8058be7baab1`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/17-Capa-inmersion-Chimahon-Hoshi-Yomikai-Yomi-Koharia-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `8dbd63ac5321b45a7e66683f15183e8abfbea18a8cb71a60d59d40d2781a6cd3`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/18-Libros-OpenlibExtended-cliente-Annas-Archive-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `f5ffc6022663f5e886692614fc9d66a3d2aaf116fd3a363c1482db7cfd7123f4`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/19-Panorama-multi-anime-manga-novelas-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `b91b66d1806bc42ac339d9916287329ddb1ff04feb4b35182714cb8be0e5c612`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/20-La-Biblioteca-plano-75-publicaciones-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `890cc954e5f2d0cc7faa9672c9b0f556187b9b497757007dcf9216a888b47c8b`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/21-Musica-I-cosecha-del-muro-12-vivas-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `5aac38816f0972902569cddc3b8261f4d5315752fc124e89cd033da5764c8e87`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/22-Lectura-II-la-repisa-del-muro-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `745acd47cc18fe4051c9ca82d72690bba2792169f3d20be06889f38f82248092`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/23-Sala-del-muro-IPTV-Jellyfin-reproductores-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `b66d0efad6d3c2f1a75ebf347b5053e5b2355c728e99d8f2cd0d71c265fd0c46`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/24-Taller-del-muro-Shizuku-root-sistema-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `bf6b303938edcf2d440c7fd90c7e7a31b13254f119c9b3d8d93e378562bdc311`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/25-Sotano-del-muro-servidores-autoalojamiento-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `5745e934002f12770dbe063662455c5644f1f1d1fc87081e63ee57b385770ad4`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/26-Cajon-del-muro-privacidad-parsers-miscelaneo-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `f3747c364201f10dd164ca8689773762124ee78913db933f12319c0d8b76af0c`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/27-Musica-II-las-sucesiones-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `14bfce12082f3457d8ec7198b8d4e98e7a33f63797b506a5055a0e6d08683815`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/28-El-tronco-raiz-gestion-y-tiendas-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `581c3925423b748df5f686584502a3151fc31e344091c38a7d1f4c31c12b8dcf`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/29-Los-mayordomos-gestores-perfiles-bloat-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `61d63c7152c3dc10ff040bc4fdca5964bc47b8174a2233c457063e4266e6152e`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/30-La-cara-del-sistema-lanzadores-teclados-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `ce540ba2c482f66835585a10e2c8126bbbb974c8cc55e825549a5a1500092014`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/31-Los-pequenos-del-sistema-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `6ac5b730886f5aa37263e5620ef32f4294cd8300ba843826e98da32b6b64c89c`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/32-El-cable-y-el-escudo-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `4c280e7486f42095cabf2b0d45d6877e13128f1c181d4295888efcb9ec6968c9`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/33-Los-archivos-del-taller-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `d1a4123a0df89a9f0801fc4fb3b1cf08b2d2361bc80828945562d71fb7a0c03b`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/34-Los-que-tenian-otro-nombre-ambiguos-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `b7da9441284e0bc0e04a8ce50d56f9614bcdb31e2dc6b5c512351ee1858c9317`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/35-La-estanteria-la-estirpe-del-lector-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `1f549301fdb1ddfcac660603c665f76840f7ec4b8b0c915b718ea260692aac3a`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/36-Los-libros-biblioteca-de-bolsillo-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `83c9aa7226fd3e0b4eb23421b6f4e98cd6e43dd76f942ace4c2aadbd07db5a0b`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/37-La-puerta-grande-anime-video-I-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `896194a0e74778cf2e9a4952afb10b3fd2a21e49491022274769284fe7d2d283`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/38-El-vivero-los-germinantes-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `28bbd5a3379fc513d81b4c9339d3b5a5d06dc97f78846ee334ec35e9836d59ed`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/39-La-bodega-servidores-y-bibliotecas-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `5f496f87e89e9de750762ae6134f444afa1441df18a46380b66e9f7ab0737c73`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/40-El-estudio-lectores-de-escritorio-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `b3bd4aa25ae1404d91f294f49a215a08dd3bfb6124037b427e9e9a31455284bf`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/41-Los-cazadores-anime-y-video-III-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `983ca57a3b86ad8feb189951fde521c9c03be388cb16bf8c088864c3130d60e2`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/42-La-fosa-el-sotano-II-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `4368e5b71ba203d40b8efe382f33879a50bf20c31c847d9b25eeb2629d0f0f1d`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/43-La-corriente-geografia-de-las-fuentes-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `1b7d7eb27779855002e2c2f84482ccd5481c3b095179b35993202e15765d3d8e`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/44-Los-pequenos-las-casas-que-no-hacen-ruido-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `71cd01f9aa0c0930f2fac698f5e832066a0f8c49b8c611e3a67ce6d1314e3d2e`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/45-Las-canciones-la-voz-de-america-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `99150b9339b213feb56c7734454e115bc14adfd805f33a4386453c1ea5a80196`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/46-La-sala-de-las-novelas-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `8c3a89c0dd3fc71dccc3ab2932121471dbcb7862181d7c0e035cb2872575c999`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/47-La-ultima-puerta-del-catalogo-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `9dbd295366601e387e56df150e0eeeb85e6b88a6eb0a030b6d0239a08c01e8a5`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/48-El-archivo-la-V25-vuelve-hecha-mejor-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `bb2860245070c15a7bd9363359738459a46744ec65b6c4e1fc8f46f82a97b4e2`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/49-Las-mil-puertas-el-barrido-de-la-V25-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `e158eb9425a84d2de726a5fdf8e959b5a4234ed6f8bef599297bfa1440a11e7e`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/50-La-discoteca-I-la-mina-de-las-231-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `76a1e85ae1af167550f00a30280dd7b966f93cda81b573f2bf4b5a65d07fa137`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/51-La-discoteca-II-el-jugador-grande-y-la-mudanza-de-Finamp-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `5ce59041a374100ef1d288c1063e07a2ca146bd85d9faef6ea38da9db0c598b0`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/52-La-discoteca-III-el-censo-completo-del-baile-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `ab6e944dfb02005d9f6aa7181e273456db3423dd6e27683b48d2ccda033aa62a`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/53-Las-otras-forjas-gitlab-codeberg-y-los-sitios-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `ffea6b089c7c1f5588d3d1b2d513850cdcd0230e1eb3088e675c961db45b245b`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/54-Las-puertas-del-sistema-y-el-taller-de-la-mina-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `8ec271980fd6fb0f229c021bdec58f86f337f33379b99975bbdf5f2e3e678e49`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/55-Las-puertas-del-lector-y-las-bibliotecas-de-la-mina-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `c653eeeaa607c0a152eb9638e28583abb5d53f86e80ba8944313c65574c4c111`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/56-Las-puertas-del-anime-y-los-servidores-de-la-mina-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `aab5a7a2714eb8e149f8ca8aa47782b792af848f13d61840a521931c6d65d150`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/57-La-hornada-del-lector-la-mina-con-nombre-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `3542e60e2f54d9fac25ea65d5d226719f16c0e9fffb3ab17f90e603ef3d2a877`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/58-La-hornada-del-anime-el-segundo-territorio-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `9d366d23c08d7273d8130af8b902dd7d16e9b26bcf0aed5190beaa76e4092abf`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/59-La-hornada-del-taller-herramientas-de-la-mina-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `a3025ae63fb7ed9411d139fc5ccb53e86f54b83cf93de92c62c00e2d5147ec30`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/60-La-hornada-de-las-bibliotecas-los-ordenadores-de-la-mina-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `8acd8930deb17742ce30dd64a1dbad2ae31807240aa9e346f8084256f0928bb2`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/61-La-hornada-de-los-servidores-el-sotano-de-la-mina-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `1eb8b1d42fe132bc604ca6d0fed349756c7df45836e09e44ef26ba8946642718`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/62-La-hornada-de-los-ayudantes-los-pequenos-del-censo-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `0ad060fd565fe8a8f935568beac313d7c79d2cbd7bc9ee25c3f955e7604e2bb0`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/63-La-segunda-fila-del-lector-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `ec5fa79c17cd88781c6f1532ce73a0747f57a9256972c912e436bc6723367292`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/64-La-segunda-fila-del-anime-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `7e0a1467f2eae46b83328eafe2a738f344bca97baf53e8744fc018856e112b5a`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/65-La-segunda-fila-del-taller-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `c79ce4ece79b83b19aa4144fb3204a698310115e73f3cca8488e9eb898f264d8`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/66-La-segunda-fila-de-las-bibliotecas-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `c77857076d6c07f6cb9bf7e83527962636f01ea7ac94e35fb461e429c1acf694`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/67-La-segunda-fila-del-sotano-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `230a65934ec028f46170646eee5e2121ee6cc84597630c1f4af9e19b6af5a802`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/68-La-segunda-fila-de-los-ayudantes-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `74306b81e34ee79202bd3dbdccaf9c06e1e433e41f87e58a287f00baea1dda19`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/69-La-vara-de-las-forjas-I-gitlab-y-codeberg-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `4456a0bfe5ac62786728782564cb1e3cbb183a670e01f3928682b4a5247ac282`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/70-La-vara-de-las-forjas-II-fdroid-y-las-tiendas-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `81f555182dfd298a2432491880e8c0228527f83e0f42ade0ffd20939f9683362`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/71-Las-puertas-calladas-los-ceros-de-verdad-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `7cd0bcb98e23e763a8a1ff823d79eef5c0e82dc2b6ea09fe901727584cae2652`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/72-Las-actas-del-censo-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `73816c2606a7908932939777eeb00941905e0209d02ad2b86a6d75214a8229f1`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/73-Espejos-homonimos-y-mudanzas-el-libro-de-los-nombres-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `0bc3d0dd6b741c3b193322cd60749899716ea6cde22e94b8e50f5de6aa88a59e`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/74-Los-vivos-de-la-semana-la-fila-de-las-fechas-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `6f84982962bec11aa18dff57157adabc3ddd1c8b048775735276e4d7e0fa709e`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/75-El-podio-de-la-mina-los-veinte-mayores-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `1e3d09270bc312d0bbeb851d5ff4067517bcda3880624da1056c7c8a8e10ff42`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/76-El-recuento-de-la-quincena-la-arquitectura-de-las-ochenta-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `ae0b1de39337e34b833301b9cebbfd4254aecd8d27796efd7eabe7a37bb0df49`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/77-La-frontera-del-lunes-lo-que-queda-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `4e05a21f9fa0e8fe1ec9111ab5ae42d132e519ee7b649c3a76968ca65d60ec93`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/78-LA-LISTA-del-techo-las-ochenta-en-una-pagina-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `f05e64434133bd5543addc4c68f64baa0241a8dbd4df7698f2ae7ac28638fcf9`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/79-La-octogesima-el-techo-tocado-WhatsApp-La-Bandita-2026-09-15-dominicano-ES.md — `4d28abb85aa2c28955f432c3e78d8d980e7e91ef38ec37888979a4cd2aa6f35e`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/dominicano-ES/LEEME-de-la-carpeta.md — `aeac8e4d7554ea03664465ce1f27a096376bea72ac3da844cbf2470287a5d395`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/frances-FR/75-El-podio-de-la-mina-WhatsApp-La-Bandita-2026-09-15-frances-FR.md — `6819c1afb6651c067d3c68cf3d01c81feb328968ac529a177040a5b1be800f68`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/frances-FR/LEEME-de-la-carpeta.md — `7f87715ad046e6bf2db2dd2080d0a71f582a667eab7e74f6781f434305488484`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/hindi-IN/75-El-podio-de-la-mina-WhatsApp-La-Bandita-2026-09-15-hindi-IN.md — `bb713127b2d6e1be336c5d114ba7c776da1b94ccecd702d6dbe3a4bad1e1a952`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/hindi-IN/LEEME-de-la-carpeta.md — `069bd12d5d9d1a4c89fe18d3bf149c734c6e67664071adc6f347143bd2506d15`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/ingles-US/75-El-podio-de-la-mina-WhatsApp-La-Bandita-2026-09-15-ingles-US.md — `0c06d85ae0d689d3346ff3eb41869f4a6cc3ddd367ceb228c84030f996c6082a`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/ingles-US/LEEME-de-la-carpeta.md — `501276288fac85938a33e020834d9171a03c2eef58a28511829f4661c3ad22a7`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/portugues-BR/75-El-podio-de-la-mina-WhatsApp-La-Bandita-2026-09-15-portugues-BR.md — `b62df2149a0db7d081cff0e77836c7737bf120965e3b55f433c4848e7ad50881`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/portugues-BR/LEEME-de-la-carpeta.md — `23076ae790c3370941c8adc19ea6e9874da60efcb2a631b0274e7c5a2f8c0e5e`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/ruso-RU/75-El-podio-de-la-mina-WhatsApp-La-Bandita-2026-09-15-ruso-RU.md — `cb4d78f9526e29933a64d9fc02a0cf2445f50f647b623458797ba94ec18c9e38`
- 04-VERSIONES-MULTIIDIOMA/whatsapp/ruso-RU/LEEME-de-la-carpeta.md — `efc58c4d775be7cbc65c5964bf69b205e6a2add204f3f9d5d4872c9e93bed56e`
- 04-VERSIONES-MULTIIDIOMA/xda/chino-CN/75-El-podio-de-la-mina-XDA-La-Bandita-2026-09-15-chino-CN.md — `5c8ce3f379746cb14ff21c1829019df5445ca8313cde71cb36609f22b095d416`
- 04-VERSIONES-MULTIIDIOMA/xda/chino-CN/79-La-octogesima-el-techo-tocado-XDA-La-Bandita-2026-09-15-chino-CN.md — `416ee49841e13c36e9b1c7bfa85225f0c6e7784ac60fdb0681eef168f658d586`
- 04-VERSIONES-MULTIIDIOMA/xda/chino-CN/LEEME-de-la-carpeta.md — `65ee5df7de8b1a5d558c8bcda3924b1bf0cc96ed0b096de8cf0cb30e7a88d942`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/00-LA-LISTA-el-ecosistema-en-20-guias-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `97b72d19fb72efb7ea3126d2fb7438c7670aa2c1d70c350f85a598dbee3a9029`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/01-Tiendas-de-APK-legales-reloj-2027-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `31c9c07bb8caecc2c79b787a04284fc5ee5c35fb1adef0cb10c26ee4db54aeb4`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/02-Kototoro-manga-novelas-video-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `dc7c582a473d5231cc536a7b0e545f0c528844d5a562d6a847a5f5e2febacf55`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/03-Verificacion-de-Desarrolladores-cronograma-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `f3efc63ba0bb1f964d8ddeac15020c8084a7102f3f46bf5bef5be933896d6b52`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/04-Extensiones-tres-arboles-hubs-vivos-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `f939736ec6c0644108925fb2b71b457b01ef24dbfdf2b1e6759965d13a52ac22`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/05-TMO-cayo-los-clones-no-son-TMO-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `e2c0f6a79ce5615842a5a1db7660186258ba998d65fade2f560aa3c5258d650c`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/06-Forks-de-lectores-segundas-generaciones-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `033ac7be80d51b694491740a63608a105c212faa2183129906a55d4fe26a1b3a`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/07-Usagi-viva-cadena-Kotatsu-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `a2ba52fe442b9646d472e3ef52acfce19d62906fa2e3b192738699e7660e1446`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/08-Musica-FOSS-clientes-con-pulso-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `f5d9a0bbaffad4e77c971129d909ed48f3d02953e29d1c9145fc5c93de20f641`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/09-Herramientas-FOSS-caja-de-oficio-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `76f141ef942e71b08229d9c9190cb4dad058d23b1ce2fe8d08e89be767dd9593`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/10-GLTools-no-se-receta-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `6c0e5fd82c791cf28c249bec65d18fec18e5f70d841b42563ca7200aeb54aac9`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/11-AniZen-vivo-v05211-espejo-no-repo-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `bccd821b33daa689f561d057b92bd165ff443e999ac48654e8ec94aa5e05b956`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/12-FMHY-wiki-de-pistas-no-catalogo-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `2cbbc4399cf8a4c43ce7d0e371b9d572ad43444434eddd5ea7d82a05a3699516`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/13-Rama-Aniyomi-manga-y-anime-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `249eae92edf318be93bc5781edae64e110a5dbb4e498c713292cfbb1541a49cd`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/14-Rama-anime-puro-Animiru-Anikku-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `740f1c31e53cf57f8fbb661e8fcadbf4957a75d334e9d0383c7cba0ebe5b1a9d`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/15-Rama-J2K-el-abuelo-volvio-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `2d1908ec3d61541894b9101cd449a0df44666f3097ad3d011c917bca47f6fd31`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/16-Rama-SY-Komikku-clasico-y-rehijo-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `1ac234485a23e15725be75cae2a2459f5671f34ec4e6122ffa77c321dbd6cc8d`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/17-Capa-de-inmersion-aprender-japones-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `5a2c12b7991fcf5ff17713fcbf6e07c4f847d07bd3ab2b94f094e51a04399e69`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/18-Libros-OpenlibExtended-biblioteca-bolsillo-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `ca75bb569859da3d7c2d1f053606376c77da98a8d6004df7f5ebe91e94bf4c8e`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/19-Panorama-multi-todo-en-la-misma-mano-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `dea13a81f039448c2ddcb07de7cc0b52a61f2d9a91f98754d29a962bf0b9c4f4`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/20-La-Biblioteca-plano-de-75-guias-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `7a0f68e104143fa8005be282ad7bed96b14a891ca4662614c016cc786fa0497f`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/21-Musica-I-cosecha-del-muro-12-vivas-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `3a898ce6ee886a83e97db19490f3b1fb89abfe4d0fc5f4c9b55e91b2422d57d1`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/22-Lectura-II-repisa-del-muro-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `eed3c0c509d238fd9f3b8e8b692e34e4aeb1f95835ac8a676dbca1955096a9b2`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/23-La-sala-IPTV-cine-reproductores-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `e0e5e8ddc49144764ea435880e39275ec35eec2ac221203830e8c0ce36119007`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/24-El-taller-Shizuku-root-y-llaves-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `e88e4d049c483e304a12d89c576ae463cc31fa56aba79dba2f691c1822a716d8`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/25-El-sotano-servidores-autoalojados-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `fac9956262a15ffa0a090bcfc135f9601930e7c9651e0cbaf97812ab05970edd`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/26-El-cajon-candados-adaptadores-misc-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `9d1ee16e90aae26b03d1ea4cfb06754cb75497cbc2b4d42d7712529b4beb884b`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/27-Musica-II-las-sucesiones-quien-hereda-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `fd2b362eba2db220e4eb73c91f5237d42e07d6fa1a8ee199afc22018f5d118dc`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/28-El-tronco-raiz-gestion-y-tiendas-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `377bd02434ed929cb0b33524f57393830f81365174695de95ad9e6492c8eb508`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/29-Los-mayordomos-apps-perfiles-bloat-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `5c54d682ad947f791508e47cbb9acdc9209539a5005be6425e2512fe4840bd6a`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/30-La-cara-del-sistema-lanzadores-teclados-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `24f0ca2447300dc707e6a670c34649126546e693209061e03055a11570456c17`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/31-Los-pequenos-del-sistema-una-sola-cosa-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `ad6f07ae07464338f86d074ca7560074e53a35d155a83eee8b0ea6a77d00245a`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/32-El-cable-y-el-escudo-conectar-defender-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `ee32fc3092a652f5bd7d18c4dcbbb2df075f6448add52cfb16ffb93adc62607d`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/33-Los-archivos-del-taller-cajones-paquetes-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `4c2c18ae7308afd61f687cce4e3ddf11404b512a3b80137049ced41bea9a092c`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/34-Los-que-tenian-otro-nombre-la-vara-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `242cea55ce389ad7ead297b3822f225cef8250d6f2e82758e3384b005dfad2b1`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/35-La-estanteria-la-estirpe-del-lector-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `810995a8b68639d3be73f3154c11f62a92ca17afd74c9558c71725ddb4650d47`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/36-Los-libros-biblioteca-de-bolsillo-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `c3f4f6b42c7b9c4bf3faba46d0c3b2135ef86b368abe3c1d9877e4676cd974fe`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/37-La-puerta-grande-anime-video-I-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `979409a4991a4e0d1a89094135b7466e89eee98b9b2b5fe084bd2317475ff35c`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/38-El-vivero-los-germinantes-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `1f1af6e7e72492b44a4d6fb893d8d3dce777a5e46fe71a4a8f22788beb25ebc9`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/39-La-bodega-servidores-y-bibliotecas-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `ec8c0aa4fb8bc430aaaa0825d90cda5f3b95233322f375c7f51c0fc630403e9c`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/40-El-estudio-lectores-de-escritorio-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `5ca30db7999d4cb96a7ff5cee120a5dc3c57a7da5caa80088e4218e6394e896a`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/41-Los-cazadores-anime-video-III-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `4780a7e6f1f67b3794b031ab930aa9fee3638d28e035c8db10eaef6c4f9ea635`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/42-La-fosa-lo-profundo-del-mar-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `e1e1e73c9d19cb9d4bec2ce65bd3046e327f379563dfc9bca770c0a666719920`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/43-La-corriente-geografia-de-las-fuentes-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `581ad3203287ed2a571c1187825fb7194f292e30c323f2ff78556cf9df74829f`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/44-Los-pequenos-las-casas-que-no-hacen-ruido-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `3b9ce2d07acc2330858134ebf8a36cc6bb7b200238dda55770507c7138026b7c`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/45-Las-canciones-la-voz-de-america-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `ae12acb98c2d877456fca302f71e42b30d0337b08abbb1ea21432fdf116f218a`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/46-La-sala-de-las-novelas-lectura-IV-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `35f446c7d2dd3c3faf8ddbfce09a754085e1ce33626787946d54229ede34713f`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/47-La-ultima-puerta-del-catalogo-Venera-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `f85614e69e00951fb3cf9ceb69b65c7db673d04511e82edba79093a871a38dc6`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/48-El-archivo-la-V25-vuelve-hecha-mejor-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `982f18f5f394d95a8756179f90e0178c2e8f178dd407f81a0fde345fc1c1f83e`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/49-Las-mil-puertas-el-barrido-de-la-V25-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `2e375ab4700eff29d67e54abd39d4afa65084bd69160e6890f21bb6a023d5dcb`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/50-La-discoteca-I-mina-de-231-puertas-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `f38ce768e30916ecb1db9db79255900b6fd82663785987d0175bb3c0994e571a`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/51-La-discoteca-II-jugador-grande-Finamp-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `520da50dd08579bb3f5e58b97782ffcf6c297a1dc679f092b217184664b9eaa6`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/52-La-discoteca-III-censo-completo-del-baile-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `8696d628afc48805c32722a34a4db08e0c23132d69a7274389b34c20714b44af`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/53-Las-otras-forjas-GitLab-Codeberg-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `2fc7ba6d3e02e37eecc08bbac9c33ea5f82b3ba9111774cb018d0c4b6f93a30c`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/54-Las-puertas-del-sistema-y-taller-censo-I-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `60991ad2115a8848a286a6d03e6dfe3ab4462a701537073ed51940709839aa41`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/55-Las-puertas-del-lector-y-bibliotecas-censo-II-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `9c155af3326d98b9aaf302c101176905a0f3ed8e9f28991124aa46053c7a8583`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/56-Las-puertas-del-anime-y-servidores-censo-III-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `2dfde0e12aa39fd0cb50cd7d19703375e973ae48e6a01b26758d6a22c4fb218f`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/57-La-hornada-del-lector-la-mina-con-nombre-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `f004d1f77840de1680f2099f3d08b8a50bbcd92ad8e418cd10656616dff55f00`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/58-La-hornada-del-anime-segundo-territorio-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `36a887c47437f1cfa84087a82a99028ce1b6f65629a65a307a9ff2d7b604c700`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/59-La-hornada-del-taller-herramientas-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `0e8c12c11a184029a3ab0b9324fb90ca6725e3311b8fceadf9db13cbd26c1f36`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/60-La-hornada-de-las-bibliotecas-ordenadores-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `1b3832e55bfebb44dbf64ff32addaf2643393aecc335109f0f52bdd94c5ae412`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/61-La-hornada-de-los-servidores-sotano-mina-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `86779da3e11a418634577c87d828a1924c67215961de90d4b34c58af1c6b9438`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/62-La-hornada-de-los-ayudantes-pequenos-censo-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `29df7bf6a9e247a28de362a267a9511fd00916c2a2521b40ee8d9ba61e4953cc`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/63-La-segunda-fila-del-lector-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `0398571f6304f505133516103d67b458bbd4da75c04f31d30820cb3f1dc5d05f`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/64-La-segunda-fila-del-anime-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `17eef677d3ca16163c82c17a6a750163505fd5d71b427bcf2b6ad6706eb2a20c`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/65-La-segunda-fila-del-taller-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `8333e7915c39b39e829a5966188275f46b24598b94b496aa1111df1b4d679309`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/66-La-segunda-fila-de-las-bibliotecas-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `f17ff0fbcc38e4384dbba3193cc8950b0a14073d8eed7cd51a59b4b72a35947d`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/67-La-segunda-fila-de-los-servidores-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `48d6703b439447e8f0542bb59317cd0be3929ab87ecab45285ec342f20b25655`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/68-Los-canes-la-segunda-fila-final-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `1b92d4da433f9be8bda1b5fcc7bf27d1ad7ae08bd7537bbf3f688405fe18a156`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/69-La-vara-por-las-forjas-I-Codeberg-GitLab-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `4d219e8d0ea8bfd76bba6c5494b879278b338aad8a78b82210e74be2cd536ac4`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/70-La-vara-por-las-forjas-II-FDroid-y-tiendas-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `1c9383f8aaa3518a4d38699fd4229a7ef7593ea2ac73626e59c1e07c2ceacf97`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/71-Los-ceros-hermanos-y-nombres-solos-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `ab56ee1392df0833d44face333fac9963a18105c82025abb3dcfe75b35a5694b`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/72-Las-actas-del-censo-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `63bef82554d427a12b4c0175974127242d6b8bd1554550f3d4e9f4f54d57c855`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/73-Los-espejos-y-los-homonimos-libro-nombres-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `18cac8094db9958e4f127e067c6c32f53a979873c8ec6228a9b932d13f3419f9`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/74-Los-vivos-de-la-semana-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `161ed512c1f1a1f64f4cc7579e0c57ddd108a5daf00334ade7f9e63d56e8f458`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/75-El-podio-de-la-mina-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `0d1faa2de41f768e650b7df41951d77012557548ca14eff76aa5be4311f95e27`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/76-El-recuento-la-arquitectura-de-las-ochenta-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `75b3dc175fc56125b65e6e663e597faafd1138ffc635637f478d65381ef96f44`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/77-La-frontera-del-lunes-lo-que-queda-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `8cbfa72110f1926758538cc5ec6ba1606e1a6683f9164ae29744211b4b2e7383`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/78-LA-LISTA-del-techo-las-ochenta-en-una-pagina-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `2cfc8298a7cb7319a6e5f08e1ed1a9d82e8ed46016c282e9003d1a27bfc7ffb7`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/79-La-octogesima-el-techo-tocado-XDA-La-Bandita-2026-09-15-dominicano-ES.md — `68637185754c7868edc8442ac32c26a4b1e121833a779f00cb1a0fa319f9e2e1`
- 04-VERSIONES-MULTIIDIOMA/xda/dominicano-ES/LEEME-de-la-carpeta.md — `6ca421830979f8080e5038e0955fb2618bdf563e7194c4779ba8f61f3b8f4e61`
- 04-VERSIONES-MULTIIDIOMA/xda/frances-FR/75-El-podio-de-la-mina-XDA-La-Bandita-2026-09-15-frances-FR.md — `b414ecc1b12ada52e1f1bedcd033bbacdd023aabc3f13e1084f7a5b230819aaa`
- 04-VERSIONES-MULTIIDIOMA/xda/frances-FR/79-La-octogesima-el-techo-tocado-XDA-La-Bandita-2026-09-15-frances-FR.md — `d8b5c145d81f29fb7095d6597a3af64b1b011625cd427b0073c7a670075c7587`
- 04-VERSIONES-MULTIIDIOMA/xda/frances-FR/LEEME-de-la-carpeta.md — `75ba341347a7f28fe67bdd0168b770867440d390d3d0336a535f538d158b49d3`
- 04-VERSIONES-MULTIIDIOMA/xda/hindi-IN/75-El-podio-de-la-mina-XDA-La-Bandita-2026-09-15-hindi-IN.md — `5883bba877c9bcccefe2e1d87987affeae83c71f353ba4f533901ba9bd7292d2`
- 04-VERSIONES-MULTIIDIOMA/xda/hindi-IN/79-La-octogesima-el-techo-tocado-XDA-La-Bandita-2026-09-15-hindi-IN.md — `24b9ed2dbc3e0424d04292e389981ef6e47640169800b67d63ed77eee600d6f3`
- 04-VERSIONES-MULTIIDIOMA/xda/hindi-IN/LEEME-de-la-carpeta.md — `533471bd313dbbcbcda949b165709922fca1a80875088e5354245cfe1b6ca995`
- 04-VERSIONES-MULTIIDIOMA/xda/ingles-US/75-El-podio-de-la-mina-XDA-La-Bandita-2026-09-15-ingles-US.md — `d892153acc69f07149f03bb69629f76185bb1ddb4621bb8dd3c3367b4a564284`
- 04-VERSIONES-MULTIIDIOMA/xda/ingles-US/79-La-octogesima-el-techo-tocado-XDA-La-Bandita-2026-09-15-ingles-US.md — `5ac8b295ae5f43753b21c2d7a05dfd1d4de7195438d5414340bb5ed6a9919655`
- 04-VERSIONES-MULTIIDIOMA/xda/ingles-US/LEEME-de-la-carpeta.md — `97c96ec561b11977b1207fd02591d24ae52df1bdec62a6e3b46cd9d0b6fb9d2a`
- 04-VERSIONES-MULTIIDIOMA/xda/portugues-BR/75-El-podio-de-la-mina-XDA-La-Bandita-2026-09-15-portugues-BR.md — `0b2cf0bfa09f10474b045379aed331db4790380c5381f4f99183aaa4d6a4d8f7`
- 04-VERSIONES-MULTIIDIOMA/xda/portugues-BR/79-La-octogesima-el-techo-tocado-XDA-La-Bandita-2026-09-15-portugues-BR.md — `0aeefdb8cdf03bd1c4708925a6c7ba67f2b0abe9d31973549e584441105539de`
- 04-VERSIONES-MULTIIDIOMA/xda/portugues-BR/LEEME-de-la-carpeta.md — `62dd4bfa795c42d2b155cfd404f314568607284c04bc5b7afa2babe212c7fb4a`
- 04-VERSIONES-MULTIIDIOMA/xda/ruso-RU/75-El-podio-de-la-mina-XDA-La-Bandita-2026-09-15-ruso-RU.md — `e7b1b031dfe8cc925e8fa7b1c4da2e9dcf93ce8f13036eaacb21c2dd10e22c9e`
- 04-VERSIONES-MULTIIDIOMA/xda/ruso-RU/79-La-octogesima-el-techo-tocado-XDA-La-Bandita-2026-09-15-ruso-RU.md — `3742f9caac809650d8a384861bba6e8d39a9eab4b9ad8213639fe89cebb96005`
- 04-VERSIONES-MULTIIDIOMA/xda/ruso-RU/LEEME-de-la-carpeta.md — `ac8cb981c25186384b5530b6d376e0871fa20b620dda43419bb0b73832b355a5`
