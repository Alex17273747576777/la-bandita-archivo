# Publicación 47 — La última puerta del catálogo: Venera y los veredictos

**La Bandita · 15 de septiembre de 2026**

## 🗺️ Mapa de esta guía

├── ⚡ La última puerta, en una página
├── 🎨 La línea Venera
├── 🧩 Los remanentes con casa
├── ⚖️ Los veredictos del día
└── 🔗 Enlaces

## ⚡ La última puerta, en una página

Con esta guía, **el catálogo Miyomi queda contestado al ciento por ciento**: 133 apps — cada una fichada, muerta constatada, hueco confirmado o casa sin repos. No es un triunfo de perfecto (nadie aquí cree en eso): es un corte honesto que mañana reabrirá.

Hoy, 15 de septiembre: la línea Venera con su madre muerta y su hija inventora, los remanentes
con casa, y los **veredictos finales** — dos casas caídas por DMCA constatado, cuatro huecos sin
repos y una sin casa. Todo con acta.

## 🎨 La línea Venera

- **Venera-SSR** — ★49 · v2.1.5 (push HOY) · https://github.com/Kiastr/Venera-SSR — la hija de
la muerta, y no cualquier hija: «manga viewer with **realtime coloring, Anime4KSR and OCR
translation**» — superresolución Anime4K en tiempo real, coloreado y traducción por OCR, **todo
corriendo en tu dispositivo**. La madre le enseñó el oficio del cómic; la hija le añadió la
inteligencia de borde.
- **Venera** (la madre) — ★11.008 · **ARCHIVADA** · https://github.com/venera-app/venera — «A
comic app»: once mil estrellas y la casa cerrada. Su estirpe sigue en la hija — y queda este
acta: las estrellas no impiden la muerte; solo la hacen más citada.

## 🧩 Los remanentes con casa

- **Tachimanga** — ★41 · https://github.com/tachimanga/Tachidesk-Server — la casa certificada en
la bodega (pieza 39), ahora con ficha: «A rewrite of Tachiyomi for the Desktop» — la **misma
descripción que Suwayomi**: el linaje Tachidesk mantiene vivo el nombre fundacional. El
lector-servidor para iOS.
- **Suwatte** — ★225 · https://github.com/Suwatte/Suwatte — «Manga/Comic Reading App for iOS»:
la de TestFlight — casa viva, sin releases públicas. Se anota tal cual: quien quiera su puerta,
la tiene.
- **Stremio** — ★13.904 (solo el cliente) · https://github.com/Stremio/stremio-web — el
**parcial honesto**: cliente web abierto (v5 beta viva), núcleo cerrado. Se ficha lo abierto; se
declara lo que no lo es. La etiqueta manda.
- **QuickNovel-Enhanced** (NeoQN) — ★68 · https://github.com/Shadyteal2/QuickNovel-Enhanced — el
hijo mejorado de QuickNovel (pieza 40): descargar y leer novelas.
- **Nekori** — ★25 · v0.0.10 · https://github.com/Yuneko-dev/Nekori — la fork-de-fork de la
pieza 42, con su pivote declarado: «novel reader for Android» — la nieta de tsundoku que se hizo
novelera.
- **tankobon** — ★2 · v0.4.0 · https://github.com/mednasserallah/tankobon — el hijo de Mihon,
hoja del semillero: «Free and open source manga reader». Sin releases sostenidas: observada,
como mandan los germinantes.

## ❓ Preguntas de la última puerta

**¿Y ahora qué, si el catálogo se acabó?** El catálogo era candidato, no destino. Ahora empieza lo demás: el clasificador general de la casa — todo lo fichado, etiquetado por rango y clase — y las puertas que no salen de catálogo alguno.

El mapa no se acaba: cambia de cuenca.

**¿Por qué celebrar un cierre sabiendo que reabrirá?** Porque perfecto sería un callejón: la casa prefiere cortes honestos y reentradas. Mañana alguien lanza algo y el catálogo vuelve a tener puertas.

Así se trabaja mejor que lo que precedió — sin pretender ser perfecto.

## 🔗 Enlaces

- Venera: Kiastr/Venera-SSR · venera-app/venera (ARCH) · Remanentes: tachimanga/Tachidesk-Server
· Suwatte/Suwatte · Stremio/stremio-web · Shadyteal2/QuickNovel-Enhanced · Yuneko-dev/Nekori ·
mednasserallah/tankobon
- Veredictos: github/github-dmca → 2026/03/2026-03-23-fakku.md (Hentoid) ·
2025/10/2025-10-22-crunchyroll.md (Hayase)
- (URLs completas en cada ficha · el inventario del muro: paquete interno, Registro y Protocolo.)

## El meme de la última puerta

> —¿Ya se leyó todo el catálogo?
> —Se contestó todo el catálogo: cada nombre con su veredicto. Fichada, muerta con acta, hueco
confirmado o casa viva.
> —¿Y las dos que mató el DMCA?
> —Con notice pública y todo. Aquí nadie desaparece: se archiva con fecha y causa. La muerte
también se verifica.

> La Bandita verifica antes de recomendar: 133 de 133 nombres del catálogo con veredicto el 15
de septiembre de 2026 — una hija inventora, un linaje con nombre fundacional y dos casas caídas
por la espada del aviso legal. Las estrellas adornan; las fechas mandan. Y los cierres, se
actan.

───────────────────

💓 *PULSO 29-OCT-2026 — verificación profunda de La Bandita (Facebook 47).*

Alcance: se re-verificaron el 29-oct-2026 los repos y enlaces atribuidos a esta publicación: 8
repos GitHub confirmados y 8 apariciones de URL. La historia no se reescribe; esta nota añade el
estado medido hoy.

Actividad medida hoy: 0 hoy · 2 en 7 días · 0 en 30 días · 4 en 180 días · 1 dormidos · 1
archivados.

*Alertas de continuidad (verificadas el 29-oct-2026):*

• `venera-app/venera` — ARCHIVADO
· última actividad 2026-04-05 · ★11.299 (verificado 29-oct-2026). No leer como opción viva sin sucesor.

• `suwatte/suwatte` — dormido
· última actividad 2025-09-05 · ★236 (verificado 29-oct-2026). Queda como historia, no como recomendación fresca.

• `hayase-app/ui` — GitHub respondió HTTP 451 el 29-oct-2026 (no disponible por bloqueo legal). No se cita como repo accesible.

• `thaunknown/miru` — GitHub respondió HTTP 451 el 29-oct-2026 (no disponible por bloqueo legal). No se cita como repo accesible.

*Señales de futuro (novedad activa, no ranking por estrellas):*

• `yuneko-dev/nekori` — creado 2026-07-26
· última actividad 2026-10-24 · ★37 (verificado 29-oct-2026)
· Apache-2.0.

*Placas de control (por actividad y juventud, no por fama):*

• `stremio/stremio-web` — ★14.935 (verificado 29-oct-2026)
· última actividad 2026-10-28
· GPL-2.0
· release v5.0.0-beta.43 (2026-10-20).

• `yuneko-dev/nekori` — ★37 (verificado 29-oct-2026)
· última actividad 2026-10-24
· Apache-2.0
· release Nekori v0.1.3 (2026-10-23).

• `tachimanga/tachidesk-server` — ★44 (verificado 29-oct-2026)
· última actividad 2026-07-15
· MPL-2.0.

Enlaces web: 8 apariciones; 8 respondieron vivas el 29-oct-2026.

Vara de cierre: futuro y actividad comprobable antes que aplauso. La historia conserva su fecha;
el pulso de hoy dice qué sigue vivo, qué duerme y qué ya no resuelve.