# Publicación 02 — Kototoro: el mueble de tres cajones (la dos que faltaba)

**La Bandita · 29 de octubre de 2026**

## ⚡ En una página

Esta página cierra el único hueco numérico del muro: la 02 que nunca se había escrito en Facebook. Su pieza madre de WhatsApp presentó a Kototoro como el mueble de tres cajones del lector — biblioteca, fuentes y lectura en un solo cuerpo — nacido para heredar el oficio cuando Kotatsu cerró su taller. Hoy su placa sigue viva, y esta página lo firma con honestidad doble.

La estrella es modesta y la licencia que su puerta aún no declara en SPDX quedó leída y no encontrada por las rutas comunes.

## 🗼 Las placas al pulso (29-oct-2026)

• `kototoro-app/kototoro` — ★650 (verificado 29-oct-2026) · última actividad 2026-10-29 · licencia sin resolver · release v2.3.4 (2026-10-29).

## 📦 Las reglas de la casa

**1.** El hueco se rellena confesándolo: esta 02 nació el 29-oct-2026 para cerrar el número, no para fingir que siempre estuvo.

**2.** Mueble de tres cajones se prueba cajón por cajón: biblioteca primero, fuentes firmadas después, lectura al final.

**3.** Licencia sin SPDX visible es placa incompleta: se recomienda con el asterisco firmado, no con silencio.

## ⚖ La vara

Los números completos importan cuando el lector busca su pieza: el muro sin huecos es un índice en el que se puede confiar.

## El meme de la pieza

> —Falta la 02. —Faltaba: nació hoy, confesada y con fecha, que es como se rellenan los huecos en esta casa.

> La Bandita verifica antes de recomendar: pieza 02 del muro, nacida el 29 de octubre de 2026 con placas re-medidas hoy en su fuente primaria. Las estrellas adornan; las fechas mandan.

💓 *Pulso de nacimiento 29-oct-2026:* las placas de esta página se verificaron hoy. El futuro se firma con actividad y licencia, no con aplauso.
