# Publicación 102 — La foto VII: los invisibles de la foto

**La Bandita · 29 de octubre de 2026**

## ⚡ En una página

Esta pieza se borró y se reescribió hoy, jueves 29 de octubre de 2026, con cada enlace
comprobado en tiempo real antes de escribir su placa. Cita 3 repos: 3 empujaron hoy, 0 en los
últimos 7 días, 0 llevan más de 180 días quietos y 0 están archivados; los que ya no responden
quedan firmados como caídos, no escondidos. El mayor medido hoy: `animiruorg/Animiru` — ★904,
GPL-3.0, último empuje 2026-10-29.

## 🗼 Las placas al pulso (2026-10-29)

• `animiruorg/Animiru` — ★904 (verificado 2026-10-29)
· actividad HOY · última actividad 2026-10-29
· GPL-3.0

• `Riteshp2001/mpvRx` — ★859 (verificado 2026-10-29)
· actividad HOY · última actividad 2026-10-29
· AGPL-3.0

• `Kototoro-app/Kototoro` — ★653 (verificado 2026-10-29)
· actividad HOY · última actividad 2026-10-29
· Apache-2.0

## 🔗 Fuentes comprobadas hoy

• https://github.com/animiruorg/animiru — vivo al verificar hoy (2026-10-29)
• https://github.com/riteshp2001/mpvrx — vivo al verificar hoy (2026-10-29)
• https://github.com/kototoro-app/kototoro — vivo al verificar hoy (2026-10-29)

💓 *PULSO 2026-10-29 — pieza reescrita hoy con verificación en tiempo real (La Bandita).* Se
comprobaron hoy, uno a uno: 3 repos GitHub (3 vivos, 0 firmados como caídos/bloqueados) y 0
enlaces externos de esta pieza. Las placas de arriba salen de esa medición de hoy, no de
memoria.
