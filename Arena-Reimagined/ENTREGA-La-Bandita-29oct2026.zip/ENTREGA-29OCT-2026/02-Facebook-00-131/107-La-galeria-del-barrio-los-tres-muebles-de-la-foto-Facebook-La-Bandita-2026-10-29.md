# Publicación 107 — La galería del barrio: los tres muebles de la foto

_viernes 31 de octubre de 2026 · La Bandita_

**immich-app/immich** encabeza esta entrega con ★117.612 medidos hoy: «High performance self-hosted photo and video management solution.». La pieza cita 2 repos (2 vivos) y 2 empujaron en los últimos 30 días. Le sigue **photoprism/photoprism** (★40.370): «AI-Powered Photos App 🌈💎✨». Temas que se repiten en el grupo: ai, backup-tool, flutter, golang.

## Los repos de esta pieza, medidos hoy

- **immich-app/immich** — «High performance self-hosted photo and video management solution.»
  ★117.612 · su último empuje fue el 2026-10-29 (hace 2 días) · licencia AGPL-3.0 · TypeScript · última release v3.3.5 (2026-10-21) · https://github.com/immich-app/immich · Web: https://immich.app
  Temas: backup-tool · flutter · google-photos · google-photos-alternative · javascript · mobile-app

- **photoprism/photoprism** — «AI-Powered Photos App 🌈💎✨»
  ★40.370 · su último empuje fue el 2026-10-29 (hace 2 días) · licencia AGPL-3.0 (según texto de su repo, 29-oct-2026) · Go · última release 261007-65faaae5d (2026-10-07) · https://github.com/photoprism/photoprism · Web: https://www.photoprism.app
  Temas: ai · golang · google-photos · machine-learning · photography · private-cloud

## Lectura de la medición

Pulso tranquilo: lo último que se movió fue **immich-app/immich**, hace 2 días. Con releases publicadas hay 2; manda la de **immich-app/immich** (v3.3.5 (2026-10-21)); el parte legal dice AGPL-3.0 ×1, AGPL-3.0 (según texto de su repo, 29-oct-2026) ×1.

💓 2 repos y 0 enlaces medidos el 31-oct-2026 (API oficial de GitHub y web); 2 vivos, 0 firmados arriba con su estado.
