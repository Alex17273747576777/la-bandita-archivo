*31 — EL PORTERO DEL BARRIO*
*AFWall+ cumple catorce años, NetGuard cumple once con quietud y TrackerControl firma a los
rastreadores: el control de quién habla con quién en tu teléfono (WhatsApp · La Bandita ·
dominicano-ES)*

───────────────────

*⚡ EN UN RESPIRO*

El bloque del sistema abre con la pieza del portero: el firewall del teléfono — el mueble que
decide QUÉ app habla con la red y cuál queda en silencio, medido al censo del 15-oct-2026.

Las placas: **AFWall+** — ★3.507 (pulso 15-oct-2026), GPL-3.0, nacida el 27-oct-2012: CUMPLE CATORCE AÑOS en doce días exactos, con push del 12-oct — el firewall de la escuela del root, el más viejo del censo de la noche. **NetGuard** — ★3.923, GPL-3.0, nacida el 24-oct-2015: cumple ONCE AÑOS en nueve días...

y lleva el acta del censo: sin push desde el 1-ago-2026, DOS MESES Y MEDIO de quietud. Y
**TrackerControl** — ★2.686, GPL-3.0, push del 14-oct: el detective que firma a los rastreadores
que las apps esconden.

El marco honesto: el portero es la pieza donde el escudo (24) se vuelve albañilería fina — la lista de la lista (24) bloqueaba webs enteras; el firewall de esta noche bloquea APP por APP: el mensajero habla, el juego no; el banco habla, el «optimizador» no. Y la vara del oficio se aplica con el doble de peso: el portero toca el flujo entero del teléfono.

───────────────────

*🗺 MAPA DE ESTA GUÍA*

⏱ *Lectura total: 55 min* · Todo dato con fecha y placa · Censo del 15-oct-2026 (tarde)

───────────────────

*🌱 LA SEMILLA*

El teléfono moderno es un barrio con trescientas puertas abiertas: cada app que instalas trae su puerta a internet y casi nadie sabe quién habla por la noche. El portero existe pa eso: poner UNA vara en las puertas — el firewall per-app, la regla dominicana del oficio: cada quien habla lo que necesita hablar, y el que no necesita, calla.

La serie preparó el terreno: el escudo (24) bloqueó la mirada ajena de la red; el tronco (27) cuidó las llaves; el correo (28) ordenó la puerta principal. Esta pieza pone el portero EN CADA PUERTA: el control fino, por app, con reglas de wifi y de datos por separado.

Y su vara es la más vieja de la noche: AFWall+ lleva catorce años haciendo EL MISMO oficio — el más simple y más serio del sistema: decidir quién pasa. El censo de esta noche es un homenaje a la longevidad del oficio simple bien hecho — con el acta de NetGuard al frente, porque en el sistema también se mide la quietud.

───────────────────

*🚧 EL CENSO DEL PORTERO (censo 15-oct-2026)*

Las placas completas, tal como el censo de la tarde y el pulso nocturno del 15-oct-2026 las
contestaron:

*AFWall+* — ukanth/afwall · ★3.507 (pulso 15-oct-2026) · push del 12-oct · GPL-3.0 · nacida el 27-oct-2012. El firewall de la escuela del root: reglas de iptables por app, wifi y datos por separado, logs de lo que intenta hablar. Catorce años menos doce días al corte — cumple el 27-oct: la casa más vieja del censo de la noche y una de las más viejas de la serie entera.

*NetGuard* — M66B/NetGuard · ★3.923 (pulso 15-oct-2026) · push del 1-ago · GPL-3.0 · nacida el 24-oct-2015. El firewall de la escuela SIN root: el filtro por VPN local — bloquea por app sin tocar el sistema. Cumple ONCE AÑOS el 24-oct — y trae el acta de la noche: DOS MESES Y CATORCE DÍAS de quietud al corte.

La casa del taller M66B (el mismo del correo (28)) — su acta completa es la sección cuatro.

*TrackerControl* — TrackerControl/tracker-control-android · ★2.686 (pulso 15-oct-2026) · push del 14-oct · GPL-3.0 · nacida el 10-nov-2019. El detective del portero: no solo bloquea — FIRMA: te muestra QUÉ rastreadores lleva cada app adentro y cuáles intentó hablar esta noche. Casi siete años de taller, escuela de la Universidad de Oxford llevada al bolsillo.

───────────────────

Detalle que la forja firma con vara: tres casas, TRES cumpleaños de octubre en una sola pieza (AFWall+ el 27, NetGuard el 24, y la propia pieza naciendo el 15) — el sistema libre del Android cumple años este mes. Y la respiración del censo: dos casas empujando esta semana, una quietud anotada con acta.

El barrio del portero es viejo de oficio y nuevo de cumpleaños.

*🏫 LAS DOS ESCUELAS DEL CONTROL*

Tres casas, dos escuelas — y la escuela la decide la TÉCNICA del portero, que en este territorio
manda.

*LA ESCUELA DEL ROOT (AFWall+).* El portero de las puertas del sistema: usa iptables — el firewall del kernel de Linux — para decidir por app antes de que el paquete salga. Su vara: el control MÁS fino y más barato (cero intermediarios), con la condición del oficio: pide ROOT — el teléfono desbloqueado del taller serio.

Es la escuela de la pieza 20 (los módulos de root): los que ya viven ahí, la conocen. Sus
faenas: reglas por app (wifi/datos separados), logs completos, y el modo del portero estricto:
NADA habla sin permiso explícito.

*LA ESCUELA SIN ROOT (NetGuard, TrackerControl).* El portero de la puerta única: crea una VPN LOCAL dentro del teléfono — todo el tráfico pasa por ella, y ella decide quién habla. Sin root, con la vara del intermediario: una capa más (que consume un suspiro de batería) a cambio de funcionar en cualquier teléfono.

NetGuard es el especialista en CORTAR (por app, por wifi/datos); TrackerControl el especialista
en FIRMAR (ve el nombre del rastreador que cada app intenta contactar: el «Facebook Analytics»
de tu juego, el «Google Ads» de tu linterna).

*Cómo se arma el portero sin equivocarse:*

Con root del taller (20) → escuela del root: AFWall+ — el control fino sin intermediarios.

Sin root → escuela sin root: TrackerControl pa VER (la primera semana es de observación: el
informe de rastreadores cambia como ves el barrio), NetGuard pa CORTAR lo que el informe firmó.

Y la secuencia de la casa: PRIMERO mirar (TrackerControl), DESPUÉS cortar (NetGuard o AFWall+).
El que corta sin haber mirado deja el teléfono sin habla — y el dueño sin mensajero.

───────────────────

*⚖ LA VARA DE LA LICENCIA*

El corte del portero al 15-oct-2026: TRES FIRMAS COMPLETAS — las tres GPL-3.0. Segundo
territorio consecutivo en firmar entero, y el primero en firmar con UNA SOLA ley: el copyleft
completo para las tres.

La lectura de la forja: el firewall es el mueble donde la ley importa MÁS — decide qué sale de tu teléfono, y su código tiene que ser auditable por diseño. Las tres casas lo firman igual: GPL-3.0, la ley que obliga a que cualquier modificación siga abierta.

En el portero no hay licencias permissivas «pa la mezcla»: la vara del territorio exige la ley
más social de todas — y las tres la traen.

*El contraste con la noche:* después de cinco placas en blanco marcadas en el bloque (Markor, AppManager, KeePassXC, Lawnchair, FUTO), el portero firma 3 de 3 — el barrio más legal de la serie en proporción. La lectura honesta: el territorio del control de red atrae talleres de doctrina — gente que escribe firewall ES gente que cree en la transparencia, y la firma es la prueba.

*La vara aplicada, casa por casa:* repo público con años ✓ (catorce, once y siete), fila viva ✓,
instalación del repo o tienda legal ✓ (las tres están en F-Droid desde siempre).

El detalle que la forja subraya pa el usuario nuevo: los firewalls SIN root de esta noche
(NetGuard, TrackerControl) crean una «VPN local» — el Android los muestra con el icono de VPN y
pide su permiso: ES NORMAL y es exactamente cómo funciona la escuela: la puerta única que tú
controlas, no un túnel a la nube ajena.

───────────────────

*🕰 EL ACTA DE NETGUARD (la quietud del cumpleañero)*

*NetGuard — ★3.923 (pulso 15-oct-2026) · push del 1-ago-2026 · GPL-3.0 · cumple once años el 24-oct*

Dos meses y catorce días de silencio al corte. El acta de la forja, en tres capas:

*UNO — el taller es conocido y de doble casa.* NetGuard es de M66B — el mismo taller de FairEmail (28), que empujó EL MISMO día del censo. La lectura: el taller está vivo (el correo respira); el firewall está EN ESPERA. Los talleres de una persona priorizan: la casa con más usuarios activos recibe el oficio del día.

No es abandono confirmado — es prioridad anotada con fecha.

*DOS — el mueble funciona sin push.* Igual que el acta de Shizuku (25): lo instalado sirve hoy —
un firewall no se corrompe por no actualizarse, se vuelve VIEJO despacio: cada gran
actualización de Android puede torcer algo de su escuela (la VPN local es zona de cambios del
sistema).

El reloj del acta: funciona HOY con fecha — y su plan B (AFWall+ con root, TrackerControl sin
root) ya está anotado por esta pieza.

*TRES — el cumpleaños como vara de medición.* El 24-oct NetGuard cumple once años: el censo próximo de la serie lo mira. Si empuja antes del cumpleaños: el acta se celebra.

Si no: la quietud llega a los tres meses y la forja la re-firma. Así funciona el mapa vivo: la quietud no se adivina — se RE-MIDE con fecha.

La serie no despide a nadie por adelantado: anota, espera y vuelve a mirar.

───────────────────

*🔧 LA RECETA DEL PORTERO ORDENADO (una tarde, por pisos)*

*Piso uno — mirar primero.* TrackerControl de la tienda legal (F-Droid, placa: ★2.686 al pulso
del 15-oct-2026, GPL-3.0, push del 14-oct): permiso de VPN local, y UNA JORNADA de observación
sin cortar NADA. El informe de la noche: la lista de rastreadores que tus apps intentaron
contactar — la primera lista que la mayoría del barrio ve en su vida.

El dato duele dos minutos y ordena una tarde.

*Piso dos — el corte fino.* Con el informe al frente: las reglas del portero. El juego que firma a doce rastreadores: bloqueado de la red de fondo (con permiso pa cuando JUEGAS).

El «optimizador» que firma a tres: sin internet, PERMANENTE. El mensajero, el banco, el correo: hablan.

La vara del corte: corta lo que firma, no lo que usas — el portero estricto empieza por los
sospechosos de siempre, no por el mensajero de la familia.

*Piso tres — las reglas por red.* La gracia del portero fino: wifi y datos son dos puertas distintas. La regla dominicana del censo: en WIFI de casa habla más (las copias del sótano (26), las sincronías del personal (29)); en DATOS MÓVILES habla lo esencial (mensajero, banco, mapa).

La factura de datos que baja al segundo mes es el sueldo del portero — medible, como todo en la
casa.

*Piso cuatro — el modo estricto (pa el oficio avanzado).* AFWall+ con root del taller (20): el modo de cero permisos — NADA habla sin regla explícita. Es el portero del castillo: máximo control, máxima responsabilidad — cada app nueva necesita su permiso.

La forja lo firma pa quien ya vive en el root; el resto del barrio queda bien servido con la escuela sin root.

*Piso cinco — el acta del portero.* La nota-placa del taller: qué portero, qué censo (15-oct-2026), qué reglas gruesas, la fecha del primer corte. Y el ritual mensual: el informe de TrackerControl se re-lee (¿las apps nuevas traen rastreadores nuevos?), las reglas se ajustan, y el acta del push de cada casa se compara con el censo.

El portero con acta se hereda — como toda la casa.

───────────────────

*🧊 MITOS DESMONTADOS*

*Mito uno — «bloquear la red rompe las apps».* La verdad del oficio: corta lo que firma, no lo que usas. El juego bloqueado de la red de fondo funciona IGUAL pa jugar (se conecta solo cuando tú abres); el «optimizador» bloqueado no pierde ninguna función (su única función era firmar a rastreadores).

La app que REALMENTE necesita la red (mensajero, banco) no se toca.

El firewall de la casa corta con informe delante — el que corta a ciegas, deja el teléfono mudo.

*Mito dos — «una VPN local gasta batería».* El suspiro medido: la escuela sin root añade un intermediario local — su costo se mide en puntos porcentuales, no en horas. La vara práctica de la casa: una semana con el portero puesto y mira la batería real — y compárala con el ahorro de datos del piso tres: el balance de la casa es positivo con el portero fino.

*Mito tres — «si la app es de pago, no trae rastreadores».* El informe de TrackerControl contesta con datos: apps de pago del censo firman a rastreadores igual — el pago compra la función, no la privacidad del diseño. La vara del portero no pregunta cuánto costaste: pregunta con quién hablas.

La primera noche del informe lo firma mejor que cualquier ensayo.

*Mito cuatro — «con antivirus no necesito firewall».* Son muebles distintos: el antivirus mira ARCHIVOS; el portero mira EL FLUJO — quién habla, con quién, por qué puerta. El teléfono con antivirus y trescientas puertas abiertas sigue siendo el barrio de las puertas abiertas.

La casa los firma como complementos — y en la casa libre, el portero primero: el flujo manda
sobre el archivo.

───────────────────

*❓ PREGUNTAS DE LA FILA*

*¿AFWall+ o NetGuard pa empezar?* Del censo del 15-oct-2026: sin root, NetGuard o TrackerControl
(la casa arranca por TrackerControl pa mirar). Con root del taller (20), AFWall+ es el control
más fino — catorce años de oficio lo respaldan.

El dato del acta: NetGuard lleva dos meses y medio quieta — pa el nuevo de escuela sin root, la
forja firma empezar con TrackerControl (push del 14-oct) y mirar el cumpleaños de NetGuard
(24-oct) antes de mudar.

*¿Cada app nueva hay que darle regla manual?* Con el portero estricto, sí — y es su oficio: el control total pide atención total. Con la escuela flexible (informe primero, corte después), las apps nuevas entran en la regla de prueba: cortadas de fondo hasta el informe del sábado.

La regla de la casa: la app nueva del cajón (25) ya pasó la vara de origen — el portero solo
pregunta a QUIÉN firma, no si puede entrar.

*¿El portero bloquea las actualizaciones de las apps?* Solo si le pides que las bloquee: la tienda de apps es una app más — con puerta propia. La regla del piso tres: actualizaciones solo en WIFI de casa — el portero las corta en datos y las deja en la wifi: la factura de datos se ahorra los gigas de las actualizaciones sorpresa.

*¿Funciona con datos móviles de la compañía que sea?* Sí: el portero trabaja encima del teléfono, no encima de la compañía — las reglas valen igual en la SIM que en la wifi. La vara honesta: el portero no arregla la señal del campo — no confunde el control del flujo con la cobertura: eso lo firma el técnico del barrio, no el firewall.

*¿TrackerControl y NetGuard a la vez?* No conviene: los dos crean la puerta única (VPN local) — el Android solo permite una a la vez. La secuencia de la casa: TrackerControl una semana (mirar), NetGuard después (cortar).

El que ya sabe qué cortar, va directo a NetGuard; el que quiere el informe mensual de rastreadores, va con TrackerControl. Una puerta, un portero por vez.

*¿El portero me hace anónimo en internet?* No — y la pieza no vende ese cuento: el portero decide QUIÉN habla desde tu teléfono; no esconde DÓNDE estás. Pa el viaje cifrado de la red, la escuela del escudo (24): las listas y las llaves de esa pieza.

El portero y el escudo son hermanos de casa distinta: uno corta adentro, el otro protege afuera. Juntos, la defensa completa.

*¿El portero protege de las redes wifi ajenas?* No en la capa que esta pieza mide: el portero decide QUIÉN habla; la wifi ajena del mall es la CALLE por donde hablas — su riesgo lo cubre el escudo (24) con su escuela del viaje cifrado. La casa los usa juntos en la calle: portero adentro, escudo afuera — y en la wifi de casa, el portero solo, que el jardín es tuyo.

*¿Se puede permitir la red por horario?* Sí en la escuela del root (AFWall+ con los perfiles) y por automatismo del personal (29) en la escuela sin root (el perfil del portero se activa y desactiva por hora). La regla dominicana del horario: el juego habla en su franja, el estudio mudo de red, la noche silenciosa salvo la familia.

El horario en el portero es la regla que no discute — la misma lección del papá del caso dos.

*¿Las apps se dan cuenta de que están bloqueadas?* Las que intentan firmar a rastreadores en la noche: no molestan al usuario (la firma es silenciosa por diseño — nadie quiere leer «tu linterna habla con un servidor de anuncios»). Las que necesitan la red pa funcionar: muestran su error de conexión normal.

La regla del corte fino lo evita: corta lo que firma, no lo que usas.

───────────────────

*🧪 CASOS DEL BARRIO*

*Caso uno — el joven del plan de datos chico.* Dos gigas al mes que se evaporaban en la semana dos, sin saber por qué. Receta: la tarde del portero completa — el informe de TrackerControl (dos apps firmaban a servidores de video en la noche), las reglas de NetGuard: datos solo pa lo esencial, actualizaciones solo en wifi.

El plan de dos gigas llegó AL DÍA 28 por primera vez.

El sueldo del portero, facturado y medible.

*Caso dos — el papá del teléfono del hijo.* El teléfono de estudio del muchacho con los juegos que «hablaban de noche». Receta: las reglas del portero — los juegos con red SOLO en la wifi de casa, cortados en horario de estudio, y el mensajero de la familia siempre libre.

La conversación del horario dejó de ser pelea: la regla está en el portero y el portero no discute.

El papá que peleaba cada noche con el horario, hoy descansa: el portero aplica, el papá acompaña.

*Caso tres — la contadora del caso 2 de la pieza 28.* Su correo ordenado le firmó el siguiente
frente: la app de la «calculadora fiscal» del negocio intentaba hablar con servidores de
publicidad cada vez que abría un recibo.

Receta: el informe de TrackerControl a la vista, la calculadora con red cortada (trabaja 100% local — lo probó una semana), y el recibo del negocio que ya no viaja a ningún servidor de anuncios. El dato fiscal del negocio que se queda en el negocio: el portero pa el oficio.

*Caso cuatro — el dueño del taller de motos.* Notaba el teléfono caliente en la noche y la batería amanecida «sin hacer nada». Receta: el informe nocturno del portero — tres apps del cajón viejo firmaban a servidores toda la noche (las «luces» y «optimizadores» del grupo de siempre).

Regla: cortadas permanentes, desinstaladas al mes.

El teléfono que amanecía caliente, amanece frío: el portero también apaga la discoteca de la
madrugada.

───────────────────

*Caso cinco — la profesora de la escuela del sector.* El tablet del aula con las apps de los estudiantes vivía «hablando» pa la casa del fabricante del tablet (telemetría de uso, decía el contrato chiquito). Receta: el portero de la escuela sin root con regla de aula: las apps de clase solo con el servidor de la escuela, la telemetría cortada permanente.

El tablet del aula que ya no reporta a nadie pa la casa: la telemetría del contrato chiquito,
cancelada con regla.

*Caso seis — el vendedor de las ferias del mercado.* Su teléfono de facturas viajaba a tres
servidores de «analítica» cada vez que cerraba una venta — y su proveedor de la app le confesó
que «es estándar de la industria».

Receta: el informe del detective al frente, la app de facturas con red SOLO pa el servidor del negocio (regla por dominio de la escuela fina), y la analítica de la industria, cancelada. El monto de la venta que ya no viaja a tres servidores: el portero pa el oficio que factura.

*🏭 LA DESPENSA DE DATOS (todo lo medido, en una repisa)*

Las tres placas del portero al 15-oct-2026, listas pa copiar y verificar:

AFWall+ · ukanth/afwall · ★3.507 · nacida 27-oct-2012 · push 12-oct-2026 · GPL-3.0 · cumple
catorce años el 27-oct. NetGuard · M66B/NetGuard · ★3.923 · nacida 24-oct-2015 · push 1-ago-2026
· GPL-3.0 · QUIETUD de dos meses y catorce días al corte · cumple once el 24-oct.

TrackerControl · TrackerControl/tracker-control-android · ★2.686 · nacida 10-nov-2019 · push
14-oct-2026 · GPL-3.0.

Frontera declarada: Orbot (Tor en Android, push del 15-oct, placa sin testamento en el censo) es
de la escuela del ESCUDO (24) — protege el viaje, no el flujo local. El portero y el escudo,
hermanos de casa distinta.

Fuente: censo vivo de la casa (5.684 repos, tarde del 15-oct-2026) + pulso nocturno con la API
oficial del mismo 15-oct-2026. Dato viaja FECHADO a esa noche.

───────────────────

*🕰 LA EDAD DEL PORTERO*

AFWall+ nació el 27-oct-2012: catorce años menos doce días. NetGuard nació el 24-oct-2015: once
años menos nueve días.

TrackerControl nació el 10-nov-2019: casi siete años. Promedio del portero: diez años y ocho
meses — el segundo censo más viejo de la serie (el correo (28) promedia once y cinco).

La lectura del dato: el control de red es oficio de VIEJOS del ecosistema — las dos casas grandes nacieron con menos de cien mil usuarios de Android en el mundo, cuando el firewall era tema de foros y no de comerciales. El portero de esta noche no es una moda de privacidad: es la institución más vieja del control del teléfono, cumpliendo años este mismo mes.

───────────────────

*💬 LA CONVERSACIÓN HONESTA*

Primera: el acta de NetGuard se escribió con la vara doble — es casa del taller más querido de la noche (M66B firmó el correo (28) entero) y es el portero más usado de la escuela sin root. La quietud se anota igual: dos meses y catorce días, con fecha y con plan B.

La forja no perdona placas por cariño — ni despide talleres por silencio: mide, anota y re-mide.

Segunda: el informe de rastreadores de la primera noche DUELE — y la pieza lo avisa pa que nadie abandone en el minuto dos: el duele es el diagnóstico, no la enfermedad. Las apps del barrio firme (mensajero, banco) rara vez firman a lo feo; las del escaparate (juegos, linternas, optimizadores) firman a lo loco.

La lista del informe es el mapa del corte — y el mapa se usa, no se enmarca.

Tercera: el glosario es el de la familia sistema (nueva desde esta pieza) más las entradas del
portero. La forja abre el bloque 31-40 con la aguja de la casa: mismo dialecto, territorio
nuevo.

───────────────────

*🎞 LO QUE ESTA PIEZA NO DICE*

No dice que el portero te haga anónimo — dice que decide quién habla desde tu teléfono; el viaje
cifrado es del escudo (24).

No dice que cortar la red sea romper apps — dice que corta lo que firma, no lo que usas: con
informe delante.

No dice que la VPN local sea un túnel ajeno — dice que es la puerta única que TÚ controlas: cero
nube.

No dice que el antivirus sustituya al portero — dice que son muebles distintos: el flujo manda
sobre el archivo.

No dice — jamás — que el portero se configure a ciegas: primero el informe (mirar), después las
reglas (cortar) — el orden del oficio.

───────────────────

*📻 LA SEGUNDA FILA (lo que quedó en la puerta del portero)*

El corte honesto declara sus huecos — con motivo escrito:

*La escuela del escudo (24).* Orbot y el Tor del bolsillo (★3.623 al pulso del 15-oct-2026, push
del 15-oct, placa sin testamento): protegen el VIAJE, no el flujo local — su censo pertenece al
territorio del escudo y la forja lo anota como frontera de esta pieza.

*El DNS filtrado de familia.* El control por DNS (la escuela del bloqueo pa niños y oficinas):
territorio del bloque de redes (41-50) — el portero de esta noche corta por app; el DNS corta
por nombre.

*Los análisis de tráfico completos.* Los muebles de la escuela del oficio fino (capturas,
dissectores): territorio del bolsillo developer (126-140) — el portero de la casa es uso diario,
no laboratorio.

*Los que no pasan la vara de origen.* Los «firewalls» de la tienda sin repo público, los que prometen «bloquear todo» pidiendo la VPN local sin código, los «aceleradores» que bloquean... nada: pa la forja no existen como porteros — existen como el secuestro con formato.

Su camino: repo, licencia, censo.

Y queda el letrero de la casa: el que no se puede auditar, trabaja pa otro barrio.

───────────────────

*🎚 EL PORTERO EN TU DÍA A DÍA (cuatro rutinas del oficio callado)*

*LA MAÑANA DEL REPORTE.* El log del portero de la noche: qué intentó hablar a las 3 AM, qué
quedó cortado, qué llegó. Un vistazo con el café — el informe nocturno es la acta diaria del
portero: el que la lee, duerme informado.

*LA SEMANA DE LA APP NUEVA.* Cada app nueva que entra al teléfono (con vara del cajón (25)) entra con regla de PRUEBA: cortada de la red de fondo hasta que el informe diga qué firma. La regla del portero para el recién llegado: primero calla, después habla — si el informe lo deja.

*EL MES DEL INFORME.* El re-lee del informe mensual de rastreadores: ¿las apps nuevas trajeron huéspedes? ¿las reglas siguen finas?

¿la factura de datos mantiene su bajada? Quince minutos, como toda la casa: el portero se ajusta en caliente y el acta se firma con fecha.

*EL AÑO DEL CUMPLEAÑOS.* El 24-oct y el 27-oct: los cumpleaños del portero — y la fecha del re-midón: ¿AFWall+ sigue empujando? ¿NetGuard despertó?

¿la escuela sin root trae casa nueva? El censo de cumpleaños de la serie: la forja vuelve a mirar donde nació el oficio — y el acta de la quietud se re-firma o se celebra, con fecha.

───────────────────

*🧵 GENEALOGÍAS DEL PORTERO*

La línea de sangre del portero es la más institucional de la serie: AFWall+ (2012) hereda la
escuela de DroidWall — el primer firewall de Android, cuando el root era el único camino:
catorce años de iptables sin cambiar de idea.

NetGuard (2015) inventó la escuela sin root: la VPN local como puerta única — el diseño que TrackerControl (2019, escuela de Oxford) adaptó pa firmar rastreadores con nombre y apellido. Las tres casas comparten ley (GPL-3.0) y comparten doctrina: el flujo se controla con código público o no se controla.

La cadena del portero en una línea: el root abrió el camino (2012), la VPN local lo democratizó (2015), y el informe con nombre lo hizo visible pa todos (2019). El portero de esta noche es la suma de tres generaciones de una sola idea: en tu teléfono, el que decide quién habla eres tú — con código que se puede leer.

───────────────────

*📦 LA DESPENSA DEL PORTERO (tus puertas, ordenadas como gente)*

*LA LISTA DE LOS QUE HABLAN.* El documento del portero: las apps con permiso permanente (mensajero, banco, correo, mapa), las con permiso de wifi (copias, sincronías, tiendas), y las cortadas (las firmantes del informe). La lista vive en la nota-placa del taller — el portero con expediente escrito se hereda.

*LAS REGLAS DEL HORARIO.* El portero fino de la casa: los juegos con red solo en su franja, el teléfono del estudio mudo de red en horas de tarea, el de trabajo sin juegos de fondo. La regla del horario que el portero aplica sin discutir — la misma lección del caso dos: el que aplica es el código, no la discusión.

*EL RESPALDO DE LAS REGLAS.* AFWall+ y NetGuard exportan sus reglas: el archivo va al sótano (26) junto a la cara (30) y las notas (25). El teléfono nuevo recupera el portero completo en minutos: las reglas que tardaron una tarde, guardadas pa siempre.

*Y LA REGLA APRENDIDA.* El portero se administra con la vara de la casa: informe primero, corte fino, pánico disponible, acta con fecha. Once piezas de la serie y la misma vara — el portero la aplica al flujo: la casa entera, puerta por puerta, con código que se lee.

───────────────────

*🪧 EL CARTEL DEL PORTERO*

Clávalo en la puerta del teléfono:

*Mirar antes de cortar — el informe primero, las reglas después.*

*Corta lo que firma, deja hablar lo que usas.*

*La puerta única la controlas tú — la del desconocido es secuestro.*

*El portero con pánico disponible: lo que no se apaga en un toque, no entra.*

*Y el acta de la quietud se re-mide con fecha — la quietud no se adivina: se mira.*

───────────────────

*😄 EL MEME DE LA CASA*

— El teléfono de fábrica, a las 3 AM: *la linterna habla con un servidor de anuncios, el juego
con otro, el «optimizador» con tres* 🌃

— El dueño, dormido: *«¿por qué amanece la batería a media?»* 😴

— AFWall+, catorce años de oficio, GPL-3.0: *reporte de la noche: 47 intentos, 0 pasados* 🚧

— Yo, leyendo el informe con el café: *«linterna, tú y yo sabemos que no hacía falta»* 😌

*Moral del meme, chin chin:* el teléfono sin portero es la casa con todas las ventanas abiertas en Carnaval: todo el mundo entra a mirar, y alguno se lleva algo. El portero del censo cuesta una tarde, no cobra cuota, y su informe de la noche es la mejor lectura de la madrugada — mejor que el chisme del grupo, chin chin.

*⚠ LOS RIESGOS DEL PORTERO, CON FECHA*

*RIESGO UNO — el corte a ciegas.* Un firewall mal configurado deja el teléfono mudo: sin mensajero, sin banco, sin mapa. La defensa es la secuencia de la casa: mirar (TrackerControl) → cortar (lo que firma) → probar (el mensajero del hijo manda el mensaje de siempre).

Y el botón de pánico del control: las reglas se apagan en un toque — el portero que no tiene pausa, no entra.

*RIESGO DOS — el portero impostor.* El territorio más copiado de la tienda: «firewalls» gratis que piden la VPN local pa... enrutarte por SU servidor.

La vara del censo: repo público con años, GPL firmada, F-Droid de siempre — las tres placas de esta noche pasan. El impostor se pesca en un dato: su repo no existe o tiene tres meses.

La puerta única que un desconocido controla no es portero: es el secuestro del barrio.

*RIESGO TRES — la quietud que se vuelve incompatibilidad.* El acta de NetGuard con su reloj: cada Android nuevo puede torcer la escuela de la VPN local. La defensa: el ritual mensual mira el push del portero Y el plan B anotado (AFWall+ si hay root, la casa nueva del censo si no).

El control que funciona hoy con fecha — y el mapa pa cuando deje de funcionar: la vara de toda
la serie, aplicada al flujo.

*Y el riesgo que la forja se auto-impone:* escribir el informe de rastreadores sin vender el miedo. La forja firma el tono: el informe no es para asustarse — es para CORTAR con vara.

El barrio que lee su primera lista de rastreadores y no duerme, dejó la pieza a medias: el plan completo es mirar, cortar y vivir tranquilo — el portero trabaja, tú vives.

───────────────────

*📖 GLOSARIO DE LA COSECHA*

*Puente.* El cliente que no guarda música: la busca en el catálogo de otro y la trae al momento.
Debe su vida a un río ajeno — por eso la vara de esta escuela mira el push con fecha antes que
las estrellas.

*Cajón.* La escuela del archivo propio: MP3 y FLAC tuyos, tocados sin internet ni río ajeno.
Nunca depende de un provedor, jamás se corta en la loma, y su única obligación es que tus
etiquetas estén peinadas.

*Detective.* La escuela del descubrimiento: cruza fuentes, amarra discografías y te muestra
versiones. Muffon es su bandera en la cosecha — menos «ponme la playlist», más «enséñame el mapa
del artista».

*Cosecha.* El pase de vara ancho por una familia del censo: se mide casa por casa, con placa, y
lo que no pasa no se borra — se anota. La cosecha es la prueba de que el método de la casa
funciona.

*Placa.* El paquete completo de datos de una casa: estrellas con fecha, push con fecha, licencia
con nombre, fila de asuntos. Sin placa no hay censo — hay lista de apodos.

*Pulso.* La toma de datos con hora. El censo de la tarde no es el pulso de la noche: el #10 de
esta pieza midió a las ~23:12 UTC y cazó dos casas moviéndose en vivo. El censo no es una foto:
es un latido.

*Mapa vivo.* La numeración de los pulsos de la casa (#1 al #10 al corte de esta pieza). Cada
mapa vivo deja caja fechada para que el próximo lector compare su cuaderno con el nuestro.

*Censo vivo.* El barrido grande de la casa: 5.684 repositorios al 15-oct-2026, con estrellas,
pushes y licencias. Es la fuente de verdad de esta pieza — y crece por puerta verificada, no por
promesa.

*Vara.* La regla de la casa que decide qué entra al mapa: fuente abierta, licencia legible,
pulso con fecha. La vara no clasifica por gusto — mide por oficio.

*Corte.* El día y la hora en que se midió la verdad. Toda esta pieza es del corte 15-oct-2026;
mañana el corte dirá lo que viva mañana — y esa es su honestidad, no su debilidad.

*Quietud.* El silencio anotado: tronco grande sin empuje, con fecha de última actividad. No es
muerte ni abandono automático — es pausa con acta. Timber y InnerTune son las quietudes de esta
cosecha.

*Push.* El último empuje del taller: la fecha de la última actividad del repositorio. En la
escuela del puente, un push de esta semana vale más que mil estrellas — es la diferencia entre
taller vivo y museo.

*Release.* La versión publicada y firmada por el taller: la única forma del software que la casa
palomea. OuterTune al corte trae la v0.10.1 contándose en público — eso es salud de release.

*Asuntos.* Los issues del taller: la fila pública donde los problemas esperan turno. No cuenta
la cantidad — cuenta si se contestan. Trescientos con respuestas respiran; cuarenta en silencio,
no.

*Estrellas.* El aplauso del ecosistema: mide fama, no calidad. ★49.974 (15-oct-2026) hace a
Spotube el más aplaudido de la cosecha — la vara de la casa decide si ese aplauso viene con
contrato.

*Licencia.* El contrato escrito del taller: qué puedes hacer con su código. En esta cosecha
firman GPL-3.0, AGPL-3.0 y MIT — y tres casas viajan sin firma clara, con su vara marcada.

*GPL-3.0.* La licencia copyleft más común de la cosecha: usa el código, y lo que publiques con
él se abre con la misma placa. Es la firma que convierte un silencio en genealogía — InnerTune
la firmó, y OuterTune hereda con honor.

*AGPL-3.0.* La GPL para servicios: si el código corre como servicio, también se abre. muffon la
firma al 15-oct-2026 — la casa la lee con el mismo respeto que la GPL de sus hermanas.

*MIT.* La licencia más simple de leer: haz casi lo que quieras, conserva el aviso. Salt Player
la firma — garantía mínima, cadena limpia, cero letra chica.

*NOASSERTION.* La placa en blanco: el repositorio no declara licencia reconocida. No es delito —
es ausencia. Sin firma, el derecho por defecto es «todos los derechos reservados», y los
reempaques viajan sin freno legal.

*Copyleft.* La regla del recíproco: si tomas el código de un taller público para hacer el tuyo,
lo que agregues sale con la misma placa. Es el antídoto del reempaque silencioso.

*Fork.* La continuidad del software libre: un taller que nace del código de otro, respetando su
licencia. OuterTune es el fork vivo de InnerTune — no su imitación: su línea.

*Heredero.* El taller (o la línea) que toma el código de una casa quieta y sigue empujando. Para
heredar con honor hace falta una sola cosa: que la madre haya firmado licencia. Sin firma no hay
testamento.

*Reempaque.* El APK que toma la obra de un taller, le mete anuncios o peaje, y la reparte con
placa ajena. El enemigo viejo de la casa — y la razón de la vara: origen, firma, permisos, sin
prisa.

*Tienda legal.* La puerta de instalación que muestra el repositorio de origen: Droid-ify,
Neo-Store, Accrescent, el F-Droid de la pieza 01. Si la tienda no muestra el repo, no es tienda
— es grupo con carrocería bonita.

*Droid-ify.* El cliente F-Droid material de la casa (pieza 01): busca la casa por su nombre
exacto del censo y la instalación viaja con la placa a la vista. La primera puerta recomendada
de esta cosecha.

*Accrescent.* La tienda de estándares altos de la pieza 01: firmas estrictas, catálogo curado.
Segunda puerta legal — la que usa el que prefieren las varas cortas.

*F-Droid.* La casa madre de las tiendas libres: el catálogo histórico del ecosistema. Vieja,
sabida y firme — el anexo donde la mayoría de las catorce de esta cosecha tiene placa.

*APK.* El paquete instalable de Android. En sí mismo es neutro — como un sobre. La vara de la
casa pregunta siempre lo mismo: ¿quién lo selló? La respuesta separa la tienda legal del grupo
de siempre.

*Firma.* La marca criptográfica del taller en su release. La tienda legal la verifica por ti; el
APK de grupo, nadie sabe quién la puso. Sin firma verificable, no hay confianza — hay fe, y la
casa no trabaja con fe.

*Material You.* El lenguaje de diseño de Android moderno que sigue el color de tu fondo. Retro
Music lo lleva de bandera (★5.357, 18-oct-2026) — el mueble clásico vestido de esta década.

*Etiqueta.* La información adentro del archivo de música: título, artista, álbum, número, año.
El reproductor lee la etiqueta, no el nombre del archivo — peinar etiquetas es peinar la
biblioteca entera.

*FLAC.* El formato sin pérdida: suena exacto al master y pesa cinco veces más que un MP3. Para
el archivo maestro en la PC — no para el bolsillo del día a día.

*MP3.* El formato que movió el mundo y sigue mandando en el bolsillo: a 320 kilobits suena
igualito en auricular humilde y pesa como la palabra. La casa lo respeta sin nostalgia ni
complejo.

*Caché.* La memoria del río: las canciones que ya suenaste se guardan un tiempo para no volver a
bajar. Es la gracia económica del streaming libre — la mata de hilo del tercer día suena media
gratis.

*Scrobble.* El hábito del detective: registrar lo que suenas para amarrar historial y
descubrimiento. muffon lo trae de fábrica — el reproductor que también lleva el cuaderno de
campo.

*Discografía.* El mapa completo de un artista: álbumes, años, versiones. La vara del detective
es amarrarla bien — muffon la cruza entre fuentes al 18-oct-2026 con ★2.246 y AGPL firmado.

*Multi-fuente.* La casa que no se casa con un río: consulta varios provedores y te sirve la
versión que esté limpia. Spotube, Namida y muffon viven de esa libertad — con sus licencias
mirándose dos veces.

*Streaming.* El modelo del río: suena ahora, no guarda nada tuyo. Infinito mientras el río corra
— y por eso esta pieza repite: exporta lo que amas, streamea lo que descubres.

*Aleatorio.* El modo más honesto del reproductor: te enseña cuánto conoces tu propio archivo. En
el cajón con etiquetas peinadas, el aleatorio es un paseo; sin etiquetas, un secuestro.

*Lista.* La secuencia guardada: el arte del anfitrión y la herramienta del viajero. La lista
buena se exporta a archivo — la que solo vive dentro de la app es rehén de la app.

*Exportar.* Sacar tus listas y favoritos a archivo que otra casa pueda leer. La prueba de
propiedad de la escuela del río: si el mueble no exporta, eres inquilino con mueble bonito.

*Sincronía.* La rutina que mueve tu música entre PC y teléfono sin cable ni heroico: Syncthing y
su familia (viene en la serie). La copia maestra queda en casa; el teléfono lleva la de trabajo.

*Copia maestra.* El original en FLAC que vive en tu PC o disco, del que nacen las copias de
bolsillo. Convertir del maestro, nunca al revés: bordarle encaje a un saco de harina no lo
vuelve traje.

*Root.* El teléfono abierto de par en par. La casa lo trata en la pieza 20 con sus letreros — y
esta cosecha musical NO lo necesita ni un poquito: fuente abierta es taller público, no cirugía.

*Cuenta de prueba.* El casco de la obra: la cuenta sin nada personal que estrenas cualquier app
nueva. En esta cosecha ninguna de las catorce pide contraseña — la que la pida, desinstálala y
anota la fecha.

*Letrero anti-reempaques.* La regla que SimpMusic puso en su casa (pieza 08) y se volvió ley del
barrio: los reempaques no son míos y no los apoyo. El letrero que le quita al clonero su excusa
favorita — la duda.

*Genealogía.* El oficio de contar de dónde viene cada casa: troncos, forks, herederos,
quietudes. La pareja InnerTune→OuterTune es la lección viva de esta cosecha — misma sangre,
distinto pulso.

*Sucesión.* El relevo ordenado cuando un taller se duerme: la línea GPL continúa en el heredero
y el mapa anota el cambio con fecha. Sucesión limpia no tiene drama — tiene acta.

*Corte honesto.* El corte que declara sus huecos: faltan casas, el censo sigue creciendo, y la
pieza dice qué queda fuera. Sabe a lo que sabe — y lo que sabe, lo firma.

*Rumor con formato.* Lo que queda de una recomendación cuando se le recorta la fecha: «Timber es
el mejor» sin el 28-abr-2023 es un rumor con negritas. La casa comparte mapas con corte puesto.

*Taller público.* El repositorio abierto: el taller cuyas herramientas, filas y errores están a
la vista de todos. Las catorce de esta cosecha lo son — y por eso se les puede medir sin pedirle
permiso a nadie.

*Resurrección.* El regreso con fecha: tachiyomiJ2K volvió de dos años y medio de silencio (pieza
15). Por eso la quietud lleva acta y no lápida — la casa celebra el despertar el día que ocurre.

*Gemela FB.* La copia hermana de una pieza que nacía para Facebook. Por orden del dueño del 15-oct noche, la serie nueva (21 en adelante) viaja SIN gemela: WhatsApp puro — el muro de Facebook queda fuera de esta cosecha.

Ley anotada en la hoja de ruta, no en la discordia.

*LA LISTA.* El índice vivo de la biblioteca (la pieza 00): el mapa del mapa donde cada guía
nueva toma su número y su fila. Esta cosecha entra al corte siguiente de LA LISTA con su placa.

*Boleta.* El único requisito de entrada a la biblioteca: haber abierto el repositorio, la página
de versiones y la libreta de obra. Las catorce de esta cosecha pagaron boleta — por eso tienen
pieza.

*Lupa.* La herramienta de la casa que examina una pieza como un oficial de aduana: respiro,
cadencia, anclas de tiempo, dialecto. La v6 «aire» es la que exige bloques que respiren — esta
pieza nació bajo su vara.

*Respiro.* La ley del aire: ningún bloque de la pieza debía quedarse sin oxígeno — al corte del
15-oct la vara mide ~380 caracteres por bloque. La música también respira: es la diferencia
entre leer y ahogarse.

*Certificación.* Las baterías que la pieza corre antes de firmarse FINAL: la experta (v4), la
evolutiva (v5) y la de rarezas (fuzz) con semilla fija. Sin batería no hay sello — y sin sello,
la pieza no se llama final.

*Acta.* El documento fechado donde la casa anota lo que hizo: actas de corrección, actas de
censo, actas de push. Lo que no tiene acta no pasó — y lo que pasó con acta, no se puede negar.

*Registro.* El cuaderno mayor de la casa: registro-2026-10-15.md y sus hermanos por fecha,
append-only. Aquí vive el acta de esta cosecha, con su pulso #10 y su hora.

*Censo abierto.* La puerta del dueño: lo que encuentra un día, entra el MISMO día al censo con
prioridad. Los Hush de la pieza 17 entraron así — y esta cosecha tiene la puerta abierta para la
próxima casa musical que llegue.

*Hallazgo.* La puerta que alguien trae a la casa: un repositorio que merece mapa. No se necesita
vara de hierro para traerlo — se necesita fuente abierta: lo demás lo mide el censo.

*Cola.* El orden sin favor: lo que no pasa la vara hoy queda en cola anotada, no en silencio. La
cola tiene orden, no pena — y se revisa en cada corte.

*Anti-omisión.* La ley de la casa contra el dato sin fecha: lo que no se re-pulsó viaja FECHADO
como el corte en que se vio. Nunca «actualmente» sin hora — siempre «al 15-oct-2026».

*Triple lectura.* La lectura de la casa antes de publicar: la del técnico (¿el dato aguanta?), la del lector (¿se entiende al primer trago?) y la del rival (¿dónde me meto?). Esta pieza pasó las tres — y los mitos son puro oro de la tercera.

*Río.* El catálogo ajeno: YouTube Music, archive público, provedores varios. El río corre sin
pedirte permiso y se corta sin avisar — por eso la escuela del puente se mide por push fresco.

*Señal.* La torre que el río necesita y el cajón no. En la loma, la señal es la primera vara: lo
que no descargaste no existe en carretera — lección que el campo enseña gratis.

*Loma.* La geografía honesta del país: donde el streaming confiesa su dependencia. Toda la
escuela del puente se queda mudita en la loma — el cajón suena igualito.

*Modo avión.* La prueba de fuego del mueble local: ponerlo y que suene. Si tu lista de fiesta
necesita torre, no era lista — era esperanza.

*Anfitrión.* El que pone el teléfono en la fiesta. Su vara: lista corrida, pantalla bloqueada y
cero promesas de wifi ajeno. La casa le recomienda cajón — el río en fiesta es apuesta.

*Coleccionista.* El que suena, guarda, etiqueta y copia. No necesita FLAC de colección para
empezar: necesita la rutina — maestro en PC, copia en teléfono, lista exportada. La estructura
antes que el volumen.

*Oído con oficio.* El que escucha preguntando: qué versión, qué año, qué disco. La escuela del
detective existe para él — muffon al 18-oct-2026 con ★2.246 y AGPL firmado.

*Bitrate.* Los kilobits por segundo del audio: la medida de cuánto archivo pesa una canción. A
más bitrate, más fidelidad hasta donde el oído y el altavoz alcancen a distinguir — el 320 del
MP3 es el techo práctico del bolsillo.

*Pérdida.* Lo que un formato tira al comprimir. El MP3 la tiene (y bien administrada a 320
alcanza al bolsillo); el FLAC no la tiene — y por eso uno viaja y el otro archiva.

*Conversión.* Pasar del maestro a la copia de trabajo: FLAC a MP3, una vez, desde el original.
La conversión inversa no existe en la casa — no se inventa calidad que no bajó.

*Permiso.* Lo que la app te pide al entrar. La vara: permiso fuera de oficio = desinstalar y
volver al censo. Un reproductor que pide contactos no es reproductor — es huésped con maleta.

*Desinstalar.* El acto de higiene digital: quitar la app con fecha anotada. La casa lo
recomienda sin drama — la desinstalación honesta es la mitad de la vara que nadie cuenta.

*Actualizar.* Traer la nueva release del taller legal. En la escuela del puente, actualizar
semanal no es manía: es respirar — el río cambia de puerta y el taller contesta con push.

*Versión.* El número que el taller pone a su release (OuterTune v0.10.1 al corte). Con versión
hay historia: se puede comparar, se puede volver atrás, se puede exigir.

*Snapshot.* La foto del estado en un momento: la caja de pulso de esta pieza es un snapshot del
15-oct-2026 a las ~23:12 UTC. Mañana será historia fechada — que es el único tipo de historia
que la casa guarda.

*Dialecto.* La voz de la casa: dominicano de verdad, con clienta, barrio y chin chin — pero el
dato siempre en traje formal. El dialecto es la envoltura; la placa, el contenido.

*Chin chin.* El golpe de mesa de la moral del meme: la sentence final que clava la lección. No
es adorno — es la firma de la casa cuando el oficio quedó claro.

*Muro FB.* La fila de piezas gemelas que la casa publicaba en Facebook. Desde el 15-oct noche:
la serie 21+ va sin muro — WhatsApp puro. La ley del dueño, anotada con fecha y sin melcocha.

*Índice.* El mapa de una pieza: el árbol de esta guía. Un árbol único por pieza, con secciones y
tiempos — el lector sabe dónde está parado y cuánto falta pa la parada.

*Provedor.* El que sirve el río: la plataforma cuyo catálogo atraviesa el puente. No es socio de
nadie y no avisa cuando muda la puerta — por eso el taller que la sigue es la primera vara de
esta escuela.

*Fila viva.* La fila de asuntos que se contesta: la señal de taller respirando sin ambigüedad.
Los asuntos de esta cosecha van de 42 (Musify) a 868 (Spotube) al 15-oct-2026 — la vida no es la
cantidad, es la contesta.

*Publicar.* El acto de soltar la pieza con acta, pulso y hora. Publicar sin fecha es rumor;
publicar con fecha es mapa. Esta cosecha sale el 15-oct-2026 con pulso #10 — y su sello lo
cuenta.

*Colmado.* La bodega del barrio: lo tienes todo cerca, te fiarán la libreta, pero el catálogo es
el que cabe en el estante. En esta pieza, la escuela del puente con factura propia — respetada,
y ajena al censo.

*Puerta al viento.* Vivir de un solo río sin cajón propio: la casa abierta cuando el provedor
muda la puerta. El antídoto cabe en una línea — descarga lo que amas, streamea lo que descubres.

*Segunda fila.* Los vecinos que el censo vio y esta pieza no tomó: podcast, vídeo puro y
talleres bajo la vara del barrido. No es exclusión — es cola con orden, y se revisa en cada
corte.

*Oído del barrio.* El que escucha antes de opinar: prueba dos muebles, mira dos placas y
pregunta en la fila antes de palomear. No nace sabido — se hace con una semana de ritual bien
dada.

Portero|El firewall del teléfono: decide qué app habla con la red y cuál calla. La vara: mirar
antes de cortar, cortar lo que firma, dejar hablar lo que usas.

Informe|La lista de la primera noche: qué rastreadores intentó contactar cada app. Duele dos
minutos — ordena una tarde. El diagnóstico, no la enfermedad.

Rastreador firmante|El que la app esconde adentro: el «Analytics» de tu juego, el «Ads» de tu
linterna. TrackerControl lo firma con nombre y apellido.

VPN local|La puerta única de la escuela sin root: todo el tráfico pasa por ella — y la controlas
tú. Cero nube: el icono de VPN es normal, no es túnel.

iptables|El firewall del kernel de Linux: la escuela del root (AFWall+). El control más fino —
el paquete se decide antes de salir.

Modo estricto|El portero del castillo: NADA habla sin regla explícita (AFWall+). Máximo control,
máxima responsabilidad — el portero del castillo.

Reglas por red|Las dos puertas distintas: wifi habla más (copias, sincronías), datos lo
esencial. La factura que baja es el sueldo del portero.

Puerta única|La que el Android muestra con icono VPN: una sola por teléfono — por eso
TrackerControl y NetGuard no van juntos: un portero por puerta.

Acta de quietud|La de NetGuard: dos meses y catorce días con fecha y plan B. La quietud no se
adivina: se re-mide — el censo del cumpleaños la mira.

Taller doble|La casa M66B: NetGuard quieto, FairEmail empujando el mismo día. La prioridad del
taller de una persona, anotada sin drama.

Cumpleañero|Las dos casas de octubre: AFWall+ (27-oct, catorce) y NetGuard (24-oct, once). El
sistema libre de Android cumple años este mes.

Botón de pánico|La pausa del portero: las reglas se apagan en un toque. Lo que no tiene pausa,
no entra — la regla de todo el personal de la casa.

Corte a ciegas|El portero mal configurado: el teléfono mudo. La defensa: el informe delante y la
prueba del mensaje del hijo. Nadie corta a ciegas en esta casa.

Log nocturno|El acta diaria del portero: qué intentó hablar a las 3 AM. Un vistazo con el café —
el que lee su informe, duerme informado.

Regla de prueba|La entrada del recién llegado: toda app nueva entra cortada de la red de fondo
hasta que el informe diga qué firma. Primero calla, después habla.

Exportación de reglas|El respaldo del portero: las reglas a archivo, al sótano (26). El teléfono
nuevo recupera el portero completo en minutos.

Secuestro con formato|El «firewall» sin repo que enruta por su servidor: la puerta única del
desconocido. No es portero — es el secuestro del barrio.

Escuela del root|La de AFWall+: iptables directo, cero intermediarios. La del taller serio (20)
— el control más barato y más fino.

Escuela sin root|La de NetGuard y TrackerControl: la VPN local como puerta. Cualquier teléfono —
un suspiro de batería de costo.

Frontera del escudo|Orbot y el Tor del bolsillo: protegen el viaje, no el flujo local. El
portero y el escudo: hermanos de casa distinta.

Censo igualado|Las tres casas entre ★2.686 y ★3.923 al pulso del 15-oct-2026: el territorio sin
estrellas ni enanas. El portero no es fama — es confianza acumulada años de no traicionar.

Doctrina firmada|Las tres GPL-3.0: único censo de la serie con una sola ley. Quien escribe
firewall cree en la transparencia radical — la firma ES la doctrina.

Inclusión técnica|El censo que cubre todo el espectro: root y sin root, cada teléfono con su
portero con placa. La inclusión como diseño, no como discurso.

Telemetría|El que el contrato chiquito llama «mejorar tu experiencia»: la app reportando uso a
la casa del fabricante. La regla del aula la corta.

Regla por dominio|El corte fino de la escuela avanzada: la app habla SOLO con el servidor del
negocio — la analítica de la industria, cancelada.

Edades del oficio|El parte del portero: el viejo que empuja (AFWall+), el maduro en espera con
acta (NetGuard), el adulto que firma (TrackerControl). Las tres edades en un censo de octubre.

Cliente de prueba|El mensaje del hijo que confirma que la casa sigue hablando: el bautismo del
portero. Cortar y probar — el oficio completo en dos toques.

Listero|El que lee su informe de rastreadores con el café: el oficio nuevo del barrio. No es
paranoia — es lectura de la acta nocturna de tu propio teléfono.

Cortador|El oficio del dueño que aplica las reglas con el informe delante: ni ciego ni miedoso —
el corte fino es oficio de vara, no de reflejo.

Informe del sábado|La cita semanal con el log: qué firmó la madrugada, qué se corta hoy. La
rutina que mantiene el portero fino sin volverse obsesión.

Firmante nocturno|La app que habla a las 3 AM sin que nadie la llame: el cliente fiel de los
servidores de analítica. El informe nocturno lo firma con hora — el dato no miente.

Madre de las reglas|La lista de los que hablan: el documento del portero con las tres columnas
(permanente, wifi, cortado). El expediente que se exporta junto a las reglas — la casa con su
constancia.

Reporte de la noche|El del meme: «47 intentos, 0 pasados» — el parte que el catorceañero firma
cada madrugada. La mejor lectura de las 3 AM, junto al silencio.

Cobertura y control|La vara que no confunde: el portero manda en el flujo — la señal la firma el
técnico del barrio. Cada mueble pa su oficio.

Silencio de fondo|Lo que el corte fino produce: las apps funcionan, los rastreadores callan. El
usuario no nota el portero — nota la factura que baja y la batería que dura. El oficio que se
nota por lo que deja de pasar.

Puerta de la familia|Lo único que nunca se corta: el mensajero de los tuyos. El portero estricto
de la casa firma la excepción primera — la familia habla siempre.

*🗓 EL RITUAL DE LA PRIMERA SEMANA (del barrio de puertas abiertas al portero con reglas)*

*DÍA UNO — el inventario de puertas.* Cuántas apps tienes y cuáles necesitan internet de verdad: el mensajero, el banco, el mapa, el correo. La lista corta de lo que habla — el resto es sospechoso hasta que el informe diga lo contrario.

El inventario del portero es de cinco minutos y ordena la tarde.

*DÍA DOS — el informe.* TrackerControl de F-Droid (placa: ★2.686 al pulso del 15-oct-2026, GPL-3.0): permiso de la puerta local, jornada completa de observación SIN cortar nada. A la noche: la primera lista de rastreadores de tu vida.

Duele — y ordena: con esa lista se trabaja el resto de la semana.

*DÍA TRES — el corte fino.* NetGuard (o AFWall+ con root): las reglas con la lista delante — corta lo que firma, deja hablar lo que usas. El bautismo: el mensajero del hijo manda el mensaje de prueba y llega.

El portero está vivo y la casa sigue hablando.

*DÍA CUATRO — las dos puertas.* Las reglas por red: en wifi habla más (copias, sincronías, actualizaciones); en datos habla lo esencial. Y la prueba del plan de datos: el consumo del día cuatro contra el del lunes — el portero ya está facturando su sueldo.

*DÍA CINCO — la noche del portero.* La prueba del informe nocturno: TrackerControl pausa una noche más (o los logs de AFWall+) y mira qué intentó firmar a las 3 AM. Lo que firmó y está cortado: confirmado el acierto. Lo que firmó y habla: entra a la lista del corte del sábado.

Trabaja de noche — el informe de la mañana es su acta.

*DÍA SEIS — el acta del portero.* La nota-placa del taller: qué portero, qué censo, qué reglas gruesas, la fecha del primer corte, el plan B del acta de NetGuard. El portero documentado junto al expediente del personal (29): la casa con sus reglas escritas.

*DÍA SIETE — la placa, otra vez.* Vuelve al censo con el portero montado: ¿el mensajero sigue
hablando? ¿La factura de datos baja? ¿El cumpleañero NetGuard empujó antes del 24-oct?

El día que respondes sin ayuda, la casa cumplió: tu teléfono ya no es un barrio de trescientas
puertas abiertas — es el barrio del portero: cada quien habla lo que necesita, y el que no
necesita, calla.

───────────────────

*Y la regla del portero que la serie pide clavar en la puerta del teléfono:* mirar antes de
cortar, cortar lo que firma, dejar hablar lo que usas — y el portero que no tiene pausa, no
entra.

───────────────────

*🩺 LA SALUD DEL PORTERO AL CORTE (el parte médico de las tres casas)*

El parte del 15-oct-2026: dos respirando, una en espera con acta.

TrackerControl, push del 14-oct: aire de la víspera — el detective firmando rastreadores hasta
ayer. AFWall+, push del 12-oct: tres días de aire en la casa catorceañera — el oficio más viejo
del censo empujando como siempre.

NetGuard, push del 1-ago: la quietud del acta — dos meses y catorce días, con el taller vivo en
la otra casa (el correo empujó el 15-oct).

El balance del parte: dos casas al máximo, una en espera informada — cero quietudes sin acta. La
lectura fina del parte: el portero es el primer territorio de la serie con la mezcla completa —
vida, espera y longevidad en el mismo censo.

Las tres edades del oficio (el viejo que empuja, el maduro que descansa, el adulto que firma) en
tres casas de octubre.

*📐 LA MEDIDA DEL PORTERO (lo que el censo deja leer y no se ve)*

Tres medidas finas de la forja.

La primera: el tamaño de las casas. Las tres entre ★2.686 y ★3.923 al pulso del 15-oct-2026 — el
censo más IGUALADO de la serie: el territorio del control no tiene estrellas ni enanas.

La lectura: el firewall no es territorio de fama — es territorio de confianza acumulada: el usuario del portero no elige por aplauso (no hay aplauso pa un firewall), elige por años de no traicionar. Tres casas de tamaño parecido = tres oficios de confianza parecida.

La segunda: la concentración de ley. Las tres GPL-3.0 — único censo de la serie con UNA sola ley
en las tres casas.

La lectura fina: el territorio del control de red es doctrinal: quien escribe firewall cree en
la transparencia radical — y la firma lo dice.

La forja lo anota: si algún día una casa del portero cambia de ley, el acta será el parte más
importante del ecosistema — la firma del portero ES su doctrina.

La tercera: la geografía de las escuelas. Root (AFWall+) y sin root (NetGuard, TrackerControl) —
dos caminos técnicos, una meta.

La medida honesta: el censo cubre TODO el espectro de teléfonos: el desbloqueado del taller (20)
y el del cajón sellado (25) tienen su portero con placa.

El territorio del control no deja a nadie sin mueble — la inclusión técnica como diseño, no como
discurso.

*🎯 EL MINIQUIZ DEL PORTERO*

Cinco preguntas de la pieza. Las respuestas van AL REVÉS al pie (leídas de atrás para adelante),
para que nadie las palmee sin pensarse el plato.

*LAS PREGUNTAS:*

1) ¿Qué casa cumple catorce años este mes y qué escuela firma?

2) ¿Qué acta trae NetGuard al censo y de qué taller es?

3) ¿Qué hace TrackerControl que los otros no hacen?

4) ¿Qué es la VPN local y quién la controla?

5) ¿Cuál es la secuencia del oficio del portero?

*Respuestas al revés (léelas de atrás para adelante):*

REV|selbatpi noc toor led aleucse al — tco-21 led hsup ,0.3-LPG ,2102-tco-72 le adican :+llaWFA=1

REV|)82( oerroc led omsim le ,B66M rellat led — )6202-oga-1 led hsup( duteiuq ed saíd ecrotac y sesem sod=2

REV|ppa adac ralbah ótnetni rodaertsar éuq artseum et :erbmon rop serodaertsar sol a AMRIF=3

REV|ebun orec ,út salortnoc al y — alle rop asap ocifárt le odot :onofélet led ortned acinú atreup al=4

REV|elbinopsid ocináp noc — )sasu euq ol( raborp → )amrif euq ol( ratroc → )lortnoCrekcarT( rarim=5

(Las respuestas correctas —de arriba abajo— son: AFWall+ el catorceañero del root; NetGuard la
quietud del cumpleañero; TrackerControl el detective con nombre; la VPN local la puerta que tú
controlas; y mirar-cortar-probar la secuencia del oficio.)

───────────────────

*PRIMERA CARTA — al que nunca vio el informe de su teléfono.*

Esta pieza te trae la primera lista honesta de tu vida digital: qué apps intentaron hablar esta
noche y con quién. El informe duele dos minutos — y después ordena años.

La tarde del portero es la de mayor retorno de toda la serie: la factura de datos baja, la
batería amanece fría, y la linterna deja de tener vida nocturna.

Lo que pasa en tu teléfono de noche, merece un testigo — y el testigo se instala en una tarde.

*SEGUNDA CARTA — al taller M66B.*

La forja firmó esta noche dos actas de tu casa: la del correo que empuja el mismo día del censo, y la del portero con su quietud fechada (dos meses y catorce días al corte, once años el 24-oct). La serie no despide: anota, espera y re-mide — y el censo del cumpleaños ya tiene su vara preparada.

La casa de FairEmail y NetGuard lleva once años de oficio firmado: la puerta queda abierta y la
vara, lista.

*TERCERA CARTA — al que nota que esta pieza abre el bloque del sistema.*

Exacto: la cosecha (21-30) midió los territorios del diario; el bloque del sistema (31-40) mide lo que SOSTIENE el diario — y arranca por el portero porque el control del flujo es el cimiento de la privacidad del diario entero. Los próximos del bloque (permisos, almacenamiento, batería) se escriben con la misma vara: el backend del teléfono, medido como se mide el frente.

El sistema también es de la casa — y esta noche aprendió a tener portero.

───────────────────

💓 *PULSO 29-OCT-2026 — verificación profunda de La Bandita (pieza 31).*

Alcance de esta nota: se re-verificaron el 29-oct-2026 los repos y enlaces atribuidos a esta
pieza: 4 repos GitHub confirmados. La historia original no se reescribe: conserva su fecha y su
texto; esta nota solo añade el estado medido hoy.

Actividad medida hoy: 1 con actividad hoy · 1 en 7 días · 1 en 30 días · 1 en 180 días · 0
dormidos · 0 archivados.

Continuidad: sin archivados ni dormidos entre los repos atribuidos a esta pieza en esta pasada
(verificado 29-oct-2026).

*Placas de control (selección por actividad reciente y juventud, no por fama):*

• `m66b/fairemail` — ★4.736 (verificado 29-oct-2026) · última actividad 2026-10-29 · GPL-3.0 · release 1.2339 Elopteryx (2026-10-24).

• `trackercontrol/tracker-control-android` — ★2.703 (verificado 29-oct-2026) · última actividad 2026-10-28 · GPL-3.0.

• `ukanth/afwall` — ★3.512 (verificado 29-oct-2026) · última actividad 2026-10-17 · GPL-3.0 · release Version 5.0.0 (2026-10-12).

• `m66b/netguard` — ★3.949 (verificado 29-oct-2026) · última actividad 2026-08-01 · GPL-3.0.

Enlaces web: esta pieza no trae URL explícitas fuera de los repos citados; su verificación es la
de los repos de arriba y la del universo del censo cuando cita agregados.

Vara de cierre: futuro y actividad comprobable antes que aplauso. Si un repo deja de empujar, la
próxima foto lo dirá con fecha; si nace una rama viva, entrará por la misma puerta: fuente,
fecha y pulso.