*64 — LA APRENDIZ DEL TALLER*
*Open Interpreter ★68.589 (pulso 16-oct-2026) convierte tu «hágame un programita» en código
escrito y corrido EN TU máquina — la aprendiz que muestra la receta antes de encender el fuego
(WhatsApp · La Bandita · dominicano-ES)*

───────────────────

*⚡ EN UN RESPIRO*

La aprendiz del taller es Open Interpreter: la mente de la casa (61) con oficio de programadora
— le dices «renombreme las fotos por fecha», ella ESCRIBE el código, te lo MUESTRA, y con tu
visto lo corre en tu máquina: la computadora, obedeciendo en tu idioma.

*🗺 MAPA DE ESTA GUÍA*

La fila de la IA propia (61-70) suma su oficio fino: la mente (61) piensa, la cara (62) muestra,
las manos (63) hacen las faenas del calendario y el papel — esta pieza sexagésimocuarta toma las
faenas del TECLADO (el código de la casa, escrito y corrido con permiso).

El recorrido: la escena del «no sé programar pero necesito» (la de toda casa con una tarea de computadora), el censo del oficio y las tres capas de la aprendiz. Después la vara de la letra propia, la doctrina de la aprendiz (la frontera con el agente que corre sin preguntar), la receta por pisos, los mitos y las preguntas de la fila.

Y al cierre: seis casos, las despensas, los riesgos con fecha, el ritual de siete días y las
cartas de la mesa.

*🌱 LA SEMILLA*

La escena del «no sé programar pero necesito»: la casa con una tarea de computadora que ninguna
app resuelve (las 3.000 fotos del teléfono sin orden, los 200 PDF con nombres raros, el Excel
del colmado sin resumen — la solución existe: SON CUATRO LÍNEAS DE CÓDIGO; el problema: nadie de
la casa sabe escribirlas).

Y los dos caminos de siempre: la store (la app genérica que casi hace lo que quieres — con
anuncios y con tus datos) o el YouTube del tutorial (dos horas pa un renombrado).

La forja firma la tercera vía del bloque: Open Interpreter — la aprendiz de programadora: le hablas en TU idioma («ordéname las fotos por mes y año»), ella escribe el script, te lo enseña COMPLETO (jamás una caja negra), y con TU visto lo corre en tu máquina. El código: de la casa — la aprendiz: del taller.

Su vara: el código se muestra antes de encender el fuego — el visto, SIEMPRE tuyo.

*🗼 EL CENSO DEL OFICIO (censo 16-oct-2026)*

La aprendiz y su familia de oficio — las placas del código propio, medidas HOY.

*La aprendiz — Open Interpreter.* `openinterpreter/open-interpreter` ★68.589 (pulso
16-oct-2026), nacida el 14-jul-2023, con aire reciente (push de la semana), con su letra
Apache-2.0 — **LETRA DE OFICIO LIMPIO** (la firma de la escuela Apache: el código de la
aprendiz, pa cualquier taller).

La ayudante que convierte el idioma de la casa en código corrido local: la aprendiz más famosa
del mundo libre (68.589 casas firmando su oficio).

*La vara del ranking, con honestidad del censo:* la placa del cofre de la casa (56: Vaultwarden
★69.164, pulso 16-oct-2026) la supera por UNA NARIZ (575 estrellas: la distancia más chica del
podio de la obra) — la aprendiz NO es placa mayor: es la PLACA DEL OFICIO FINO (la primera del
oficio de código corrido en tu máquina, por encima de la forja de la 57: Gitea ★58.533).

El censo no decora: mide.

*La familia del oficio en la fila:* la mente (61: Ollama ★183.478, pulso 16-oct-2026 — los modelos que la aprendiz piensa con), el motor (llama.cpp ★131.403 — la cocina del pensar), las manos MCP (63: ★91.311 — las faenas firmadas de la casa). La pareja del taller: la aprendiz USA la mente local (el oficio entero, en tu caja: el pensar y el escribir, sin taller ajeno).

*🏛 LAS TRES CAPAS DE LA APRENDIZ*

El oficio de la aprendiz, por capas — del pedido al código corrido.

*La capa del oído — el idioma de la casa.* El oficio fino de la aprendiz: entender la faena como
la dices («las fotos por mes», «el Excel con totales por semana», «el PDF que se llame como la
fecha») — y la vara fina del oído: la pregunta ANTES del código (lo que no entendió, lo
pregunta: «¿las fotos del WhatsApp también?» — la aprendiz de verdad: pregunta antes de
hornear).

La capa que derriba el muro: el código, dejando de ser idioma extranjero.

*La capa del taller — el código escrito a la vista.* El corazón del oficio: la aprendiz ESCRIBE
el script (las líneas completas, en TU pantalla — Python, shell: el idioma del oficio) y lo
muestra ANTES de correr (la caja negra: jamás — cada línea, legible y comentada pa quien quiera
leerla).

Suma la vara fina del taller: el código queda TUYO (el script guardado en tu carpeta: la receta
de la faena, pa la próxima vez — sin la aprendiz si quieres). La capa que enseña: cada faena, un
mini-curso de código gratis.

*La capa del visto — el fuego encendido con permiso.* La vara mayor del oficio (la doctrina de
la fila 63, aplicada al código): el script corre SOLO con tu visto (la aprendiz pregunta: «¿lo
corro?» — el enter humano, línea por línea o faena por faena).

Su vara fina: los permisos por nivel (el modo seguro: pregunta TODO; el modo de confianza: corre lo de lectura — jamás el borrado sin visto). Y firma la diferencia con la tienda: el agente ajeno corre en su nube con tus datos; la aprendiz, en tu máquina con tu enter.

*⚖ LA VARA DE LA LICENCIA*

*Apache-2.0 — la letra del oficio limpio.* La letra de la aprendiz (la escuela Apache): uso, estudio, mejora y hasta el oficio comercial — con la cortesía del oficio (la nota de patentes: la paz legal firmada). La lectura fina de la vara: la aprendiz puede vivir en la caja del colmado Y en el taller del negocio — la letra, ancha como la casa.

La lectura de la fila: la trinidad de letras del bloque (la mente: MIT — la más ancha; la cara: por leer en su hogar; la aprendiz: Apache — el oficio con paz legal firmada): las tres, letras de taller libre. La vara del censo: cada letra leída en su hogar — la honestidad del bloque, firme.

*🎯 LA DOCTRINA DE LA APRENDIZ (las tres reglas del código propio)*

Aquí va la frontera que el agente suelto jamás dibuja — la doctrina de esta pieza.

*Regla uno — el código se muestra ANTES de encender el fuego.* La vara mayor de la aprendiz:
jamás un script corrido a oscuras (la caja negra de la tienda: «confía, es magia» — la aprendiz
enseña las líneas: «esto es lo que voy a hacer»).

Su vara fina: si no lo entiendes, PREGUNTAS (la aprendiz explica línea por línea — la
explicación, parte del oficio: cada faena, un mini-curso). La regla mayor del oficio: la magia
sin receta, no entra al taller.

*Regla dos — el fuego se enciende con TU visto, y el borrado: con doble visto.* La vara fina de
la confianza: los permisos por nivel (el modo seguro: cada script pregunta; el modo de
confianza: solo lo de lectura — leer, listar, contar), y la vara mayor: lo que BORRA o
SOBRESCRIBE, jamás sin doble visto («¿corro esto?

BORRARÁ los originales» — el aviso en grande, el enter pensado). La regla del fuego: la
computadora obediente también es peligrosa — por eso el visto, SIEMPRE humano.

*Regla tres — la aprendiz enseña: cada faena deja la receta guardada.* La línea educadora del
bloque: el script que hizo la faena, QUEDA en tu carpeta (la receta escrita: reutilizable,
editable, donable), y la vara fina: la segunda vez, la casa ya sabe (el muchacho del liceo
leyendo su primer script: el código, dejando de ser idioma extranjero — una faena a la vez).

La regla del oficio: la aprendiz que solo hace, es empleada; la que enseña, es maestra — la de
la casa: las dos cosas.

*🔧 LA RECETA DE LA APRENDIZ EN PIE (una tarde, por pisos)*

Cómo se arma sin equivocarse:*

*Piso 1 — la mente en pie (ya está).* La mente (61) respirando en la caja (los modelos del
taller: la pareja del pensar). La receta de la aprendiz: sobre la mente local — el oficio, sin
taller ajeno.

*Piso 2 — la aprendiz instalada (quince minutos).* Open Interpreter bajando al taller (un comando: del repertorio de la casa), el modelo local conectado (la mente de la 61 como su cerebro: la pareja del oficio), y la primera prueba en seco («¿qué puedes hacer?» — la aprendiz, presentándose). El taller: con aprendiz.

*Piso 3 — la primera faena (media hora, la del corazón).* La faena real de la casa (las fotos
sin orden: la de todas las familias), el pedido en tu idioma («ordename las fotos por mes y año,
sin borrar nada»), el script MOSTRADO completo (las líneas en tu pantalla: leídas con calma), y
el visto dado (el código corriendo: las 3.000 fotos, ordenadas).

La primera faena: hecha — y la receta: guardada.

*Piso 4 — los permisos firmados (quince minutos).* El modo del taller elegido (el seguro pa empezar: pregunta todo; el de confianza: cuando la mesa confíe), la vara del borrado probada (el script que borra: el doble visto en acción — el aviso en grande), y la lista de faenas hechas anotada (el diario del oficio). La confianza: con firma.

*Piso 5 — la segunda y tercera faena (una tarde de calma).* Las faenas de la vida real, de a una (el Excel del colmado: resumido; los PDF con nombre de fecha: renombrados; la lista del mercado: ordenada por pasillo), cada una con SU receta guardada (la carpeta de scripts de la casa: creciendo). La casa: con su biblioteca de recetas.

*Piso 6 — el vigía y la póliza (media hora).* La carpeta de scripts en el respaldo (dos discos: la póliza del oficio), la prueba del desastre (una faena re-corrida desde la receta: idéntica), y la aprendiz en el mapa (la página del taller: el oficio, documentado). El oficio de código: oficial en la casa.

*El oficio fino:* la receta compartida con cortesía Apache — cada casa ajusta la suya; el taller
libre: compartiendo oficio como comparte plato.

*🧊 MITOS DESMONTADOS*

*«Programar es pa developers».* El mito del gurú, jubilado (decimoquinta vez en la fila):
programar COMO OFICIO es pa developers; programar COMO FAENA de casa («renombreme esto», «sumeme
aquello») es pa cualquier dueño — la aprendiz traduce tu idioma al código y el código de vuelta
a tu idioma.

Con vara fina: el developers de la casa (el del caso del liceo) puede leer los scripts y
aprender — la puerta del oficio serio: abierta de par en par. La programación de faenas: pa la
casa entera.

*«Una IA que corre código es un virus andante».* El miedo de la mesa, leído con la vara de la
doctrina: una IA que corre código SIN PERGUNTAR lo es (el agente suelto de la tienda: el riesgo
real); la aprendiz muestra, pregunta y espera TU visto (la regla dos: el borrado, con doble
visto — la casa decide qué se enciende).

El virus andante: la versión sin permiso; la aprendiz: la versión con llave. La diferencia
entera: está en el enter.

*«ChatGPT ya hace eso».* El mito de la tienda, desmontado con el censo: el chat de la tienda TE MUESTRA el código (a veces) — pero lo corre EN SU nube (tus fotos: viajando; tus archivos: subiendo; el faenado: en taller ajeno). La aprendiz corre EN TU MÁQUINA (los archivos: jamás salen; la faena: local de la casa — el oficio entero, sin un byte de viaje).

La vara fina: la mitad del trabajo del chat ajeno (el copiar, el pegar, el abrir la terminal) —
hecha por la aprendiz. El «ya hace eso»: hace la MITAD — y la mitad que hace, la hace ajena.

*«Y si borra algo importante?».* El temor del dueño, honesto y con respuesta: la doctrina está
escrita PA ESO (el borrado: doble visto con aviso en grande — jamás automático), y la póliza de
la fila (el respaldo del taller: los discos del domingo) cubre el resto (lo borrado por error:
restaurado de la copia).

Otra vara fina: la primera semana, modo seguro TODO (cada script preguntando) — la confianza:
con deuda de prueba. El miedo: legítimo — y la casa, armada pa él.

*❓ PREGUNTAS DE LA FILA*

*¿Qué clase de faenas puede hacer — y cuáles no?* Hace: las faenas de ARCHIVOS y TEXTO de la
casa (renombrar y ordenar fotos, resumir planillas, convertir formatos, extraer datos de PDFs,
organizar carpetas, preparar listas) — la oficina del hogar, completa.

No hace (o no debe): las faenas de SISTEMA profundo (tocar la instalación del sistema, los drivers, las llaves del cofre 56) — la vara fina: la aprendiz sirve la CASA, jamás la fundación (los cimientos, del dueño y sus manuales). Y la de siempre: el dinero (pagar, comprar) — JAMÁS (la mano que ninguna casa firma: la misma vara de la 63).

*¿Necesita la mente local (la 61) o puede usar la de la tienda?* Puede ambas — y la vara de la
fila: la pareja COMPLETA es mente local (el pensar y el escribir, todo en la caja: la
conversación Y la faena, sin un byte de viaje).

La mente ajena solo con vara seria (tu código y tus archivos pasando por taller ajeno: la decisión, firmada con los ojos abiertos — la casa seria: la pareja local). La recomendación del bloque: la aprendiz con la mente de la 61 — la casa completa.

*¿La aprendiz sirve pa el negocio del colmado o es pa hobby?* Sirve pa negocio — con vara de
separación (la del caso ocho de la 51: el negocio, con SU cuenta de dueño y SU carpeta): las
planillas del colmado resumidas cada tarde, las facturas del despacho ordenadas por mes, el
inventario contado desde las fotos.

Y la vara fina: los scripts del negocio, en SU carpeta (la receta del negocio: separada de la de
la casa — la vara del confesorio, aplicada al código). El hobby y el negocio: la misma aprendiz,
dos llaveros.

*¿Cuánto tarda en aprender a hacerme caso — o ya nace sabiendo?* Nace sabiendo lo GENERAL
(renombrar, resumir, convertir: el oficio base de la escuela) y aprende lo TUYO con el contexto
(le dices dónde están tus fotos y cómo las quieres: la faena, a la medida).

Y la vara fina del oficio: los scripts guardados son SU memoria (la segunda vez, la casa pide la receta guardada: la faena instantánea — el aprendizaje de la casa: en tus recetas, no en su cabeza). La aprendiz: sabia de fábrica y de taller a la vez.

*¿Se puede romper la computadora con un mal script?* Se puede — POR ESO existe la doctrina (la
regla dos: el modo seguro pregunta TODO al arranque; el borrado: doble visto; el sistema
profundo: fuera del alcance) y la póliza (el respaldo: lo borrado por error, restaurado).

Y la vara fina honesta: el riesgo real de la aprendiz es MENOR que el del humano apurado en la terminal (el dueño copiando comandos de YouTube sin entenderlos: el riesgo de la década pasada; la aprendiz explicando cada línea: la educación del riesgo). La computadora: más protegida CON la aprendiz que con el tutorial apurado.

*¿Y el muchacho que ya programa — la aprendiz lo estorba o lo empuja?* Lo empuja — con vara
fina: el que ya programa usa la aprendiz como el profesional usa su ayudante (el script base en
segundos, el ajuste fino de su mano: el oficio serio, más rápido).

Su vara fina educadora: los scripts de la aprendiz, legibles y comentados (el muchacho lee, corrige, mejora — la ayudante que también es maestra: la puerta del oficio serio, abierta de par en par). La aprendiz: no reemplaza el oficio — lo siembra.

*¿Las recetas de la casa sirven pa otra casa — el vecino, el club, el comité?* Sirven — con
cortesía de oficio (la letra Apache de la escuela: el script libre pa compartir), y la vara
fina: cada casa ajusta la SUYA (la carpeta de fotos del vecino no es la tuya: las rutas se
cambian, la receta se adapta — el oficio de compartir recetas: tan viejo como la cocina).

El club y el comité: con biblioteca colectiva — el taller libre, compartiendo oficio como
comparte plato.

*🧪 CASOS DEL BARRIO*

*Caso uno — las 3.000 fotos del teléfono.* La mamá con tres años de fotos sin orden (el
cumpleaños del niño mezclado con la factura del gas: el álbum del caos).

Receta: el pedido en su idioma («ordename las fotos en carpetas por año y mes, sin borrar nada, las que estén mal abiertas déjalas en una carpeta de revisar»), el script mostrado (leído con calma: «hace carpetas 2024-01, 2024-02… y las mueve»), el visto, y el álbum: ordenado.

La tarde de orden: jubilada — el álbum de la casa: con fecha y todo.

*Caso dos — la planilla del colmado.* El colmadero con su Excel del mes (las ventas anotadas a mano en la planilla: los totales, a ojo — el balance de diciembre: una sorpresa cada año). Receta: «sumame las ventas por semana y dame el mes por línea, los gastos aparte», el script mostrado, el visto, y el resumen: en su carpeta (receta guardada: cada fin de mes, UN comando).

El balance del colmado: de sorpresa a oficio — la planilla: con totales de verdad.

*Caso tres — los PDF del banco.* El papá con tres años de estados de cuenta en PDF (200 archivos con nombres como «documento(23).pdf»: el archivo del caos). Receta: «renombralos con la fecha del extracto que dice adentro, carpeta por año», el script mostrado (la aprendiz leyendo las fechas de adentro: el truco fino del oficio), el visto, y el archivo: con nombre y orden.

El caos del banco: jubilado — el papel del banco: encontrable por fin.

*Caso cuatro — el curriculum y la carta del muchacho.* El joven del liceo (el de la beca de la
63) pidiendo su curriculum en tres formatos (PDF pa la beca, Word pa el correo, texto pa el
formulario web: la misma vida, tres vestidos).

Receta: la mente redactando (la del caso de la 62), la aprendiz convirtiendo (el script de los tres formatos: mostrado y corrido con visto), y el resultado: en su carpeta (las tres versiones, con nombre limpio). La beca del muchacho: con papeles de oficio — la aprendiz: su primera jefa técnica.

*Caso cinco — la foto del amigo que se cae a pedazos.* El fotógrafo del barrio (el del caso de
la 59) con la foto antigua del cliente (la del abuelo: doblada, manchada, única) — la
restauración que la store cobra a suscripción.

Receta: la mente local con el modelo de imagen (la del caso del taller), la aprendiz preparando el paso del archivo (el script de conversión y limpieza de bordes: mostrado, visto, corrido — en TU máquina, la foto del abuelo: JAMÁS viajando), y la restauración fina del modelo local. La foto única: restaurada EN casa — la suscripción de la store: jubilada.

*Caso seis — el club del barrio y la nómina del torneo.* El secretario del club (el de la copa
de la 63) con la nómina de 40 jugadores en un papel (los equipos de los domingos: parejos «a ojo
de campeón» — las quejas de siempre).

Receta: la lista pasada a texto (la foto al despacho 59: el OCR de la casa), el pedido («repártelos en cuatro equipos parejos por edad, muéstrame las nóminas»), el script mostrado, el visto, y los equipos: parejos con matemática (la vara del cuaderno de la 57: el acta del torneo, guardada). La copa del barrio: con equipos de oficio — el «me tocó con los grandotes»: jubilado.

*Caso siete — el grupo del comité y las actas.* La señora del comité (la del censo de la 62) con
las actas de las reuniones (12 meses en un cuaderno: «el acta de marzo», perdida entre facturas
— la asamblea que no encuentra lo que firmó).

Receta: las actas al despacho (59: el OCR de la casa), el pedido («pasalas a texto, nombre por fecha, un resumen de acuerdos por cada una»), el script mostrado, el visto, y el archivo del comité: ordenado con resúmenes. La asamblea del barrio: con memoria buscable — el acta de marzo: a dos clics.

*Caso ocho — el video del cumpleaños.* La familia con el video del cumpleaños del niño (el
teléfono graba en un formato que la TV del sofá no lee: «no abre» en plena fiesta — el drama de
todos los hogares).

Receta: la aprendiz con el conversor («pásalo a un formato que lea la TV, misma calidad»), el script mostrado (el comando de conversión: leído y entendido), el visto, y el video: abriendo en la TV (receta guardada: los próximos cumpleaños, sin drama). La fiesta del barrio: con video corriendo — el «no abre»: jubilado.

*🏭 LA DESPENSA DE DATOS (todo lo medido, en una repisa)*

*Las placas (censo 16-oct-2026):* la aprendiz ★68.589 — la PLACA DEL OFICIO FINO (la primera del
código corrido en tu máquina; el cofre de la 56 la supera por una nariz de 575: el censo no
decora).

*La edad:* nacida el 14-jul-2023 (tres años de oficio — la misma hornada del mes de la mente y
el motor: julio 2023, el verano del oficio local).

*El aire:* push de la SEMANA (el oficio, en faena diaria).

*La letra:* Apache-2.0 — el oficio con paz legal firmada (la escuela Apache: uso, mejora y
comercio con cortesía).

*La pareja:* la mente local (61) como su cerebro — el oficio entero en tu caja.

*La vara de la casa:* el código se muestra ANTES de correr; el borrado, con doble visto; el
dinero, JAMÁS; los scripts, guardados como recetas de la casa.

*🕰 LA EDAD DE LA APRENDIZ*

Tres años (2023-2026): la hornada de julio de 2023 (la mente el 26, la aprendiz el 14 — el mismo verano del oficio local: la década decidiendo su dirección). La historia del nacimiento: julio de 2023 — la forja firma la idea que la tienda no quiso vender: «y si el chat no solo contesta, sino que CORRE lo que contesta — en TU máquina, mostrando el código?».

Tres años después: 68.589 casas firmando el oficio. La edad de la aprendiz: la idea que la
tienda pensó peligrosa y el mundo libre pensó obvia — con permiso, todo lo demás es magia
barata.

*💬 LA CONVERSACIÓN HONESTA*

Dígase claro: la aprendiz NO convierte a nadie en programador (el oficio serio del código: años de taller — la pieza no vende humo). Lo que hace: la faena de computadora de la casa (la de todos los meses, la que ninguna app hace exacta) — hecha con código VISTO, guardado y reutilizable.

Otra vara fina honesta: la curva existe (la primera faena, con calma y preguntas; la segunda, con confianza; la décima, con biblioteca propia) — la casa no se apura: arma la tarde, corre el modo seguro, y deja que la aprendiz enseñe. La honestidad del bloque: la aprendiz es maestra — no vendedora de atajos.

*🎞 LO QUE ESTA PIEZA NO DICE*

No dice que la aprendiz convierta a nadie en developer — dice que hace la faena de la casa con
código visto y receta guardada.

No dice que corra sin preguntar — dice lo contrario: el fuego SOLO con tu visto, y el borrado
con doble visto.

No dice que sea placa mayor — dice la vara honesta: 68.589, una nariz detrás del cofre de la 56
— placa del oficio fino.

No dice que tus archivos viajen — dice que corren EN TU MÁQUINA: el oficio entero, sin un byte
de taller ajeno.

No dice que sea pa developers — dice que es pa la casa: el código, traducido del barrio al
oficio y de vuelta.

*🩺 LA SALUD DEL OFICIO AL CORTE (el parte de la aprendiz)*

El parte del 16-oct-2026: la aprendiz con aire de la semana, la letra Apache firme, la familia
del oficio en faena (la mente con push de HOY, el motor con push de HOY, las manos MCP con push
de la semana).

La lectura fina del parte: la hornada de julio 2023 — la más sana del censo (la mente, el motor
y la aprendiz: los tres en faena diaria, tres años después). La salud del oficio local: la
generación que aguantó — firma y crece.

*📐 LA MEDIDA DEL OFICIO (lo que el censo deja leer y no se ve)*

Tres medidas finas de la noche.

La primera: la nariz del cofre. 69.164 contra 68.589: la distancia más chica del podio de la obra (la placa mayor más cerca de caer) — y la vara fina: si la aprendiz la pasa, el bloque de la IA propia tendría CUATRO de las cinco placas mayores.

La medida del momento: el oficio del código local, comiendo tierra a los veteranos.

La segunda: la hornada de julio. La mente (26-jul-2023), la aprendiz (14-jul-2023) y el motor
(10-mar-2023): el año cero del oficio local — tres forjas nacidas en meses, dueñas hoy del podio
(183k, 131k, 68k).

La medida fina de la época: la década no la firmó un gigante — la firmó un verano.

La tercera: el código como receta. El oficio fino de la aprendiz: cada faena deja script guardado (la biblioteca de recetas de la casa: creciendo faena a faena) — la medida del aprendizaje de la casa: en archivos propios (la memoria del taller: en el disco, no en la cabeza ajena).

La casa que faena: escribe su propio manual.

*📻 LA SEGUNDA FILA (lo que quedó fuera del oficio)*

*La historia — el verano que decidió la década.* Julio de 2023: la mente (el 26) y la aprendiz
(el 14) — dos forjas del mismo verano, dos ideas gemelas (el pensar local; el hacer local), y la
vara fina: la tienda en esos meses vendiendo la nube como el único futuro.

La visita de la obra: el verano que el mundo libre eligió su camino — tres años después, el
podio es de ese verano.

*El tutorial de YouTube — la visita del pasado.* Las dos horas de video pa un renombrado (el copy-paste apurado del comando que no entiendes: el oficio a ciegas de la década pasada). La vara de la visita: la aprendiz no eliminó el aprender — lo ordenó (el mismo conocimiento, pedido a la medida y explicado en el momento: la clase particular del oficio, gratis, en tu casa).

*El script como herencia — la vara del archivo.* El oficio fino de las recetas guardadas (la
biblioteca de la casa: los scripts con nombre de gente, pasables al muchacho, al socio, al
club): el código de la casa, convirtiéndose en archivo familiar (como las recetas de cocina de
la abuela: escritas, guardadas, heredadas).

La lectura fina: la primera generación de la historia que hereda scripts junto con las fotos —
el álbum y la biblioteca: en la misma gaveta.

*🗼 EL OFICIO EN TU DÍA A DÍA (cuatro rutinas del código callado)*

*El morning del pedido.* La faena del día dicha en voz alta («recuerdeme ordenar las fotos de
ayer»), la receta guardada corriéndola (un comando, un visto). El morning: con oficio.

*El mediodía de la planilla.* El Excel del colmado al cierre («dame el resumen de la semana»),
la receta del negocio corriendo. El mediodía: con totales de verdad.

*El evening de la enseñanza.* El muchacho leyendo un script (la clase del taller: quince
minutos, una receta, un concepto). El evening: con escuela.

*La madrugada de la gira.* La gira mensual de la biblioteca (las recetas leídas, las muertas
borradas con visto, las nuevas respaldadas): el oficio, visitado como toda casa seria. La
madrugada: con biblioteca en orden.

*🧵 GENEALOGÍAS DEL OFICIO*

*El abuelo — el muchacho que sabía.* El del barrio de siempre: el único del bloque que tocaba la computadora («dale eso al muchacho de la 12» — el oficio: de un muchacho prestado, con horario ajeno). El abuelo del oficio: la faena digital — hecha por otro, cuando él podía.

*El padre — el tutorial y el copy-paste.* Los 2010s: el tutorial de YouTube (dos horas por un
comando: copiado sin entender — y el miedo eterno de «¿y si lo rompo?»). El padre del oficio: la
faena digital — a ciegas, con suerte.

*La madre — la app que casi hace.* 2015-2023: la store y su app genérica (la que casi ordena tus
fotos — con anuncios, con suscripción y con tus datos viajando). La madre del oficio: la faena
digital — alquilada a medias.

*El hijo — la aprendiz de la casa.* 2026: la faena dicha en tu idioma (el código mostrado, el visto tuyo, la receta guardada — el oficio: propio, entendido y heredable). La genealogía completa: del muchacho prestado al tutorial a ciegas, de la app a medias — al código de la casa.

La idea que no cambió: la computadora, obedeciendo.

Y el que ahora manda, es el dueño: la faena — con visto y con receta.

*📦 LA DESPENSA DEL OFICIO (tu código, ordenado como gente)*

*La biblioteca de recetas* — los scripts de la casa con nombre de gente
(«ordenar-fotos-por-mes»): guardados, respaldados, heredables. La memoria del oficio — en tu
disco, jamás en cabeza ajena.

*El visto humano* — el código leído ANTES de correr (la explicación: parte del servicio), el
borrado con DOBLE visto. El fuego — pensado, jamás a oscuras.

*El copiar-primero* — las faenas de orden moviendo a carpeta nueva (el borrado: de la mano
humana, tras verificar). La regla fina del oficio serio.

*El modo seguro* — pregunta TODO al arranque; el modo de confianza: solo lectura, ganado con
meses. La comodidad — nunca apurada.

*La vara del dinero* — el mismo cable de la 63: la aprendiz jamás paga, jamás compra, jamás toca
el dinero. La única faena que ninguna casa firma.

*🪧 EL CARTEL DEL OFICIO*

*Tu faena, en tu idioma — el código, a la vista: la magia sin receta no entra al taller.*

*El fuego con tu visto — y el borrado con doble visto: la computadora obediente también es seria.*

*La receta queda guardada — cada faena, un script con nombre de gente: la biblioteca de la casa.*

*El oficio corre en tu máquina — tus fotos y tus planillas: jamás un byte de viaje.*

*Y la aprendiz enseña — cada script leído, una clase: la casa que faena, aprende.*

*😄 EL MEME DE LA CASA*

El tutorial de YouTube, en su intro: «BIENVENIDOS A OTRO VÍDEO DE 47 MINUTOS — HOY: RENOMBRAR
ARCHIVOS (PARTE 1 DE 12)». La aprendiz, en tu pantalla: «¿esto?

Son cuatro líneas — mira, te las enseño, y con tu visto lo corro». La tienda vendiéndote el
curso de doce partes.

La casa, faenando en cuatro líneas — con clase incluida.

*⚠ LOS RIESGOS DE LA APRENDIZ, CON FECHA*

*El script a oscuras (el riesgo número uno, 16-oct-2026).* El visto dado sin leer (el «sí,
córrelo» automático: la caja negra aceptada por costumbre — el enter que ya no piensa, versión
código).

La salida: la regla uno de la doctrina — el código se muestra y se lee (la aprendiz explicando línea por línea: la explicación es oficio), y la vara fina: si nadie de la casa lo entiende, la aprendiz lo explica en idioma de casa (jamás «es muy técnico pa ti» — la explicación: parte del servicio). El fuego: jamás a oscuras.

*El borrado confiado (el riesgo del doble visto).* El script con `rm` escondido (el que «solo
ordena» y de camino borra los originales: la faena que sale cara).

La salida: la regla dos — el borrado con DOBLE visto y aviso en grande («BORRARÁ los originales: ¿continúa?»), y la vara fina del oficio: las faenas de orden, hechas COPIANDO primero (el script fino: mueve a carpeta nueva, jamás borra — el borrado: de la mano humana, cuando el orden esté verificado). La póliza (el respaldo): el cinturón de la casa.

*El modo confianza apurado (el riesgo del cómodo).* La casa pasando al modo de confianza en la
primera semana (el «ya me cansé de apretar sí»: el permiso permanente — la puerta del script a
oscuras, reabierta).

La salida: la vara de la fila 63 — el modo seguro TODO en las primeras semanas (cada script, su enter), y el modo de confianza: solo pa lo de lectura (listar, contar, mostrar — el borrado y la escritura: SIEMPRE con visto). La comodidad: ganada con meses — jamás regalada en días.

*La mente ajena por pereza (el riesgo del byte viajero).* La pareja mitad afuera (la aprendiz
local PERO pensando con la mente de la tienda: el código y los nombres de tus archivos, viajando
al taller ajeno — la faena local con pensar alquilado).

El remedio: la vara de la pareja completa (la mente de la 61: el pensar Y el escribir, en la caja), y la vara fina: si la mente ajena se usa un día (el modelo local sin espacio: la excepción), sin archivos personales en el pedido. El byte de la casa: viajero solo con firma.

*El script basura acumulado (el riesgo del cajón).* La carpeta de scripts sin orden (40 recetas
mezcladas, tres que hacen lo mismo, una que ya no corre: el cajón del desorden — la ironía fina:
la herramienta del orden, desordenada).

La salida: la gira de la biblioteca (mensual: las recetas leídas, las repetidas unificadas, las muertas borradas — con visto), y la vara fina: las recetas con nombre de gente («ordenar-fotos-por-mes», jamás «script(17)»). La biblioteca de la casa: con orden de biblioteca.

*📖 GLOSARIO DE LA COSECHA*

*Puente.* El cliente que no guarda música: la busca en el catálogo de otro y la trae al momento.
Debe su vida a un río ajeno — por eso la vara de esta escuela mira el push con fecha antes que
las estrellas.

*Cajón.* La escuela del archivo propio: MP3 y FLAC tuyos, tocados sin internet ni río ajeno.
Nunca depende de un provedor, jamás se corta en la loma, y su única obligación es que tus
etiquetas estén peinadas.

*Detective.* La escuela del descubrimiento: cruza fuentes, amarra discografías y te muestra
versiones. Muffon es su bandera en la cosecha — menos «ponme la playlist», más «enséñame el mapa
del artista».

*Cosecha.* El pase de vara ancho por una familia del censo: se mide casa por casa, con placa, y
lo que no pasa no se borra — se anota. La cosecha es la prueba de que el método de la casa
funciona.

*Placa.* El paquete completo de datos de una casa: estrellas con fecha, push con fecha, licencia
con nombre, fila de asuntos. Sin placa no hay censo — hay lista de apodos.

*Pulso.* La toma de datos con hora. El censo de la tarde no es el pulso de la noche: el #10 de
esta pieza midió a las ~23:12 UTC y cazó dos casas moviéndose en vivo. El censo no es una foto:
es un latido.

*Mapa vivo.* La numeración de los pulsos de la casa (#1 al #10 al corte de esta pieza). Cada
mapa vivo deja caja fechada para que el próximo lector compare su cuaderno con el nuestro.

*Censo vivo.* El barrido grande de la casa: 5.684 repositorios al 15-oct-2026, con estrellas,
pushes y licencias. Es la fuente de verdad de esta pieza — y crece por puerta verificada, no por
promesa.

*Vara.* La regla de la casa que decide qué entra al mapa: fuente abierta, licencia legible,
pulso con fecha. La vara no clasifica por gusto — mide por oficio.

*Corte.* El día y la hora en que se midió la verdad. Toda esta pieza es del corte 15-oct-2026;
mañana el corte dirá lo que viva mañana — y esa es su honestidad, no su debilidad.

*Quietud.* El silencio anotado: tronco grande sin empuje, con fecha de última actividad. No es
muerte ni abandono automático — es pausa con acta. Timber y InnerTune son las quietudes de esta
cosecha.

*Push.* El último empuje del taller: la fecha de la última actividad del repositorio. En la
escuela del puente, un push de esta semana vale más que mil estrellas — es la diferencia entre
taller vivo y museo.

*Release.* La versión publicada y firmada por el taller: la única forma del software que la casa
palomea. OuterTune al corte trae la v0.10.1 contándose en público — eso es salud de release.

*Asuntos.* Los issues del taller: la fila pública donde los problemas esperan turno. No cuenta
la cantidad — cuenta si se contestan. Trescientos con respuestas respiran; cuarenta en silencio,
no.

*Estrellas.* El aplauso del ecosistema: mide fama, no calidad. ★49.974 (15-oct-2026) hace a
Spotube el más aplaudido de la cosecha — la vara de la casa decide si ese aplauso viene con
contrato.

*Licencia.* El contrato escrito del taller: qué puedes hacer con su código. En esta cosecha
firman GPL-3.0, AGPL-3.0 y MIT — y tres casas viajan sin firma clara, con su vara marcada.

*GPL-3.0.* La licencia copyleft más común de la cosecha: usa el código, y lo que publiques con
él se abre con la misma placa. Es la firma que convierte un silencio en genealogía — InnerTune
la firmó, y OuterTune hereda con honor.

*AGPL-3.0.* La GPL para servicios: si el código corre como servicio, también se abre. muffon la
firma al 15-oct-2026 — la casa la lee con el mismo respeto que la GPL de sus hermanas.

*MIT.* La licencia más simple de leer: haz casi lo que quieras, conserva el aviso. Salt Player
la firma — garantía mínima, cadena limpia, cero letra chica.

*NOASSERTION.* La placa en blanco: el repositorio no declara licencia reconocida. No es delito —
es ausencia. Sin firma, el derecho por defecto es «todos los derechos reservados», y los
reempaques viajan sin freno legal.

*Copyleft.* La regla del recíproco: si tomas el código de un taller público para hacer el tuyo,
lo que agregues sale con la misma placa. Es el antídoto del reempaque silencioso.

*Fork.* La continuidad del software libre: un taller que nace del código de otro, respetando su
licencia. OuterTune es el fork vivo de InnerTune — no su imitación: su línea.

*Heredero.* El taller (o la línea) que toma el código de una casa quieta y sigue empujando. Para
heredar con honor hace falta una sola cosa: que la madre haya firmado licencia. Sin firma no hay
testamento.

*Reempaque.* El APK que toma la obra de un taller, le mete anuncios o peaje, y la reparte con
placa ajena. El enemigo viejo de la casa — y la razón de la vara: origen, firma, permisos, sin
prisa.

*Tienda legal.* La puerta de instalación que muestra el repositorio de origen: Droid-ify,
Neo-Store, Accrescent, el F-Droid de la pieza 01. Si la tienda no muestra el repo, no es tienda
— es grupo con carrocería bonita.

*Droid-ify.* El cliente F-Droid material de la casa (pieza 01): busca la casa por su nombre
exacto del censo y la instalación viaja con la placa a la vista. La primera puerta recomendada
de esta cosecha.

*Accrescent.* La tienda de estándares altos de la pieza 01: firmas estrictas, catálogo curado.
Segunda puerta legal — la que usa el que prefieren las varas cortas.

*F-Droid.* La casa madre de las tiendas libres: el catálogo histórico del ecosistema. Vieja,
sabida y firme — el anexo donde la mayoría de las catorce de esta cosecha tiene placa.

*APK.* El paquete instalable de Android. En sí mismo es neutro — como un sobre. La vara de la
casa pregunta siempre lo mismo: ¿quién lo selló? La respuesta separa la tienda legal del grupo
de siempre.

*Firma.* La marca criptográfica del taller en su release. La tienda legal la verifica por ti; el
APK de grupo, nadie sabe quién la puso. Sin firma verificable, no hay confianza — hay fe, y la
casa no trabaja con fe.

*Material You.* El lenguaje de diseño de Android moderno que sigue el color de tu fondo. Retro
Music lo lleva de bandera (★5.357, 18-oct-2026) — el mueble clásico vestido de esta década.

*Etiqueta.* La información adentro del archivo de música: título, artista, álbum, número, año.
El reproductor lee la etiqueta, no el nombre del archivo — peinar etiquetas es peinar la
biblioteca entera.

*FLAC.* El formato sin pérdida: suena exacto al master y pesa cinco veces más que un MP3. Para
el archivo maestro en la PC — no para el bolsillo del día a día.

*MP3.* El formato que movió el mundo y sigue mandando en el bolsillo: a 320 kilobits suena
igualito en auricular humilde y pesa como la palabra. La casa lo respeta sin nostalgia ni
complejo.

*Caché.* La memoria del río: las canciones que ya suenaste se guardan un tiempo para no volver a
bajar. Es la gracia económica del streaming libre — la mata de hilo del tercer día suena media
gratis.

*Scrobble.* El hábito del detective: registrar lo que suenas para amarrar historial y
descubrimiento. muffon lo trae de fábrica — el reproductor que también lleva el cuaderno de
campo.

*Discografía.* El mapa completo de un artista: álbumes, años, versiones. La vara del detective
es amarrarla bien — muffon la cruza entre fuentes al 18-oct-2026 con ★2.246 y AGPL firmado.

*Multi-fuente.* La casa que no se casa con un río: consulta varios provedores y te sirve la
versión que esté limpia. Spotube, Namida y muffon viven de esa libertad — con sus licencias
mirándose dos veces.

*Streaming.* El modelo del río: suena ahora, no guarda nada tuyo. Infinito mientras el río corra
— y por eso esta pieza repite: exporta lo que amas, streamea lo que descubres.

*Aleatorio.* El modo más honesto del reproductor: te enseña cuánto conoces tu propio archivo. En
el cajón con etiquetas peinadas, el aleatorio es un paseo; sin etiquetas, un secuestro.

*Lista.* La secuencia guardada: el arte del anfitrión y la herramienta del viajero. La lista
buena se exporta a archivo — la que solo vive dentro de la app es rehén de la app.

*Exportar.* Sacar tus listas y favoritos a archivo que otra casa pueda leer. La prueba de
propiedad de la escuela del río: si el mueble no exporta, eres inquilino con mueble bonito.

*Sincronía.* La rutina que mueve tu música entre PC y teléfono sin cable ni heroico: Syncthing y
su familia (viene en la serie). La copia maestra queda en casa; el teléfono lleva la de trabajo.

*Copia maestra.* El original en FLAC que vive en tu PC o disco, del que nacen las copias de
bolsillo. Convertir del maestro, nunca al revés: bordarle encaje a un saco de harina no lo
vuelve traje.

*Root.* El teléfono abierto de par en par. La casa lo trata en la pieza 20 con sus letreros — y
esta cosecha musical NO lo necesita ni un poquito: fuente abierta es taller público, no cirugía.

*Cuenta de prueba.* El casco de la obra: la cuenta sin nada personal que estrenas cualquier app
nueva. En esta cosecha ninguna de las catorce pide contraseña — la que la pida, desinstálala y
anota la fecha.

*Letrero anti-reempaques.* La regla que SimpMusic puso en su casa (pieza 08) y se volvió ley del
barrio: los reempaques no son míos y no los apoyo. El letrero que le quita al clonero su excusa
favorita — la duda.

*Genealogía.* El oficio de contar de dónde viene cada casa: troncos, forks, herederos,
quietudes. La pareja InnerTune→OuterTune es la lección viva de esta cosecha — misma sangre,
distinto pulso.

*Sucesión.* El relevo ordenado cuando un taller se duerme: la línea GPL continúa en el heredero
y el mapa anota el cambio con fecha. Sucesión limpia no tiene drama — tiene acta.

*Corte honesto.* El corte que declara sus huecos: faltan casas, el censo sigue creciendo, y la
pieza dice qué queda fuera. Sabe a lo que sabe — y lo que sabe, lo firma.

*Rumor con formato.* Lo que queda de una recomendación cuando se le recorta la fecha: «Timber es
el mejor» sin el 28-abr-2023 es un rumor con negritas. La casa comparte mapas con corte puesto.

*Taller público.* El repositorio abierto: el taller cuyas herramientas, filas y errores están a
la vista de todos. Las catorce de esta cosecha lo son — y por eso se les puede medir sin pedirle
permiso a nadie.

*Resurrección.* El regreso con fecha: tachiyomiJ2K volvió de dos años y medio de silencio (pieza
15). Por eso la quietud lleva acta y no lápida — la casa celebra el despertar el día que ocurre.

*Gemela FB.* La copia hermana de una pieza que nacía para Facebook. Por orden del dueño del 15-oct noche, la serie nueva (21 en adelante) viaja SIN gemela: WhatsApp puro — el muro de Facebook queda fuera de esta cosecha.

Ley anotada en la hoja de ruta, no en la discordia.

*LA LISTA.* El índice vivo de la biblioteca (la pieza 00): el mapa del mapa donde cada guía
nueva toma su número y su fila. Esta cosecha entra al corte siguiente de LA LISTA con su placa.

*Boleta.* El único requisito de entrada a la biblioteca: haber abierto el repositorio, la página
de versiones y la libreta de obra. Las catorce de esta cosecha pagaron boleta — por eso tienen
pieza.

*Lupa.* La herramienta de la casa que examina una pieza como un oficial de aduana: respiro,
cadencia, anclas de tiempo, dialecto. La v6 «aire» es la que exige bloques que respiren — esta
pieza nació bajo su vara.

*Respiro.* La ley del aire: ningún bloque de la pieza debía quedarse sin oxígeno — al corte del
15-oct la vara mide ~380 caracteres por bloque. La música también respira: es la diferencia
entre leer y ahogarse.

*Certificación.* Las baterías que la pieza corre antes de firmarse FINAL: la experta (v4), la
evolutiva (v5) y la de rarezas (fuzz) con semilla fija. Sin batería no hay sello — y sin sello,
la pieza no se llama final.

*Acta.* El documento fechado donde la casa anota lo que hizo: actas de corrección, actas de
censo, actas de push. Lo que no tiene acta no pasó — y lo que pasó con acta, no se puede negar.

*Registro.* El cuaderno mayor de la casa: registro-2026-10-15.md y sus hermanos por fecha,
append-only. Aquí vive el acta de esta cosecha, con su pulso #10 y su hora.

*Censo abierto.* La puerta del dueño: lo que encuentra un día, entra el MISMO día al censo con
prioridad. Los Hush de la pieza 17 entraron así — y esta cosecha tiene la puerta abierta para la
próxima casa musical que llegue.

*Hallazgo.* La puerta que alguien trae a la casa: un repositorio que merece mapa. No se necesita
vara de hierro para traerlo — se necesita fuente abierta: lo demás lo mide el censo.

*Cola.* El orden sin favor: lo que no pasa la vara hoy queda en cola anotada, no en silencio. La
cola tiene orden, no pena — y se revisa en cada corte.

*Anti-omisión.* La ley de la casa contra el dato sin fecha: lo que no se re-pulsó viaja FECHADO
como el corte en que se vio. Nunca «actualmente» sin hora — siempre «al 15-oct-2026».

*Triple lectura.* La lectura de la casa antes de publicar: la del técnico (¿el dato aguanta?), la del lector (¿se entiende al primer trago?) y la del rival (¿dónde me meto?). Esta pieza pasó las tres — y los mitos son puro oro de la tercera.

*Río.* El catálogo ajeno: YouTube Music, archive público, provedores varios. El río corre sin
pedirte permiso y se corta sin avisar — por eso la escuela del puente se mide por push fresco.

*Señal.* La torre que el río necesita y el cajón no. En la loma, la señal es la primera vara: lo
que no descargaste no existe en carretera — lección que el campo enseña gratis.

*Loma.* La geografía honesta del país: donde el streaming confiesa su dependencia. Toda la
escuela del puente se queda mudita en la loma — el cajón suena igualito.

*Modo avión.* La prueba de fuego del mueble local: ponerlo y que suene. Si tu lista de fiesta
necesita torre, no era lista — era esperanza.

*Anfitrión.* El que pone el teléfono en la fiesta. Su vara: lista corrida, pantalla bloqueada y
cero promesas de wifi ajeno. La casa le recomienda cajón — el río en fiesta es apuesta.

*Coleccionista.* El que suena, guarda, etiqueta y copia. No necesita FLAC de colección para
empezar: necesita la rutina — maestro en PC, copia en teléfono, lista exportada. La estructura
antes que el volumen.

*Oído con oficio.* El que escucha preguntando: qué versión, qué año, qué disco. La escuela del
detective existe para él — muffon al 18-oct-2026 con ★2.246 y AGPL firmado.

*Bitrate.* Los kilobits por segundo del audio: la medida de cuánto archivo pesa una canción. A
más bitrate, más fidelidad hasta donde el oído y el altavoz alcancen a distinguir — el 320 del
MP3 es el techo práctico del bolsillo.

*Pérdida.* Lo que un formato tira al comprimir. El MP3 la tiene (y bien administrada a 320
alcanza al bolsillo); el FLAC no la tiene — y por eso uno viaja y el otro archiva.

*Conversión.* Pasar del maestro a la copia de trabajo: FLAC a MP3, una vez, desde el original.
La conversión inversa no existe en la casa — no se inventa calidad que no bajó.

*Permiso.* Lo que la app te pide al entrar. La vara: permiso fuera de oficio = desinstalar y
volver al censo. Un reproductor que pide contactos no es reproductor — es huésped con maleta.

*Desinstalar.* El acto de higiene digital: quitar la app con fecha anotada. La casa lo
recomienda sin drama — la desinstalación honesta es la mitad de la vara que nadie cuenta.

*Actualizar.* Traer la nueva release del taller legal. En la escuela del puente, actualizar
semanal no es manía: es respirar — el río cambia de puerta y el taller contesta con push.

*Versión.* El número que el taller pone a su release (OuterTune v0.10.1 al corte). Con versión
hay historia: se puede comparar, se puede volver atrás, se puede exigir.

*Snapshot.* La foto del estado en un momento: la caja de pulso de esta pieza es un snapshot del
15-oct-2026 a las ~23:12 UTC. Mañana será historia fechada — que es el único tipo de historia
que la casa guarda.

*Dialecto.* La voz de la casa: dominicano de verdad, con clienta, barrio y chin chin — pero el
dato siempre en traje formal. El dialecto es la envoltura; la placa, el contenido.

*Chin chin.* El golpe de mesa de la moral del meme: la sentence final que clava la lección. No
es adorno — es la firma de la casa cuando el oficio quedó claro.

*Muro FB.* La fila de piezas gemelas que la casa publicaba en Facebook. Desde el 15-oct noche:
la serie 21+ va sin muro — WhatsApp puro. La ley del dueño, anotada con fecha y sin melcocha.

*Índice.* El mapa de una pieza: el árbol de esta guía. Un árbol único por pieza, con secciones y
tiempos — el lector sabe dónde está parado y cuánto falta pa la parada.

*Provedor.* El que sirve el río: la plataforma cuyo catálogo atraviesa el puente. No es socio de
nadie y no avisa cuando muda la puerta — por eso el taller que la sigue es la primera vara de
esta escuela.

*Fila viva.* La fila de asuntos que se contesta: la señal de taller respirando sin ambigüedad.
Los asuntos de esta cosecha van de 42 (Musify) a 868 (Spotube) al 15-oct-2026 — la vida no es la
cantidad, es la contesta.

*Publicar.* El acto de soltar la pieza con acta, pulso y hora. Publicar sin fecha es rumor;
publicar con fecha es mapa. Esta cosecha sale el 15-oct-2026 con pulso #10 — y su sello lo
cuenta.

*Colmado.* La bodega del barrio: lo tienes todo cerca, te fiarán la libreta, pero el catálogo es
el que cabe en el estante. En esta pieza, la escuela del puente con factura propia — respetada,
y ajena al censo.

*Puerta al viento.* Vivir de un solo río sin cajón propio: la casa abierta cuando el provedor
muda la puerta. El antídoto cabe en una línea — descarga lo que amas, streamea lo que descubres.

*Segunda fila.* Los vecinos que el censo vio y esta pieza no tomó: podcast, vídeo puro y
talleres bajo la vara del barrido. No es exclusión — es cola con orden, y se revisa en cada
corte.

*Oído del barrio.* El que escucha antes de opinar: prueba dos muebles, mira dos placas y
pregunta en la fila antes de palomear. No nace sabido — se hace con una semana de ritual bien
dada.

Aprendiz del taller|Open Interpreter: la mente de la casa con oficio de programadora — tu faena
dicha en tu idioma, hecha en código con visto. La computadora — obedeciendo en tu lengua.

Placa del oficio fino|La de la aprendiz (★68.589, pulso 16-oct-2026): la primera del código
corrido en tu máquina — una nariz (575) detrás del cofre de la 56. El censo no decora: mide.

Hornada de julio|La de 2023: la aprendiz (14-jul), la mente (26-jul) y el motor (10-mar) — el
año cero del oficio local. La década: decidida en un verano.

Código a la vista|La regla uno: el script completo mostrado ANTES de correr, explicado en idioma
de casa si nadie lo entiende. La magia sin receta — fuera del taller.

Doble visto|El del borrado: aviso en grande («BORRARÁ los originales») y enter pensado. La única
faena que jamás se automatiza.

Receta guardada|El script que quedó de cada faena: con nombre de gente, en la biblioteca de la
casa. La segunda vez — instantánea; la memoria — en tu disco.

Biblioteca de recetas|La carpeta de scripts de la casa: respaldada en dos discos, girada
mensual, heredable al muchacho. El álbum y el código — en la misma gaveta.

Copiar-primero|La regla fina del orden: mover a carpeta nueva, jamás borrar de entrada. El
borrado — humano, tras verificar. El cinturón — con póliza.

Modo seguro|El del arranque: pregunta TODO. El de confianza: solo lectura, ganado con meses. La
comodidad — nunca apurada en días.

Oído fino|El de la aprendiz: la faena entendida como la dices, y lo oscuro — preguntado antes de
hornear. La aprendiz de verdad: pregunta primero.

Faena de casa|La que la aprendiz sí hace: fotos, planillas, PDF, listas — la oficina del hogar
completa. La que no: la fundación del sistema — del dueño.

Pareja completa|La del oficio entero: la mente local (61) pensando y la aprendiz escribiendo —
todo en la caja, sin un byte de viaje. El pensar alquilado: solo con firma.

Byte sin viaje|El de tus archivos: las fotos y las planillas jamás salen de la máquina. La faena
— local de la casa, como el pensar.

Clase del taller|La que cada script leído da: un concepto, quince minutos, gratis. La casa que
faena — aprende; el muchacho — con maestra en el taller.

Nariz del cofre|La distancia de 575 estrellas entre la aprendiz (68.589) y el cofre (69.164): la
más chica del podio. Si cae — el bloque IA tendrá cuatro de las cinco placas mayores.

Script basura|El del cajón desordenado: repetidos, muertos, sin nombre. La gira mensual de la
biblioteca — con visto; las recetas — con nombre de gente.

Fallo del mediodía|El del script a medio camino: carpeta de prueba, error leído con la aprendiz,
faena partida en pasos. El fallo — parte del oficio, jamás drama.

Herencia de scripts|La nueva de la historia: la biblioteca de la casa pasando al muchacho como
las recetas de cocina de la abuela. El código — archivo familiar.

Cortesía Apache|La de compartir la receta: el script libre pa el vecino, el club, el comité —
cada casa ajusta la suya. El oficio de compartir — tan viejo como la cocina.

Siembra del oficio|La que la aprendiz hace en el muchacho que ya programa: script base en
segundos, lectura y mejora de su mano. La ayudante — no reemplaza: siembra.

Acta buscable|La del comité: 12 meses al despacho, texto y resumen por fecha. El acta de marzo —
a dos clics; la asamblea — con memoria.

Video que abre|El del cumpleaños: conversado con receta guardada, misma calidad. La TV del sofá
— leyendo lo que el teléfono graba; el «no abre» — jubilado.

Biblioteca colectiva|La del club y el comité: recetas compartidas y ajustadas por casa. El
taller libre — compartiendo oficio como comparte plato.

Ajuste de receta|El que toda casa hereda hace: rutas cambiadas, faena adaptada. La receta del
vecino — inspiración, jamás molde.

Formato de fiesta|El que la TV lee: la receta del conversor guardada tras el primer drama. Los
cumpleaños del año — sin «no abre».

Ayudante maestra|La que enseña con script legible y comentado: el oficio — sembrado faena a
faena. La puerta del developers — abierta de par en par.

Tarde de estreno|La primera faena real de la casa: pedido, lectura, visto, verificación. El
álbum del caos — ordenado en una tarde; la receta — guardada pa siempre.

Oficio al corte|El parte del 16-oct-2026: la aprendiz con aire de la semana, la hornada de julio
en faena diaria. El oficio local — la generación que aguantó.

*🗓 EL RITUAL DE SIETE DÍAS (de la faena imposible al oficio de la casa)*

*Día uno — la pareja en pie.* La mente (61) respirando, la aprendiz instalada y presentándose
(«¿qué puedes hacer?»), la letra Apache leída en su hogar. El taller: con aprendiz.

*Día dos — la primera faena.* La más fácil de la casa (una carpeta de prueba: jamás empezar por las fotos de la boda), el pedido en tu idioma, el script LEÍDO completo (con calma, preguntando lo oscuro), el visto dado, la faena verificada. La primera receta: en la biblioteca.

*Día tres — el modo seguro consagrado.* Los permisos firmados (el modo seguro: pregunta todo), la vara del borrado probada en carpeta de prueba (el doble visto: visto en acción), la regla del copiar-primero adoptada. La confianza: con firma y con deuda de prueba.

*Día cuatro — la faena de verdad.* La real de la casa (las fotos del teléfono, la planilla del
mes), con el ritual completo: pedido, lectura, visto, verificación, receta guardada con nombre
de gente. La biblioteca: creciendo en serio.

*Día cinco — la segunda faena y la enseñanza.* Otra faena (la del banco, la del muchacho), y el
muchacho del liceo leyendo un script completo (la primera clase de código de la casa: gratis,
con maestra en el taller). El oficio: enseñando.

*Día seis — la póliza.* La biblioteca de scripts en el respaldo (dos discos), la prueba del
desastre (una receta re-corrida en carpeta de prueba: idéntica), la gira de la biblioteca
anotada en el calendario (mensual). El oficio: con póliza.

*Día siete — la aprendiz en el mapa.* La página del taller: el oficio documentado (qué faenas, qué recetas, qué varas), la pareja completa (mente + aprendiz) en el diagrama de la casa, y la gira sumada. El oficio de código: oficial — la casa, con su aprendiz de planta.

*La regla de la aprendiz:* el código se lee, el fuego con visto, el borrado con doble visto — y
la receta, siempre guardada.

*📎 LOS APÉNDICES DEL OFICIO (lo que queda de la noche)*

Apéndice A — el mapa del oficio, al corte.

La fila 61-70 con su oficio completo: la mente (61) piensa, la cara (62) muestra, las manos MCP
(63) hacen las faenas firmadas, la aprendiz (esta) escribe y corre el código — y la casa entera
conectada: el despacho (59) alimentando las faenas, el cofre (56) guardando las llaves, el
tablero (60) vigilando los latidos, el taller (57) archivando las recetas.

La casa: pensando, mostrando, haciendo y programando — la fila de la IA propia, completa de oficio.

Apéndice B — las cinco preguntas del mostrador, en una línea. ¿Qué hace?

Escribe y corre el código de tus faenas: en tu máquina, con visto. ¿Qué no hace?

No toca la fundación del sistema, no paga, no borra sin doble visto. ¿Cuánto cuesta?

Luz y quince minutos de instalación — la letra Apache: gratis pa siempre. ¿Cuánto tarda?

Una tarde con SU semana de prueba.

¿Y si borra algo mal? El respaldo de la fila lo restaura — y la doctrina (copiar-primero): pa
que no pase.

Apéndice C — la página en blanco. La que la forja deja abierta a propósito: la faena de
computadora que TÚ repites cada mes (¿cuál es — las fotos, la planilla, los PDF?).

Esa respuesta — la tuya, fechada en tu taller — vale más que 68.589 estrellas: es la vara
midiendo tu primera tarde de oficio.

La obra no termina en la lectura: termina cuando la faena repetida, la corre tu propia receta.

Apéndice D — la sala de los errores. Las tres fallas posibles y su salida.

Si la aprendiz no entiende el pedido (el oído confundido): el pedido re-dicho con detalle
(dónde, qué, cómo — la receta del oído fino: contexto, contexto) y la faena partida en pasos
chiquitos.

Si el script falla a medio camino (la faena a medias): la carpeta de prueba (el script
re-corrido con menos archivos) y el error leído con la aprendiz (el mensaje del fallo: traducido
y arreglado — el fallo: parte del oficio).

Si la mente local no da abasto (el modelo grande sin espacio): el modelo más chico de la 61 (la
vara de la despensa de modelos) y las faenas partidas en tandas.

Apéndice E — la fila que viene. La 65 firma la compañera del sofá (la IA con rostro que vive en
tu máquina: la del censo — la fila que acompaña con oficio); la fila completa 61-70 firma la IA
propia al completo.

La casa no improvisa: programa. Y la noche firma: la aprendiz del taller — el código, con visto.

*🎯 EL MINIQUIZ DEL OFICIO*

*LAS PREGUNTAS:*

*1.* ¿Cuándo se muestra el código — y qué pasa si nadie lo entiende?

*2.* ¿Qué necesita el borrado que no necesita nada más?

*3.* ¿Qué deja guardada cada faena — y cómo se llaman esos archivos?

*4.* ¿Por qué la aprendiz NO es placa mayor — quién la supera y por cuánto?

*5.* ¿Qué hornada firma la mente, el motor y la aprendiz — y en qué años?

*Respuestas al revés (léelas de atrás para adelante):*

REV|.lacol oicifo led orec oña le — )oña omsim led ram-01( rotom le y )luj-41( zidnerpa al ,)luj-62( etnem al :3202 ed onarev lE=1|REV|.onif oicifo led acalp al se — 575 ed ziran anu rop arepus al )461.96★ nedrawtluaV :65( asac al ed erfoc lE=2|REV|.asac al ed acetoilbib al — )»sem-rop-sotof-ranedro«( etneg ed erbmon noc odadraug tpircs le :atecer aL=3|REV|.azitamotua es acnun euq retne ocinú le :»?aúnitnoc¿ :selanigiro sol ÁRARROB« — ednarg ne osiva noc otsiv elboD=4|REV|.»it ap ocincét yum se« sámaj :asac ed amoidi ne acilpxe ol zidnerpa al ,edneitne ol eidan is y — rerroc ed SETNA=5